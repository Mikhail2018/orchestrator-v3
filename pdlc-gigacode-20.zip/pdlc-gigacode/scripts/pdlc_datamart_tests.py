#!/usr/bin/env python3
"""OPS-070 — Data mart quality-test & test-data generator.

Two generic capabilities, both config-driven via knowledge.dataMartTesting:

1. `dq-tests` — parse an S2T (source-to-target) Excel sheet, emit data
   quality test scripts as CSV (DataExist / Mandatory / Double-PK /
   Broken-links), one file per environment (RDT and IFT — differing only
   by schema).

2. `test-data` — given a list of source tables (provided by the caller
   after scanning datamart Scala code), emit a CSV stub per source into
   the sources dir. The actual relevant row content is filled by the
   agent (LLM) — this script creates well-formed skeletons + a manifest
   the agent fills, since join-relevant data needs semantic reasoning.

Why a script (vs pure agent shell):
- Excel parsing is deterministic and error-prone by hand
- CSV escaping / quoting handled by csv module, not string concat
- No recursive listing, no cmd.exe-specific commands (OPS-050/060)
- Cross-platform via openpyxl + csv + pathlib

Config (knowledge.dataMartTesting):
    s2t_excel_path, s2t_sheet, data_vars_path, market_schema_var,
    autotests_dir, sources_output_dir, environments.{rdt,ift}

Usage:
    # 1. Convert S2T sheet to CSV (intermediate, for agent inspection):
    python pdlc_datamart_tests.py sheet-to-csv \\
        --excel s2t/dm_product_s2t.xlsx --sheet "Target columns" \\
        --out s2t/target_columns.csv

    # 2. Generate DQ test CSVs from the parsed sheet:
    python pdlc_datamart_tests.py dq-tests \\
        --columns-csv s2t/target_columns.csv \\
        --datamart dm_product \\
        --schema-rdt custom_cib_pkaptdul \\
        --schema-ift custom_cib_pkaptdul_ift \\
        --out-dir autotests

    # 3. Scaffold test-data CSV skeletons for source tables:
    python pdlc_datamart_tests.py test-data-skeleton \\
        --sources "custom_cib_pkaptdul.dns_agr_frs,custom_cib_pkaptdul.dns_plcmnt" \\
        --out-dir docs/sources

Exit codes:
    0 — success
    1 — bad args / missing input
    2 — openpyxl not available (for Excel ops)
    3 — output write failed
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path


# ─────────────────────────────────────────────────────────────────────
# Expected S2T sheet column headers (RU). Tolerant matching: we look
# for these substrings case-insensitively to survive minor variations.
# ─────────────────────────────────────────────────────────────────────

HEADER_HINTS = {
    "column_name": ["column name", "имя колонки", "наименование атрибута", "attribute", "колонк"],
    "is_null": ["является ли поле null", "nullable", "is null", "null?"],
    "is_pk": ["является ли поле pk", "is pk", "pk?", "primary key"],
    "is_fk": ["является ли поле fk", "is fk", "fk?", "foreign key"],
    "note": ["column attribute note", "примечание", "note", "attribute note"],
}


def _find_col(headers: list[str], hints: list[str]) -> int | None:
    """Find column index whose header contains any hint (case-insensitive)."""
    low = [(h or "").strip().lower() for h in headers]
    for i, h in enumerate(low):
        for hint in hints:
            if hint in h:
                return i
    return None


def sheet_to_csv(excel_path: Path, sheet: str, out_csv: Path) -> int:
    """Export one Excel sheet to CSV verbatim."""
    try:
        import openpyxl  # type: ignore
    except ImportError:
        print(
            "ERROR: openpyxl not installed. Run: pip install openpyxl --break-system-packages",
            file=sys.stderr,
        )
        return 2

    if not excel_path.is_file():
        print(f"ERROR: Excel file not found: {excel_path}", file=sys.stderr)
        return 1

    wb = openpyxl.load_workbook(excel_path, data_only=True, read_only=True)
    if sheet not in wb.sheetnames:
        print(
            f"ERROR: sheet '{sheet}' not found. Available: {wb.sheetnames}",
            file=sys.stderr,
        )
        return 1

    ws = wb[sheet]
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f, delimiter=";")
        for row in ws.iter_rows(values_only=True):
            writer.writerow(["" if c is None else str(c) for c in row])

    print(f"Exported sheet '{sheet}' → {out_csv}")
    return 0


def _read_columns_csv(columns_csv: Path) -> tuple[list[str], list[dict]]:
    """Read the S2T columns CSV. Returns (headers, rows-as-dicts).

    Auto-detects the header row (first row containing a recognizable
    column-name header).
    """
    with columns_csv.open(encoding="utf-8") as f:
        # Sniff delimiter
        sample = f.read(4096)
        f.seek(0)
        delim = ";" if sample.count(";") >= sample.count(",") else ","
        reader = csv.reader(f, delimiter=delim)
        all_rows = [r for r in reader]

    # Find header row: the first row where we can locate a column-name col
    header_idx = None
    for i, row in enumerate(all_rows[:20]):  # search first 20 rows
        if _find_col(row, HEADER_HINTS["column_name"]) is not None:
            header_idx = i
            break

    if header_idx is None:
        raise ValueError(
            "Could not locate header row (no 'column name'-like header in first 20 rows)"
        )

    headers = all_rows[header_idx]
    idx = {
        key: _find_col(headers, hints)
        for key, hints in HEADER_HINTS.items()
    }

    rows: list[dict] = []
    for row in all_rows[header_idx + 1:]:
        if not any((c or "").strip() for c in row):
            continue  # skip blank rows

        def get(key: str) -> str:
            i = idx[key]
            if i is None or i >= len(row):
                return ""
            return (row[i] or "").strip()

        col_name = get("column_name")
        if not col_name:
            continue
        rows.append({
            "column_name": col_name,
            "is_null": get("is_null"),
            "is_pk": get("is_pk"),
            "is_fk": get("is_fk"),
            "note": get("note"),
        })

    return headers, rows


def _is_yes(v: str) -> bool:
    return v.strip().lower() in ("yes", "y", "да", "true", "1")


def _is_no(v: str) -> bool:
    return v.strip().lower() in ("no", "n", "нет", "false", "0")


def generate_dq_tests(
    columns_csv: Path,
    datamart: str,
    schema: str,
    out_csv: Path,
) -> int:
    """Generate DQ test CSV for one environment (schema-specific)."""
    try:
        headers, rows = _read_columns_csv(columns_csv)
    except (ValueError, OSError) as e:
        print(f"ERROR reading columns CSV: {e}", file=sys.stderr)
        return 1

    fq_table = f"{schema}.{datamart}"
    tests: list[dict] = []
    tid = 1

    def add(entity: str, name: str, script: str, expected: str) -> None:
        nonlocal tid
        tests.append({
            "Id": tid,
            "Entity": entity,
            "Test_name": name,
            "Test_script": script,
            "Expected_result": expected,
        })
        tid += 1

    # 1. DataExist — count by table
    add(datamart, "Data exists", f"SELECT COUNT(*) FROM {fq_table}", ">0")

    # 2. Mandatory attributes — NOT NULL where is_null == NO
    for r in rows:
        if _is_no(r["is_null"]):
            col = r["column_name"]
            add(
                datamart,
                f"Mandatory attribute filled: {col}",
                f"SELECT COUNT(*) FROM {fq_table} WHERE {col} IS NULL",
                "0",
            )

    # 3. Double PK — no dups on PK columns
    pk_cols = [r["column_name"] for r in rows if _is_yes(r["is_pk"])]
    if pk_cols:
        pk_list = ", ".join(pk_cols)
        add(
            datamart,
            f"Double PK: {pk_list}",
            (
                f"SELECT COUNT(*) FROM (SELECT {pk_list}, COUNT(*) AS cnt "
                f"FROM {fq_table} GROUP BY {pk_list} HAVING COUNT(*) > 1) t"
            ),
            "0",
        )

    # 4. Broken links — each FK must resolve to a PK (from note refs)
    for r in rows:
        if _is_yes(r["is_fk"]):
            col = r["column_name"]
            note = r["note"]
            # note may contain comma-separated PK references like
            # "schema.table.pk_col" or "table.pk_col"
            refs = [ref.strip() for ref in note.split(",") if ref.strip()]
            if not refs:
                # FK declared but no reference target — emit a TODO test
                add(
                    datamart,
                    f"Broken links: {col} (REF UNKNOWN — fill note)",
                    f"-- TODO: FK {col} has no PK reference in 'Column Attribute Note'",
                    "0",
                )
                continue
            for ref in refs:
                add(
                    datamart,
                    f"Broken links: {col} -> {ref}",
                    (
                        f"SELECT COUNT(*) FROM {fq_table} t "
                        f"LEFT JOIN {ref.rsplit('.', 1)[0] if '.' in ref else ref} r "
                        f"ON t.{col} = r.{ref.rsplit('.', 1)[-1]} "
                        f"WHERE t.{col} IS NOT NULL AND r.{ref.rsplit('.', 1)[-1]} IS NULL"
                    ),
                    "0",
                )

    # Write CSV
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    try:
        with out_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=["Id", "Entity", "Test_name", "Test_script", "Expected_result"],
                delimiter=";",
            )
            writer.writeheader()
            for t in tests:
                writer.writerow(t)
    except OSError as e:
        print(f"ERROR writing {out_csv}: {e}", file=sys.stderr)
        return 3

    print(f"Generated {len(tests)} tests → {out_csv} (schema={schema})")
    return 0


def test_data_skeleton(sources: list[str], out_dir: Path) -> int:
    """Create CSV skeleton (header-only) for each source table.

    The agent fills relevant rows afterward — this just ensures correct
    filenames and flat layout. Filename: <schema>_<table>.csv (dots in
    the FQ name become underscores).
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    created = []
    for src in sources:
        src = src.strip()
        if not src:
            continue
        # custom_cib_pkaptdul.dns_agr_frs -> custom_cib_pkaptdul_dns_agr_frs.csv
        fname = src.replace(".", "_") + ".csv"
        path = out_dir / fname
        if not path.exists():
            # Header-only placeholder; agent will add real columns + rows
            path.write_text(
                f"-- source: {src}\n-- TODO: agent fills columns + >=5 relevant rows\n",
                encoding="utf-8",
            )
            created.append(fname)
    print(f"Created {len(created)} source skeletons in {out_dir}:")
    for c in created:
        print(f"  + {c}")
    if not created:
        print("  (all skeletons already existed)")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Data mart quality-test & test-data generator (OPS-070)."
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_sheet = sub.add_parser("sheet-to-csv", help="Export Excel sheet to CSV")
    p_sheet.add_argument("--excel", type=Path, required=True)
    p_sheet.add_argument("--sheet", default="Target columns")
    p_sheet.add_argument("--out", type=Path, required=True)

    p_dq = sub.add_parser("dq-tests", help="Generate DQ test CSV from columns")
    p_dq.add_argument("--columns-csv", type=Path, required=True)
    p_dq.add_argument("--datamart", required=True)
    p_dq.add_argument("--schema-rdt", required=True)
    p_dq.add_argument("--schema-ift", required=True)
    p_dq.add_argument("--out-dir", type=Path, default=Path("autotests"))

    p_td = sub.add_parser("test-data-skeleton", help="Scaffold source test-data CSVs")
    p_td.add_argument("--sources", required=True, help="Comma-separated FQ table names")
    p_td.add_argument("--out-dir", type=Path, default=Path("docs/sources"))

    args = parser.parse_args(argv)

    if args.cmd == "sheet-to-csv":
        return sheet_to_csv(args.excel, args.sheet, args.out)

    if args.cmd == "dq-tests":
        rc1 = generate_dq_tests(
            args.columns_csv, args.datamart, args.schema_rdt,
            args.out_dir / f"{args.datamart}_tests.csv",
        )
        rc2 = generate_dq_tests(
            args.columns_csv, args.datamart, args.schema_ift,
            args.out_dir / f"{args.datamart}_tests_ift.csv",
        )
        return rc1 or rc2

    if args.cmd == "test-data-skeleton":
        sources = args.sources.split(",")
        return test_data_skeleton(sources, args.out_dir)

    return 1


if __name__ == "__main__":
    sys.exit(main())
