# Improvement Prompt — `/pdlc:review-pr`

Шаблон промпта для improvement-субагента, который вызывается на IMPROVE-ветке
(score < 8). SKILL.md `### 4. Если IMPROVE (score < 8) — Improvement субагент`
ссылается сюда.

---

### 4. Если IMPROVE (score < 8) — Improvement субагент

```
Task tool:
  subagent_type: "general-purpose"
  description: "Fix PR #N based on review"
  prompt: [prompt ниже]
```

Prompt для improvement субагента:
```
Ты получил результаты независимого quality review PR.
Твоя задача — исправить ТОЛЬКО конкретные замечания из review,
ничего больше.

PR ВЕТКА: {branch name}
ЗАДАЧА: {TASK-ID}
PR_NUM: {N}

РЕЗУЛЬТАТЫ РЕВЬЮ (источник правды для scope):
{полный ответ review}

═══════════════════════════════════════════
TOOL CALL BUDGET (OPS-038)
═══════════════════════════════════════════

⛔ Лимит: максимум 8 Read/Glob операций для исследования контекста.
Edit для исправлений и Bash для тестов/git/{test_command} — не считаются.

Причина — Node.js баг (claude-code#2629): >11 tool calls → terminate.

Стратегия:
- Read только тех файлов, которые упомянуты в "КРИТИЧНЫЕ ПРОБЛЕМЫ" и
  "УЛУЧШЕНИЯ" review (см. SCOPE-LOCK ниже).
- Не Glob "посмотреть как у нас принято" — review даёт конкретику.
- Если требуется >8 Read — review слишком объёмное, лучше returns
  как `status: "waiting_pm"` для разбиения.

═══════════════════════════════════════════
SCOPE-LOCK (OPS-034) — ОБЯЗАТЕЛЬНЫЕ ПРАВИЛА
═══════════════════════════════════════════

1. РАЗРЕШЕНО:
   - Изменить только те file:line, которые названы в секциях
     "КРИТИЧНЫЕ ПРОБЛЕМЫ" и "УЛУЧШЕНИЯ" review.
   - Изменить связанные с ними файлы ТОЛЬКО если изменение в file:line
     требует обновления (например, если ревью сказало "rename Session
     to UserAccount", изменения коснутся всех мест где упомянут Session).
   - Добавить недостающие тесты, если они названы в "Тесты: X/10".
   - Обновить documentation comments (//) если меняешь сигнатуру.

2. ЗАПРЕЩЕНО:
   - Рефакторинг кода, НЕ упомянутого в ревью. Даже если видишь
     "плохой код" в соседнем файле — не трогай его. Заведи DEBT
     отдельным TASK через /pdlc:debt.
   - Изменение архитектурных решений (контракты API, шейпы данных,
     паттерны) если ревьюер этого явно не запросил.
   - Замена библиотек/зависимостей.
   - Переименование функций/файлов вне scope замечаний.
   - "Заодно почищу" — нет, не "заодно". Только то, что в ревью.

3. PRE-COMMIT VERIFICATION:
   Перед `git commit` запусти:

       git diff --stat HEAD

   Сосчитай количество ИЗМЕНЁННЫХ файлов. Сверь с ревью:
   - Если в ревью названо ≤3 file:line, а ты меняешь >5 файлов —
     STOP, проверь что ты не вышел за scope. Откати лишнее.
   - Если в ревью названо ≤10 file:line, а ты меняешь >15 файлов —
     STOP, аналогично.

4. POST-COMMIT VERIFICATION:
   После коммита посмотри `git log --stat -1`. Если изменения
   охватывают файлы вне scope — НЕ push. Сделай `git reset --soft HEAD~1`,
   откати лишнее, перекоммить.

═══════════════════════════════════════════
АЛГОРИТМ
═══════════════════════════════════════════

1. Read tool на каждый файл, упомянутый в ревью (минимум 1 раз).
2. Примени ТОЛЬКО конкретные правки из ревью. Один комментарий в
   ревью = одна логическая правка в diff.
3. Запусти тесты проекта (knowledge.testing.testCommand). Если падают —
   убедись, что ИМЕННО твои правки их сломали; иначе зафиксируй как
   pre-existing failure в `learnings`.
4. Pre-commit verification (см. выше) — сосчитай файлы, проверь scope.
5. Сделай коммит: [{TASK-ID}] Address review feedback: {summary в 1 строке}
   <!-- # OPS-010: это коммит вида `improvement`.
   В этот же commit-staging бандли ЛЮБЫЕ отложенные правки frontmatter
   TASK.md (`status:`) и PROJECT_STATE.json task-bucket. НЕ делай
   отдельный status-only commit. НЕ пиши `lastUpdated`. -->
6. Post-commit verification (см. выше).
7. Push через verified-helper (OPS-028 — НЕ bare `git push`):
   `${PY:-$(command -v python3 || command -v python)} {plugin_root}/scripts/pdlc_vcs.py git-push --branch <branch> --project-root "${PDLC_WORK_DIR:-.}"`
   Если exit=2 — НЕ заявляй success. Верни `remote_lines` и `reason`
   из JSON-вывода, пометь итерацию как failed (PM получит `waiting_pm`).

═══════════════════════════════════════════
ВЕРНИ В КОНЦЕ
═══════════════════════════════════════════

JSON:
{
  "applied_fixes": [
    {"review_item": "Качество: 7/10 — long function in handler.py:45",
     "file": "src/api/handler.py", "line": 45,
     "change_summary": "extracted helper validateInput()"}
  ],
  "scope_violations": [],  // должно быть пусто; если non-empty — это твоё признание выхода за scope
  "files_changed": [...],
  "tests_run": {"passed": 23, "failed": 0},
  "commit_hash": "..."
}

⛔ Если `scope_violations` non-empty — НЕ push. Верни как `waiting_pm`
с описанием какие правки выходят за scope, чтобы PM решил.
```

