# GIGACODE.md

This file provides guidance to Qwen CLI when working with code in this repository.

---

# Polisade Orchestrator — Autonomous Development Framework

This project uses the **Polisade Orchestrator** plugin (part of the Polisade toolchain; technical id: `pdlc`) for running Claude as an autonomous development team. PM interacts through natural language or explicit `/pdlc:*` slash commands.

## Core Concept

The agent operates autonomously, executing a full development cycle: implement → test → PR → review → merge. PM intervenes only for business decisions, unclear requirements, or architectural choices with significant consequences.

## Natural Language Interface

PM can communicate in natural language. The agent recognizes intent and executes the appropriate command.

| PM Says | Intent | Command |
|---------|--------|---------|
| "Статус?" / "What's the project status?" | status | `/pdlc:state` |
| "Кнопка не работает" / "Button broken" | defect | `/pdlc:defect` |
| "Нужен экспорт в PDF" / "Need PDF export" | feature | `/pdlc:feature` |
| "Новый модуль аналитики" | prd | `/pdlc:prd` |
| "Поменяй конфиг" / "Update config" | chore | `/pdlc:chore` |
| "Надо отрефакторить" / "Need to refactor" | debt | `/pdlc:debt` |
| "Какую библиотеку выбрать?" | spike | `/pdlc:spike` |
| "Работай" / "Continue" | continue | `/pdlc:continue` |
| "Что ждёт моего ответа?" | unblock | `/pdlc:unblock` |
| "Какие вопросы открыты?" / "Open questions?" | questions | `/pdlc:questions` |

If intent is ambiguous, ask a clarifying question.

## Three Work Levels

### 1. Large Initiatives (epics, new modules)
```
/pdlc:prd → /pdlc:spec → /pdlc:design → /pdlc:roadmap → /pdlc:tasks → /pdlc:continue
                              (опционально)
```

`/pdlc:design` — опциональный шаг для создания doc-as-code артефактов (C4 диаграммы, ER, OpenAPI, ADR, glossary). Запускай для новых модулей, архитектурных переписываний, перед передачей SPEC другой команде. Для простых фич можно пропускать.

### 2. Regular Features
```
/pdlc:feature → /pdlc:tasks → /pdlc:continue
              ↘ /pdlc:spec (if complex) → /pdlc:tasks → /pdlc:continue
```

### 3. Bugs, Tech Debt, Chores
```
/pdlc:defect → auto-creates TASK → /pdlc:continue
/pdlc:debt   → регистрация (без TASK по умолчанию)
             ↘ --task или /pdlc:tasks DEBT-XXX → TASK → /pdlc:continue
/pdlc:chore  → CHORE + TASK → /pdlc:continue
             ↘ --no-task → только CHORE (регистрация)
```

**IMPORTANT:** `/pdlc:implement` accepts ONLY `TASK-XXX`. BUG creates linked TASK
automatically. DEBT creates TASK only on opt-in (`--task` flag or
`settings.debt.autoCreateTask: true`). CHORE creates TASK by default;
`--no-task` opts out.

## Full Autonomous Cycle

**⛔ CRITICAL: `/pdlc:implement` and `/pdlc:continue` behave DIFFERENTLY!**

| Aspect | /pdlc:implement | /pdlc:continue |
|--------|-----------------|----------------|
| Tasks count | **ONE** | All ready |
| After merge | **STOP** | Next task |
| Use case | Controlled execution | Autonomous work |
| PM control | After each task | Only when blocked |

### Cycle for ONE task (/pdlc:implement)

> **Note:** `/pdlc:continue` has its own cycle definition and may not yet
> support TDD-first. A separate redesign is planned.

```
1. IMPLEMENT → Create branch
   • If testing.strategy: "tdd-first" (default):
     1a. TEST-FIRST → Failing tests from AC/Gherkin, RED CHECKLIST, commit
     1b. CODE → Implement to pass tests, SELF-REVIEW CHECKLIST, commit
   • If testing.strategy: "test-along":
     Code + unit tests simultaneously, SELF-REVIEW CHECKLIST, commit
2. REGRESSION TEST → Run ALL project tests, fix if failing, repeat
3. CREATE PR → Push branch, create PR, status → review
4. QUALITY REVIEW → Independent review (auto-detected: Codex CLI if installed, otherwise current agent CLI via `self`)
   → Reviewer scores PR diff vs TASK requirements (1-10)
   → Score >= 8: PASS → merge
   → Score < 8: IMPROVE → improvement subagent fixes → re-review (max 2 iterations)
   → After 2 iterations with score < 8: STOP → waiting_pm (PM decides next step)
   → If no reviewer CLI found (codex / claude / gigacode) → STOP with diagnostics
5. /pdlc:implement: STOP
   /pdlc:continue: NEXT TASK → Continue to next ready task
```

**⛔ CRITICAL: Status `done` is ONLY set after PR merge!**

| Step | Task Status |
|------|-------------|
| After code written | `in_progress` |
| After PR created | `review` |
| After PR merged | `done` |

**Do NOT skip steps. Do NOT set `done` early. Complete the FULL cycle for each TASK.**

**Stop for:**
- `waiting_pm` (PM decision needed)
- `blocked` (unresolvable technical issue)
- `/pdlc:implement`: after merge of ONE task (STOP)
- `/pdlc:continue`: all tasks done

**Auto-fix (don't stop for):** Failing tests, review comments, merge conflicts.

## Subagents Architecture

Commands `/pdlc:spec`, `/pdlc:roadmap`, `/pdlc:tasks`, `/pdlc:implement` launch isolated subagents with clean context.

| Command | System Role | Purpose |
|---------|-------------|---------|
| `/pdlc:spec` | Technical Specification Architect | Create SPEC from PRD/FEAT |
| `/pdlc:design` | Solution Design Architect | Create doc-as-code design package (C4/ERD/OpenAPI/ADR/glossary) from PRD or SPEC |
| `/pdlc:roadmap` | Product Delivery Roadmap Architect | Create PLAN from SPEC |
| `/pdlc:tasks` | Roadmap Item Planner | Create TASKs from PLAN/SPEC/FEAT/BUG/DEBT/CHORE |
| `/pdlc:implement` | Developer | Implement code from TASK |
| `/pdlc:review-pr` | Independent Quality Reviewer (external CLI or `self`) | Review PR vs TASK, score & improve |
| `/pdlc:review` | Second Opinion Reviewer (external CLI or `self`) | Advisory review of TASK quality |

**Quality Review Loop:** After PR creation, reviewer (Codex CLI by default, or current agent's CLI with `self` flag) independently reviews the output against source requirements. Score >= 8 passes; score < 8 triggers improvement + re-review (max 2 iterations). If reviewer CLI is not available → STOP with diagnostics and installation instructions.

Knowledge flows between subagents via `.state/knowledge.json`.

## Subagent Tool-Call Budget (OPS-038)

Subagents run inside Node.js-based CLIs (the Qwen CLI agent, Qwen, GigaCode).
These CLIs have a known upstream issue (claude-code#2629, gemini-cli#5950,
nodejs/undici#3157): each Read/Glob/Bash tool call adds an `abort` listener
to a long-lived AbortSignal but does NOT remove it. After ~10-11 tool calls,
Node.js emits `MaxListenersExceededWarning`. After enough accumulation,
the subagent process can be `terminated` mid-run (real-world incident
on Polisade 2026-04-29).

This is **not Polisade's bug** — it's the CLI runtime. But Polisade can
mitigate it.

**Hard rule for subagent prompts:**

Every subagent prompt MUST include an explicit tool-call budget:

```
TOOL CALL BUDGET: maximum 8 Read/Glob/Bash operations.
If you need more — return status: "blocked" with `learnings`
explaining why context was insufficient. DO NOT exceed the budget.
```

Why 8: warning fires at 11. Budget of 8 leaves headroom for the CLI's
internal calls (HTTP, etc.) and edits like `Write`/`Edit` that may also
add listeners.

**Why subagents typically need many tool calls:**
- Re-reading SPEC/PRD/knowledge files because main agent didn't pre-build context
- Glob'ing the repo to understand structure
- Reading multiple unrelated files "to look around"

**What the main agent should do INSTEAD of letting subagent burn tool calls:**
- Pre-build sliced context via `pdlc_context.py` (1 tool call for subagent
  to Read the JSON, vs. 5+ to assemble it from scratch)
- Pass exact file paths in the prompt — subagent reads those, doesn't Glob
- Pass exact code excerpts inline if they fit (saves a Read)

If a subagent legitimately needs >8 tool calls, the TASK is too large —
decompose further, don't push the budget.

## Subagent Failure Handling (CRITICAL — OPS-037)

If a subagent fails (`terminated`, returns invalid JSON, or hits
`MaxListenersExceededWarning` followed by termination), the main agent
MUST follow the failure protocol:

1. **Log diagnostic** to PM (compact 1-3 lines).
2. **One retry** with reduced context (e.g. `--max-glossary-terms 10`,
   add `LIMIT_TOOL_CALLS: 8` to prompt).
3. **If retry also fails** → return `waiting_pm` with explicit
   options for PM to decide.

⛔ **FORBIDDEN:**
- "Try without subagent, the task is simple" — NEVER bypass the
  subagent because it failed. The skill's value comes from the
  subagent doing isolated, validated work. Manual fallback skips
  validation, context, and `pdlc_check.py tasks-graph`.
- More than one retry. Two failures → PM gate, full stop.
- Direct `Write`/`Shell`/`mkdir` to create artifacts that should be
  produced by a subagent. If subagent didn't run — task is not done,
  this is a valid outcome.

This applies to ALL skills that launch subagents: `/pdlc:tasks`,
`/pdlc:implement`, `/pdlc:spec`, `/pdlc:roadmap`, `/pdlc:design`,
`/pdlc:review-pr`, `/pdlc:review`.

## Portable Shell (CRITICAL — OPS-037)

Skills run on macOS, Linux, and Windows (via Git Bash / WSL). All
shell commands MUST be POSIX-compatible. Platform-specific syntax
breaks the workflow on the wrong OS.

⛔ **FORBIDDEN:**
- `2>nul` / `2>NUL` — Windows cmd-only. Use `2>/dev/null`.
- `cmd /c`, `powershell -c` — Windows-only. Use bash directly.
- Backslash paths in commands (`C:\Users\me`) — use forward slashes
  (`C:/Users/me`) which work on Windows in POSIX shells too.
- `set VAR=value` — cmd-only. Use `VAR=value` or `export VAR=value`.
- `dir /s`, `dir /b /s` — Windows recursive listing (OPS-050).
  May silently traverse Recycle Bin, mounted drives, or system dirs
  and dump thousands of irrelevant lines into context. Use POSIX
  alternatives with explicit scope: `find tasks/ -type f`,
  `find . -maxdepth 3 -name "*.md" -not -path "./.git/*"`.

⛔ **NEVER recursive listing without explicit scope** — any `find .`
or `ls -R` or equivalent without `-maxdepth N` AND without `-not -path`
exclusions for system dirs (`./.git`, `./node_modules`, `./.worktrees`,
`./dist`, `./target`) is a high-risk anti-pattern. Real-world incident
2026-05-06: `dir /b /s` in `/pdlc:init` traversed `C:/$RECYCLE.BIN/`,
returned 5960+ lines of garbage from deleted Java/Scala projects.

✅ **CORRECT:**
- `mkdir -p path/to/dir` (idempotent on all platforms)
- `rm -f file` (silent if missing)
- `command 2>/dev/null` (suppress stderr)
- `if [ -d "tasks" ]; then ...; fi` (POSIX test)

⛔ **PREFER tools over shell:** Most file ops should use `Write` /
`Read` / `Glob` / `Grep` / `Edit` tools, not shell commands. Tools
work cross-platform. Use shell ONLY for git, build, and test commands.

Full reference: `skills/tasks/references/portable-shell.md`.

## VCS Error Recovery — No Loop Rule (CRITICAL — OPS-041)

When ANY VCS operation (REST API, MCP server, gh CLI, git CLI to remote)
returns an error that indicates configuration / state mismatch — NEVER
loop. Go straight to `waiting_pm`.

**Errors that trigger this rule:**
- 404 / "not found" / "does not exist"
- 401 / 403 / "unauthorized" / "auth failed" / "permission denied"
- "branch ... not found" / "no such branch"
- Network timeout after 1 retry

⛔ **FORBIDDEN:**
- Attempting list-branches / get-repo / discovery calls to figure out the
  correct name yourself
- Retrying with altered parameters more than once
- Switching transport mid-flight ("REST didn't work — try MCP" or vice
  versa) without explicit PM direction

✅ **ALLOWED:**
- One retry with identical parameters (transient network/timeout)
- Reading `git remote -v` / `git branch -r` ONCE (local git is not a
  remote VCS call — does not loop)

The `waiting_pm` message must contain: VCS error code/type, manual fallback
URL (if branch was pushed), what PM should check (token, default branch
name, project access), and command to resume (`/pdlc:unblock TASK-XXX` or
`/pdlc:doctor --vcs`).

This applies to ALL skills doing VCS operations: `/pdlc:implement`,
`/pdlc:continue`, `/pdlc:review-pr`, `/pdlc:pr`.

Real incident: 2026-04-30 (project `promissory_note`) — agent looped 10+
times through MCP `bb_list_branches` after 404 on `main` branch, until
the Qwen CLI agent's built-in loop detection halted execution. Cost: tokens +
PM trust. Fix: this rule.

## API Errors and Resume (OPS-042)

Long-running `/pdlc:*` operations occasionally hit `[API Error: terminated]`
or similar transport-level failures from Anthropic API. These are **not
Polisade bugs** — they're inherent to any cloud LLM. The agent process
stops mid-turn, and the user types `продолжи` (or "continue") to resume.

Polisade can't prevent terminated. What it CAN do — and DOES —
is ensure that resuming after terminated is **idempotent**: replaying
a step that was already half-completed must not duplicate work, corrupt
state, or skip required actions.

**Rules every skill follows when re-entering after `продолжи`:**

1. **State is the source of truth** — re-read `PROJECT_STATE.json` and
   TASK frontmatter before any action. Don't trust in-memory beliefs
   about "I just did X".
2. **Idempotent file creation** — before `Write` to a file, `Read` it
   first if it might already exist. Idempotent merge if content matches
   what would be written; halt and ask PM if content differs.
3. **Idempotent state update** — before transitioning a TASK to a new
   status, check current status. If already at target — skip silently.
   If at unexpected source state — halt and ask PM.
4. **Idempotent git ops** — before `git add` or `git commit`, check
   `git status --porcelain`. If working tree is empty — skip commit
   silently. If there are unexpected changes — halt and ask PM.
5. **Idempotent subagent launch** — before launching subagent for a
   TASK, check if previous subagent run left any artifacts (commit,
   file, state update). If yes — treat as completed, skip. If partial —
   halt and ask PM.
6. **Stale cache cleanup is opportunistic** — `.pdlc/cache/tasks-staging`
   and similar dirs are cleaned at end of skill. If found at start —
   that's a sign of previous interruption. Inspect, don't auto-delete.

**When PM suspects post-resume drift:**

After `продолжи`, if anything looks off (wrong status, missing PR,
duplicated commit), PM runs:

```
/pdlc:doctor --resume-check
```

This runs 5 checks (OPS-042):
- `resume_orphan_files` — TASK files on disk not in PROJECT_STATE
- `resume_status_drift` — frontmatter status ≠ state bucket
- `resume_pr_without_url` — TASK in review without pr_url despite git commits
- `resume_stale_cache` — leftover `.pdlc/cache/` files >1h old
- `resume_uncommitted_in_worktrees` — in_progress TASK with uncommitted changes

Output is purely advisory — never auto-fixes. PM decides per-finding.

This rule applies to `/pdlc:tasks`, `/pdlc:implement`, `/pdlc:continue`,
`/pdlc:review-pr`, and any skill that does multi-step state mutations.

## Structured Tracing (OPS-043)

Long-running `/pdlc:*` commands write structured events to
`.pdlc/traces/<command>-<timestamp>.jsonl`. This is the primary
diagnostic tool when something goes wrong — instead of asking PM
for terminal screenshots, you can grep through trace files.

**The agent is RESPONSIBLE for emitting trace events at key points.**
Don't trace every tool call — that's noise. Trace **decisions** and
**boundaries** (subagent boundaries, retry decisions, PM gates,
verification outcomes).

**Mandatory trace points** for `/pdlc:tasks`, `/pdlc:implement`,
`/pdlc:review-pr`:

1. `command_started` — at skill entry, with args
2. `context_built` — after building sliced JSON context (with token
   estimate if known)
3. `subagent_prompt_sent` — before each subagent launch (with
   `subagent_id`, prompt size)
4. `subagent_completed` / `subagent_failed` — after each subagent
   returns (with `decision` if action follows: retry, waiting_pm, etc.)
5. `verification_passed` / `verification_failed` — after each major
   check (TDD ordering, DAG validation, scope-lock, etc.)
6. `pm_gate` — when stopping for PM input (with reason)
7. `pm_resumed` — at skill re-entry after `продолжи` (idempotency
   check follows)
8. `command_completed` / `command_failed` — at skill exit (with
   `decision`: pr_created, blocked, waiting_pm, etc.)

**How to emit (bash from skill):**

```bash
PY=${PY:-$(command -v python3 || command -v python)}
$PY {plugin_root}/scripts/pdlc_trace.py log \
    --phase subagent_completed \
    --command implement \
    --task-id "${TASK_ID}" \
    --subagent-id "sa-1" \
    --decision proceed \
    --tokens-used 4500 \
    --payload '{"status":"code_complete","files_changed":3}' \
    --project-root "${PDLC_WORK_DIR:-.}"
```

Trace is **best-effort** — failures don't break the workflow. If the
trace command exits non-zero, ignore and continue.

**How to inspect (PM):**

```bash
PY=${PY:-$(command -v python3 || command -v python)}
# Last 20 events from latest trace
$PY scripts/pdlc_trace.py tail

# All trace files with size and event count
$PY scripts/pdlc_trace.py list

# Pretty-print a specific trace
$PY scripts/pdlc_trace.py show implement-20260430-125333.jsonl

# Grep for a specific TASK across all traces
grep "TASK-001" .pdlc/traces/*.jsonl

# Grep for failures
grep -E '"phase":"(subagent_failed|verification_failed|command_failed|error)"' .pdlc/traces/*.jsonl
```

**Human-readable debug log (OPS-052):**

When PM wants "all the debug output in a single file" (rather than
JSON in `.pdlc/traces/`), use:

```bash
PY=${PY:-$(command -v python3 || command -v python)}
# Convert latest trace to human-readable log
$PY scripts/pdlc_trace.py log-view

# → Wrote N events to <project-root>/debug_pdlc.log
#
# Output format example:
# # === Trace: implement-20260430-125333.jsonl ===
#   [12:53:33] command_started      /pdlc:implement TASK-001
#   [12:53:33] context_built        /pdlc:implement TASK-001
#   [12:53:33] subagent_prompt_sent /pdlc:implement TASK-001 sa=sa-1
#   [12:53:42] subagent_failed      /pdlc:implement TASK-001 sa=sa-1 → retry reason=terminated tool_calls_before_fail=18
#   [12:54:00] subagent_completed   /pdlc:implement TASK-001 sa=sa-2 tokens=4500 status=code_complete

# Include all traces, not just the latest:
$PY scripts/pdlc_trace.py log-view --all

# Custom output path:
$PY scripts/pdlc_trace.py log-view --output /tmp/my-debug.log
```

⚠️ **Important caveat:** `debug_pdlc.log` is the closest Polisade can
get to "everything from terminal in a file". It contains **all
decisions and structured events** the plugin emitted — but **NOT the
raw terminal output** of the host CLI (the Qwen CLI agent, GigaCode, Qwen).
Tool failures shown in the terminal (e.g., "ReadFile: File path must
be within workspace") are NOT captured here unless the skill emits a
trace event for them. This is a fundamental architectural limit —
Polisade is markdown skills + Python helpers, not a terminal multiplexer.

**Privacy note:** trace files contain prompt sizes, decisions, and
small payload dicts — but NOT full prompts or full diffs. They're
safe to share with PM teams. Keep them out of git via `.pdlc/` in
`.gitignore` (already there).

## Anti-Rumination Guard (OPS-046)

When the agent encounters **conflicting state signals** between
`.state/PROJECT_STATE.json`, TASK frontmatter, and `git log` /
`git worktree list` — these are **three independent sources of truth**
that can desync after interruptions, manual edits, or multi-worktree
work.

⛔ **DO NOT** ruminate trying to resolve the conflict logically
("but... however... so... but then..."). This is a known LLM
anti-pattern that produces 5-10 paragraphs of self-talk without
progressing toward action.

✅ **DO** stop and emit `waiting_pm` with a **structured comparison**
of the three sources, listing concrete mismatches.

**Self-check trigger:** if your reasoning contains 3+ instances of
"but...", "however...", "so...", "but I shouldn't...", you are in a
rumination loop. STOP, emit waiting_pm with what you have so far.

Skill-specific implementations:
- `/pdlc:continue` — see SKILL.md § «State Reconciliation Guard (OPS-046)»
- `/pdlc:implement` — applies via OPS-042 idempotency rules + this guard

Real-world incident (2026-05-04): after context overflow + restart on
project `promissory_note`, agent looped 8 pages of self-dialogue
between TASK-001..005 without emitting waiting_pm. PM had to manually
interrupt.

## Promised Handoff Discipline (OPS-055)

When the agent's reasoning contains language like:
- "**нужно** уточнить у PM"
- "**надо будет** спросить у PM"
- "**стоит** проверить с PM"
- "PM should clarify"
- "I'll ask PM about this"
- "это требует подтверждения PM"

— this is a **promise of handoff** that the agent often **fails to
deliver**. The narrative says "we'll ask PM", but the actual
implementation step gets skipped — agent moves to the next task,
PM never sees the question.

⛔ **DO NOT** treat such phrases as commentary about future actions.
**They are commitments that must be honored immediately.**

✅ **When you write any of those phrases in your reasoning, STOP
immediately and emit a structured `waiting_pm` block** before
continuing with anything else:

```
═══════════════════════════════════════════
/pdlc:<skill> → waiting_pm: clarification needed
═══════════════════════════════════════════

Контекст: <where in the process this came up>

Вопрос: <the actual question>

Варианты ответа (если применимо):
  1 — <option 1>
  2 — <option 2>
  3 — <other / explain>

Я приостанавливаю работу до вашего ответа. /pdlc:unblock
═══════════════════════════════════════════
```

Don't wrap the question into a "by the way" mention later. Don't
collect multiple questions and ask them at the end. Each "нужно
уточнить" → its own waiting_pm at the moment it arises.

**Real-world incident (2026-05-08):** during `/pdlc:tasks` decomposition
agent wrote "нужно будет уточнить у PM достаточно ли только тестов с
каунтами или нужно что-то ещё". PM never saw the question — agent
proceeded to generate TASKs assuming "yes, just count tests". When
implementation finished, PM had to manually request additional checks.
The handoff mention was treated as future-tense narration, not a
commit-to-act.

**Self-check:** at the end of any `/pdlc:*` skill turn, scan your own
output for the phrases above. If found and you didn't emit waiting_pm
— that's a bug, fix it before completing the turn.

## Open Questions Block Next Steps (OPS-062)

When a `/pdlc:*` skill creates an artifact (PRD, SPEC, FEAT, DESIGN,
PLAN, BUG, DEBT, CHORE, SPIKE, TASK), and that artifact contains
**open questions** (Q-XXX entries in frontmatter, or any text
that asks PM something), the agent MUST stop in `waiting_pm` BEFORE
suggesting next steps.

⛔ **Wrong (this is what happened in 2026-05-08 design incident):**

```
✓ DESIGN-002 created with 6 artifacts.

Open questions for PM:
  Q-001: Need partitioning?
  Q-002: histDepth?
  Q-003: archive vs daily load?

Next steps:
  - /pdlc:roadmap SPEC-002 — create plan
  - /pdlc:tasks SPEC-002 — decompose directly
```

PM gets confused — **what should they do first**, answer questions
or run next-step commands? The questions imply blocking, but next
steps imply ready-to-go. Mixed signals.

✅ **Right:**

```
✓ DESIGN-002 created with 6 artifacts.

═══════════════════════════════════════════
/pdlc:design → waiting_pm: 3 open questions
═══════════════════════════════════════════

Q-001: Need partitioning for dm_product? If yes, by which field?
Q-002: What history depth (histDepth) is required?
Q-003: Archive reload (per period) or only daily load?

Я приостанавливаю работу до ваших ответов.
Запустите /pdlc:unblock когда готовы продолжить.
═══════════════════════════════════════════
```

Notice: **NO next steps section** when there are open questions. After
PM runs `/pdlc:unblock` and answers, THEN the agent (in unblock skill)
suggests next steps based on the answers.

**Decision rule:**

```
IF artifact.frontmatter.open_questions is non-empty
   OR artifact body contains "Вопрос:" / "Question:" / "Q-NNN:" markers:
    emit waiting_pm with structured Q-list
    DO NOT include "Next steps" section in output
ELSE:
    proceed normally with next_steps suggestions
```

**Self-edits also block.** When an action requires PM choice (e.g.,
"unmapped requirements detected — should I add NFR-002, NFR-004 to
manifest.yaml?"), don't make the edit unilaterally. First emit
waiting_pm with the proposed change, wait for PM approval, then
edit. Exception: trivially obvious fixes (typos, syntax errors,
schema-required fields with one valid value) can proceed without
asking.

This rule applies to ALL `/pdlc:*` skills that produce artifacts:
prd, spec, design, roadmap, tasks, feature, defect, debt, chore, spike.

Real-world incident (2026-05-08 — same as OPS-055):
`/pdlc:design SPEC-002` produced DESIGN-002 with 3 open questions
(Q-001..Q-003) but did NOT stop — also auto-edited manifest.yaml to
add NFR-002, NFR-004 without asking. PM had to manually re-prioritize:
"answer questions first, then continue, not the other way around".

## Decomposition Integrity (OPS-064)

When the agent encounters a TASK in `readyToWork` whose `depends_on`
TASKs are NOT yet `done`, **STOP**. Do not rationalize the discrepancy
("это документация, можно параллельно", "low-priority задача") and
proceed unilaterally — that's a rumination loop in disguise (OPS-046).

The same applies if the agent's own TodoWrite output contains phrases
like "не должен быть в readyToWork", "ошибка декомпозиции", "это
исключение" — **self-detection is not self-authorization**.

Always emit `waiting_pm` with a structured comparison of the
decomposition mismatch and 3-4 concrete options for PM to choose
from. Skill-specific implementation: `continue/SKILL.md` §
«Decomposition Integrity Guard (OPS-064)».

Real-world incident (2026-05-08): `/pdlc:continue` saw TASK-007 in
`readyToWork` with deps=[TASK-003..006] all `draft`. Agent decided
"documentation TASK can run in parallel", executed it without
PR/review cycle, set status=done. PM never authorized this; the
decomposition was actually incorrect.

## PR-without-Review Barrier (OPS-068)

When `/pdlc:continue` (or any pipeline that creates PRs) successfully
calls `pdlc_vcs.py pr-create`, the agent MUST proceed **immediately**
to `/pdlc:review-pr` in the same tool-call sequence, without:
- returning control to PM
- moving to the next TASK
- announcing "PR created, waiting for PM"
- asking PM "want me to run review?"

**Skipping review is a flow violation**, not a delegation. The agent
admitting "I didn't run review-pr" **after the fact** doesn't undo
the broken pipeline.

`knowledge.workflow.auto_merge = false` blocks **merge only**, not
review. Review is always mandatory; it produces actionable feedback
either way.

Skill-specific implementation: `continue/SKILL.md` §
«PR-without-review barrier (OPS-068)».

Real-world incident (2026-05-09): agent created PR #21 in `/pdlc:continue`
for TASK-003..006, then asked PM "want me to run review?" — that
question itself is the bug. Pipeline says: after pr-create →
review-pr, no PM checkpoint between.

## Branch Discipline (OPS-072)

The orchestrator works on **the current branch** (whatever branch PM is
on when they invoke a skill — often a feature/integration branch like
`test_pdlc`, NOT `master`/`main`).

Rules:
1. **All work happens on the current branch.** Do not assume `master`/`main`
   is the working branch.
2. **TASK branches merge into the CURRENT branch, not master.** When a
   skill creates a per-TASK branch (worktree or inplace), the merge target
   is the branch PM was on at invocation time — capture it at start as
   `BASE_BRANCH=$(git rev-parse --abbrev-ref HEAD)` and merge back to it.
3. **Clean up TASK branches after merge.** Once a TASK branch is merged
   into the current branch, delete it (`git branch -d <task-branch>` +
   remote delete if pushed) to avoid repo clutter. This is the ONE place
   the agent may delete branches — TASK branches it created, after their
   merge into the working branch.
4. **Final deliverable → PR into master.** When the working branch
   accumulates all completed work, the FINAL step is a PR from the working
   branch into `master`/`main`, with code review of that PR (both code
   quality AND requirements compliance — OPS-058 traceability axis).
5. **PM merges the final master PR.** The agent NEVER merges into
   master/main itself. It opens the PR, runs review, then STOPS —
   `knowledge.workflow.auto_merge = false` applies doubly to master.

⛔ The agent NEVER merges or pushes directly to master/main. It NEVER
runs `git checkout master && git merge` to land work. The master PR is
PM's to approve and merge.

This refines OPS-001 (expected-branch invariant) and OPS-056 (PM-gated
merge) with explicit "current branch, not master" + cleanup semantics.

Real-world basis (2026-05-09): PM works on `test_pdlc` branch; TASK
branches were at risk of targeting master and cluttering the repo.

⛔ **OPS-076 — branch nesting confusion (2026-06-01 incident).** The
agent started correctly (TASK branch → PR into base branch) but then
drifted: created an extra "feature" branch and began making PRs from
TASK branches INTO that feature branch, and even into OTHER task
branches. Hard rules to prevent this:
- NEVER create an intermediate "feature" branch. Base = the branch PM
  was on at invocation.
- Every TASK branch forks from `$BASE_BRANCH`, never from another TASK
  branch or a feature branch.
- Every TASK PR targets `$BASE_BRANCH`, never another TASK branch.
- Verify the PR target == `$BASE_BRANCH` before each `pr-create`. If
  it isn't, STOP — you've drifted.

## Data Mart Testing Pipeline (OPS-070)

For Spark/DWH data-mart projects (`knowledge.dataMartTesting.enabled
== true`), `/pdlc:implement` runs an extra phase after a datamart-TASK
passes review: generate data quality tests.

⚠️ **Hadoop-only (OPS-074).** DQ tests are generated ONLY for **Hadoop**
data marts. Detection is by **code autodetect** (Spark/HDFS markers:
`org.apache.spark`, `spark.read`, `DataFrame`, `.parquet`, `hdfs://`,
etc.) — not a flag, not a PM question. Non-Hadoop marts skip the whole
phase.

⛔ **SQL-only restrictions (OPS-074).** DQ test generation:
- Produces ONLY SQL scripts (CSV with SQL inside)
- NEVER edits existing Scala files (esp. `autotests.scala`)
- NEVER creates shell scripts (`.sh`/`.bat`/`.ps1`)
- NEVER creates Python/Scala/executable test code

- **DQ tests** — parse the S2T Excel "Target columns" sheet, emit 4 test
  types (DataExist, Mandatory NOT-NULL, Double-PK, Broken-links FK→PK)
  as CSV. Two files differing only by schema: `<dm>_tests.csv` (RDT) and
  `<dm>_tests_ift.csv` (IFT). Output to `dataMartTesting.autotests_dir`.

⚠️ **Test data is a SEPARATE command (OPS-075).** Test-data generation
is NOT part of the cycle anymore — it's the standalone `/pdlc:create-data`
command, run manually by PM. `/pdlc:implement` does NOT generate test
data; it may only remind PM to run `/pdlc:create-data`.

⚠️ **Standalone DQ-test generation (OPS-079).** `/pdlc:create-tests` is
the entry point for generating DQ tests OUTSIDE the implement cycle —
e.g. when the marts are already implemented and the in-cycle hook can't
fire again. It interactively enables `dataMartTesting` and fills missing
config (s2t_excel_path etc.) with PM consent (OPS-078 pattern).

⚠️ **No silent skip (OPS-079).** If the implement hook detects a Hadoop
mart but `dataMartTesting.enabled == false`, it must NOT skip silently —
it adds one line to the output: "Hadoop mart detected, DQ tests not
generated (enabled=false). Run /pdlc:create-tests". Real-world basis
(2026-06-01): PM completed a full cycle unaware the DQ-test step existed.

Engine: `scripts/pdlc_datamart_tests.py` (config-driven via
knowledge.dataMartTesting). Skill-specific flow: `implement/SKILL.md`
§ «Data Mart Testing (OPS-070)»; `create-data/SKILL.md` for test data.

Result analysis (after the mart actually runs on the IFT cluster) is a
SEPARATE manual command `/pdlc:check-tests` (OPS-071) — NOT part of the
autonomous cycle. It prompts PM for SSH params if config is incomplete
(OPS-078).

## Reviewer & VCS Provider (OPS-077)

At the start of `/pdlc:continue`, before the first PR, ensure a
**reviewer id** is known: read `knowledge.workflow.reviewer_id`; if
empty, ask PM once and persist it. Assign this reviewer on every PR.

VCS operations may optionally go through the **mcp-bitbucket** MCP server
(`knowledge.workflow.vcs_via_mcp == true`) instead of `pdlc_vcs.py`.
This is an OPTION, not a replacement — `pdlc_vcs.py` remains the fallback
and retains full functionality. mcp-bitbucket is convenient for reviewer
assignment and direct Bitbucket Server API access.

## Python-First Init (OPS-069)

`/pdlc:init` uses a **single Python entry point**: `pdlc_init.py --all`.
The agent does NOT improvise shell commands for scaffolding, template
copy, gitignore update, name set, or structure verification — all of
these are inside the Python script.

⛔ **Specifically forbidden** during /pdlc:init:
- `dir /s`, `dir /b /s` (Windows recursive — OPS-050 incident)
- `ls -R`, `find .` без `-maxdepth` (POSIX recursive)
- `[ -d X ]` chains (POSIX existence check)
- `wc -l` after directory listing
- `set VAR=... && if exist "%VAR%\..."` (cmd.exe scope — OPS-060)
- Improvised "verification" of any kind

✅ **Use** `python pdlc_init.py --verify` if explicit confirmation
needed.

This consolidates four prior fixes into one architectural solution:
- OPS-050 (recursive listing into Recycle Bin)
- OPS-051 (Read tool blocked for plugin paths)
- OPS-060 (cmd.exe variable scope)
- OPS-061 (python3 vs python on Windows)

Real-world incident (2026-05-09): even after OPS-060 (Python templates)
and OPS-067 (force status: ready), agent **still** ran `dir /b /s`
post-install for "structure verification" — pulled 6517 lines of
junk from `C:/Users/.NET v4.5 Classic` and `INetCache/Low/Content.IE5`
into context. OPS-069 removes the agent's authority to run
verification commands at all — only the script does it.

## Output Language Consistency (OPS-045)

Plugin works on projects with prose in either Russian or English (or
mixed). Subagents must keep output language consistent with the
**source artifact** (PRD/SPEC body), not with code identifiers.

**Detection rule (used by all subagents):** read first 500 chars of
prose from PRD/SPEC `body`; if Cyrillic > Latin → RUSSIAN, else
ENGLISH. If split is ~50/50 — default to RUSSIAN.

**Applied to:**
- TASK title and body (Description, Requirements, AC)
- Commit message Subject and Body
- Code comments (also follow project convention if existing comments)
- `learnings` strings in subagent JSON return

**NOT applied to:**
- Identifiers (TASK-XXX, FR-001, SPEC-002) — always English
- Technical terms (case class, SELECT, BIGINT, JSON, HTTP) — kept as-is
- File paths and URLs

**Forbidden:**
- Mixing languages within a single artefact ("## Описание" + "Based
  on the SQL...")
- Switching language between TASKs in one decomposition
- Using SQL/code language as signal for prose language

Real-world incident (2026-05-04): FEAT-002 with Russian PRD/SPEC got
TASKs in English because SQL columns were English. Inconsistency
broke grep workflow and confused PM.

## Operational Comments Language (OPS-051)

Beyond TASK/SPEC/PR content (covered by OPS-045), the **agent itself**
emits operational text during a `/pdlc:*` run:
- TodoWrite lists ("Check if initialized", "Create directory structure")
- Progress messages ("Now creating templates...")
- Diagnostic explanations ("I see that TASK-001 is in worktree...")
- Status updates between tool calls

This text is what PM **reads in the terminal**. If PM works in Russian
but the agent narrates in English — UX is broken regardless of artefact
quality.

**Rule:** the agent matches operational language to the **project
language** as detected by OPS-045 algorithm:
1. Read first 500 chars of project knowledge.json `project.name`,
   `project.description`, recent PRD/SPEC bodies
2. Cyrillic > Latin → operational language: RUSSIAN
3. Else → ENGLISH

**On the very first `/pdlc:init` run** (before any artefacts exist):
- Use the language of PM's input arguments to `/pdlc:init MyProject`
  (if `MyProject` is Cyrillic → Russian, else English)
- Or, if no arguments — match OS locale / fallback to RUSSIAN if
  the directory path contains Cyrillic / fallback to ENGLISH otherwise

**Examples (Russian project):**
```
✓  Проверка инициализации
✓  Создание структуры директорий
○  Копирование шаблонов из плагина
○  Обновление .gitignore
```

**Examples (English project):**
```
✓  Check if initialized
✓  Create directory structure
○  Copy template files
○  Update .gitignore
```

⛔ **Avoid:**
- Mixing languages in a single TodoWrite list
- Switching language mid-skill ("Reading file..." then «Файл прочитан»)
- Translating technical terms (`PROJECT_STATE.json`, `mkdir`, `git`,
  `worktree`) — they stay as-is in any language

This rule applies to ALL `/pdlc:*` skills, not only init.

## Finding TASK files by ID (OPS-054)

When a skill instructs the agent to "find/read TASK-XXX", the **full
filename** is NOT predictable from TASK ID alone. The slug part of
`tasks/TASK-XXX-<slug>.md` was chosen at decomposition time and is
NOT necessarily reflected in the SPEC body, FR text, or what the agent
might reasonably guess from context.

⛔ **Do NOT** construct a full path by guessing the slug:
```
× ReadFile {"absolute_path":"...\\tasks\\TASK-002-create-file-with-staging-source-table.md"}
   File not found
```

This wastes tool calls, produces "File not found" noise in the
terminal, and confuses PM about whether the file exists.

✅ **Use Glob first, then ReadFile** the matched path:

```
1. Glob 'tasks/TASK-002*.md' (in project root)
   → Found: tasks/TASK-002-implement-deposit-subquery.md
2. ReadFile 'tasks/TASK-002-implement-deposit-subquery.md'
```

This is the **only correct way** to read a TASK file by ID. Applies
to all `/pdlc:*` skills: continue, implement, review, doctor, sync,
state, etc.

**Exception:** if the agent already saw the full path in the same
conversation (e.g., `pdlc_check.py task_files_misplaced` finding,
or `git log --oneline` output mentioning the file), it can use that
exact path directly without Glob. Don't blindly Glob if you have
the exact path on hand.

**Real-world incident (2026-05-08):** in a successful `/pdlc:continue`
cycle, agent guessed `TASK-002-create-file-with-staging-source-table.md`
(based on SPEC text) and `TASK-003-add-collectd-rows-logic.md` —
both wrong. Real names were `TASK-002-implement-deposit-subquery.md`
and `TASK-003-implement-nso-sho-subquery.md`. Each guess produced a
visible `× ReadFile File not found`, then Glob recovered. Workflow
worked but PM saw spurious failures.

## Portable Python invocation (OPS-061)

⛔ **Don't call `python3` directly** in shell commands. On Windows
(GigaCode, Git Bash), the executable is usually `python` or `py`,
not `python3`. Hardcoding `python3` causes "command not found" and
forces the agent to fall back to inline LEGACY-mode pseudoprompts.

✅ **Use this cascade pattern** at the top of any bash block that
runs Python scripts:

```bash
PY=${PY:-$(command -v python3 || command -v python)}
$PY {plugin_root}/scripts/pdlc_check.py ...
$PY {plugin_root}/scripts/pdlc_context.py ...
```

How it works:
- `${PY:-fallback}` uses existing `$PY` if set (e.g. agent set it
  earlier in same shell), otherwise computes via `command -v`
- `command -v python3 || command -v python` returns first found
  executable path on PATH
- Works on Linux (python3 usually present), macOS (python3 always),
  Windows Git Bash (python.exe usually accessible as `python`)

**Real-world incident (2026-05-08):** `/pdlc:design SPEC-002` on
Windows GigaCode: agent ran `python3 pdlc_context.py`, command not
found, skill fell back to LEGACY inline-prompt mode (still worked,
but degraded experience and lost OPS-058 traceability data). After
OPS-061 fix, all 26 skills use the cascade pattern.

## Reading Plugin Reference Files (OPS-063)

⛔ **Don't use Read tool to read files inside the plugin directory.**

Plugin reference files like:
- `assets/tasks/references/subagent-prompts.md`
- `skills/design/references/output-formats.md`
- `skills/review-pr/references/reviewer-prompt.md`
- ... all `references/` subdirs in plugin

— live **outside the user's workspace**. On GigaCode (and similar
sandboxed runtimes), Read tool blocks them with:

```
File path must be within one of the workspace directories:
C:\Users\21271087\IdeaProjects\promissory or within the project temp directory:
...
```

This forces the agent to fall back: Glob in workspace finds nothing
(reference files aren't there), then either inlines a degraded
LEGACY prompt or improvises from memory. Both are bad.

✅ **Use shell `cat` / `type` instead:**

```bash
PY=${PY:-$(command -v python3 || command -v python)}
PLUGIN=${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}

# POSIX shells (Linux, macOS, Git Bash on Windows):
cat "$PLUGIN/assets/tasks/references/subagent-prompts.md"
```

Or to **inject** content into a subagent prompt variable:

```bash
REF=$(cat "$PLUGIN/skills/design/references/output-formats.md")
# Use $REF in the prompt template
```

**For `pdlc_context.py` — use the cascade with `$PY`** (see OPS-061):

```bash
PY=${PY:-$(command -v python3 || command -v python)}
JSON=$($PY "$PLUGIN/scripts/pdlc_context.py" for-task TASK-001)
```

This works because:
- `cat` is a shell builtin / system binary, not Read tool — no workspace check
- `python` is also a shell binary, not Read tool — no workspace check
- Both `cat` and `python` accept absolute paths to plugin internals
- The agent's Bash tool runs them in shell, which has full filesystem access

**Real-world incident (2026-05-08):** `/pdlc:design SPEC-002` tried
to ReadFile `assets/tasks/references/subagent-prompts.md` — blocked
by GigaCode workspace check. Glob in workspace returned no files
(correct, references are in plugin). Skill improvised LEGACY-mode
without consulting the reference, producing degraded subagent prompt.

After OPS-063 fix, the canonical pattern in skills is:
```bash
PLUGIN=${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}
cat "$PLUGIN/skills/<skill>/references/<ref>.md"
```

## Artifact Types

| Type | Purpose | When to Create |
|------|---------|----------------|
| **PRD** | Full requirements for large initiative | New module, epic |
| **FEAT** | Feature Brief | Regular feature |
| **SPEC** | Technical specification | Complex feature requiring design |
| **DESIGN-PKG** | Doc-as-code design package (C4, ERD, OpenAPI, ADR, glossary) | Architectural artifacts for new modules / handoff between teams |
| **PLAN** | Implementation plan with phases | Large work with dependencies |
| **TASK** | Atomic task | Always — this is the work unit |
| **BUG** | Defect description | Bugs (auto-creates TASK) |
| **DEBT** | Technical debt | Refactoring (optionally creates TASK via `--task`) |
| **CHORE** | Simple task | Config, cleanup (creates TASK by default; `--no-task` to opt out) |
| **SPIKE** | Research task | Technology choice, PoC |
| **ADR** | Architecture Decision Record | Architectural decisions |

## Requirement ID Scoping

FR/NFR идентификаторы **локально уникальны** в пределах своего источника (PRD, SPEC или FEAT), но **не глобально**. В проекте может быть несколько top-level requirement documents (PRD + несколько FEAT по версиям + несколько SPEC), и один и тот же номер — `FR-007` — может быть объявлен в каждом из них как разное требование.

### Формат ссылок

- **Composite (обязателен для cross-doc refs)**: `{DOC_ID}.FR-NNN` / `{DOC_ID}.NFR-NNN`.
  Примеры: `PRD-001.FR-007`, `FEAT-002.FR-007`, `SPEC-002.NFR-003`.
  Номер всегда 3-значный (`FR-007`, не `FR-7` и не `FR-07`). DOC_ID ∈ {PRD-NNN, SPEC-NNN, FEAT-NNN}.
- **Bare `FR-NNN`** разрешён только как id-объявление внутри самого документа-источника (`### FR-007 — …` в SPEC), либо как implicit scope «требование из parent документа текущего артефакта» — и только если в проекте **ровно один** top-level doc объявляет это FR.

### Где используется composite

- `tasks/TASK-*.md` → `requirements: [SPEC-001.FR-001, SPEC-001.NFR-002]`
- `docs/adr/ADR-*.md` → `addresses: [SPEC-001.FR-001]`
- `docs/architecture/DESIGN-*/manifest.yaml` → `artifacts[].realizes_requirements: [SPEC-001.FR-001]`
- `docs/architecture/DESIGN-*/<sub-artifact>.md` frontmatter → `realizes_requirements: [...]`

### Резолюция bare ссылок (implicit scope)

Если в frontmatter написан bare `FR-007`, plugin резолвит его по цепочке parent-документа:

- `TASK` → `parent` (PLAN или SPEC/PRD/FEAT/BUG/DEBT/CHORE). Если `parent: PLAN-XXX` — через `PLAN.parent` (канонически `SPEC-XXX`).
- `ADR` → первый элемент `related: [...]` с префиксом PRD-/SPEC-/FEAT-.
- `DESIGN` sub-artifact → `manifest.parent` пакета-контейнера.

### ⛔ Guard-rule для LLM: НЕ делай `grep -r FR-NNN`

Когда PM говорит «удали FR-07 из такого-то документа и все ссылки на него»:

1. **Сначала уточни, в каком документе** объявлено удаляемое FR.
2. **Не** делай `grep -r 'FR-07' .` по всему проекту и **не** предлагай удалить совпадения в других документах без явного согласия PM.
3. `FR-07` в `PRD-001` и `FR-07` в `FEAT-002` — это **разные требования**. Удаление одного не должно трогать другое.
4. Если в проекте используется composite (`PRD-001.FR-007`), для удаления pattern однозначен — можно спокойно grep'ить по полному id. Если же в проекте ещё встречается bare `FR-07` — сначала запусти `/pdlc:migrate --apply` (проставит scope-prefix для ambiguous), и только потом удаляй.

### Поддерживающие инструменты

- **`/pdlc:migrate --apply`** — канонизирует legacy 2-digit (`FR-07` → `FR-007`) и проставляет composite prefix для bare коллидирующих refs в существующем проекте. Идемпотентен.
- **`/pdlc:doctor --traceability`** — показывает матрицу по каждому top-level doc отдельно (`PRD-001.FR-007` vs `FEAT-002.FR-007`) и warning-секцию про ambiguous bare refs (non-blocking).
- **`pdlc_lint_artifacts.py`** — блокирует коммит (exit=1) при cross-doc bare reference на коллидирующий id.

## Status Machine

Polisade Orchestrator artifacts have **two distinct lifecycles** depending on type:

### Top-level requirement artifacts (PRD / SPEC / FEAT / DESIGN-PKG)

These are **living documents** (per ISO/IEC/IEEE 29148 §5.2.1) — they describe WHAT, not WHEN. They never become `done`; they get baselined and stay active as long as their downstream work runs.

```
draft → reviewed → ready → accepted
                     ↓
                  blocked / waiting_pm
```

- `draft` — being written
- `reviewed` — passed self-review (SPEC subagent score ≥ 8)
- `ready` — PM approved, downstream work (PLAN/TASK/DESIGN) may start
- `accepted` — baselined; multiple children created or implementation underway. Long-lived state.

⛔ Creating a child (PLAN, TASK, DESIGN-PKG) **does NOT close the parent.** SPEC/PRD/FEAT stay `ready`/`accepted` for the entire lifetime of their downstream work.

### Work-unit artifacts (TASK / BUG / DEBT / CHORE / SPIKE)

These are **closeable units of work** — they describe a single change that gets merged.

```
draft → ready → in_progress → review → done
              ↓           ↓       ↓
           blocked    waiting_pm  changes_requested
                                        ↓
                                  in_progress
```

`done` is **only** valid for work-unit artifacts and **only after PR merge**.

### ADRs

```
proposed → accepted → deprecated / superseded
```

## Project Structure

```
docs/
├── prd/             # PRD-001-name.md
├── specs/           # SPEC-001-name.md
├── plans/           # PLAN-001-name.md
├── adr/             # ADR-001-name.md
├── architecture/    # DESIGN-001-name/ (design packages from /pdlc:design)
└── templates/       # Document templates

backlog/
├── features/   # FEAT-001-name.md
├── bugs/       # BUG-001-name.md
├── tech-debt/  # DEBT-001-name.md
├── chores/     # CHORE-001-name.md
└── spikes/     # SPIKE-001-name.md

tasks/          # TASK-001-name.md  ⛔ ТОЛЬКО корневая `tasks/` — НЕ `docs/tasks/`!

.state/
├── PROJECT_STATE.json  # Central state file (CRITICAL)
├── counters.json       # ID counters
├── knowledge.json      # LLM memory between sessions
└── session-log.md      # Session log (audit trail)
```

## Временные файлы

PDLC-скиллы пишут промежуточные артефакты (PR body, diff-снэпшоты, отчёты)
в `.pdlc/tmp/` — project-local и в `.gitignore`. Туда же попадает
`pr-body-<TASK-ID>.md` от `/pdlc:implement`.

`/tmp` НЕ используется: GigaCode CLI изолирует его через виртуальную FS
(`~/.gigacode/tmp/<hash>/`), и файлы, записанные одним tool-call'ом,
становятся невидимы последующим Read/ReadFile. Если пишешь свой скрипт
или скилл — клади промежуточные файлы в `.pdlc/tmp/`, не в `/tmp/`
(issue #57 / legacy OPS-009; подробнее — `docs/gigacode-cli-notes.md` §4).

## Critical State Files

### `.state/PROJECT_STATE.json`
Central state file. After EVERY operation that changes artifacts:
1. Read current state
2. Update relevant fields
3. Write back

Contains: `pdlcVersion`, `schemaVersion`, `project`, `settings.gitBranching`, `settings.reviewer.{mode,cli}`, `settings.workspaceMode`, `settings.vcsProvider`, `settings.debt.autoCreateTask`, `settings.chore.autoCreateTask`, `artifacts`, `waitingForPM`, `blocked`, `readyToWork`, `inProgress`, `inReview`.

### `.state/knowledge.json`
LLM memory between sessions:
- `projectContext`: name, techStack, keyFiles, entryPoints
- `patterns`: patterns to follow
- `antiPatterns`: patterns to avoid
- `decisions`: architectural decisions (links to ADRs)
- `testing.strategy`: test authoring strategy — `"tdd-first"` (default) or `"test-along"`
- `testing.constraints` (OPS-057): project-specific test scope rules
  - `scope`: `"unit_only"` / `"unit_plus_sql_artifacts"` /
    `"unit_plus_integration"` / `"all"` — what test layers agent
    generates by default during decomposition
  - `generate_sql_only_no_run`: if true, agent generates SQL data
    quality / verification queries as `.sql` files in `tests/` but does
    NOT create TASK to RUN them (no spark-submit, no runtime executor).
    PM executes these queries manually when needed
  - `no_runtime_launch`: if true, generated tests must NOT launch
    application runtime (Spark, JVM service, Akka). Pure logic tests only
- `workflow.auto_merge` (OPS-056): if true, agent auto-merges PR after
  passing review. If false (default), PM does approve+merge manually
- `learnings`: lessons from implementation

### `.state/counters.json`
ID counters for all artifact types. Increment after creating each artifact.

## Git Worktree Strategy

Check `settings.workspaceMode` and `settings.gitBranching` in PROJECT_STATE.json.

### If workspaceMode: "worktree" AND gitBranching: true

Each task gets its own git worktree — isolated working directory.

**Location:** `.worktrees/{branch__name}/` (inside project root, in `.gitignore`)
**State:** Each worktree has its own `.state/` copy (NO concurrent writes)
**Counters:** `counters.json` stays in main repo only (NO copies)

**Branch naming (unchanged):**
- `feat/FEAT-XXX-slug` → folder `feat__FEAT-XXX-slug`
- `fix/BUG-XXX-slug` → folder `fix__BUG-XXX-slug`
- `plan/PLAN-XXX-TASK-YYY-slug` → folder `plan__PLAN-XXX-TASK-YYY-slug`

### Parallel Work

```
Terminal 1: /pdlc:implement TASK-001  → .worktrees/feat__FEAT-001-auth/
Terminal 2: /pdlc:implement TASK-005  → .worktrees/plan__PLAN-001-TASK-005-api/
Terminal 3: /pdlc:implement TASK-008  → .worktrees/fix__BUG-003-crash/
```

Always specify TASK-ID explicitly for parallel work!

### After Parallel Work
1. Each agent merges its PR independently
2. In main repo: `git pull origin main`
3. Run `/pdlc:sync --apply` — reconciles state from merged .md files
4. Cleanup: `git worktree list` → `git worktree remove <path> --force`

### Status Updates
When changing TASK status, ALWAYS update BOTH:
- `.state/PROJECT_STATE.json` (local copy in worktree)
- TASK `.md` file frontmatter (committed, source of truth for `/pdlc:sync`)

### If workspaceMode: "inplace" (legacy)
Uses `git checkout -b` instead of worktree. Not safe for parallel work.

### Commit Format
```
[TASK-ID] brief description
```

## Priority Order for `/pdlc:continue`

1. `changes_requested` — fix review comments
2. `in_progress` — finish started work
3. `ready` TASK from BUG (P0 > P1 > P2)
4. `ready` TASK
5. `ready` TASK from CHORE
6. `ready` TASK from DEBT (P0-P1)
7. `ready` SPIKE
8. `ready` PLAN → `/pdlc:tasks`
9. `ready` SPEC → `/pdlc:tasks`
10. `ready` FEAT → `/pdlc:tasks`
11. `ready` PRD → `/pdlc:spec`
12. `ready` TASK from DEBT (P2+)

## PM Checkpoints (When to Stop and Ask)

- FEAT size M/L → ask if spec needed
- Creating > 3 TASKs → show plan, wait for confirmation
- Architectural choice → offer options with recommendation
- First PR in session → notify PM for review

## Git Safety

- ⛔ NEVER `git add -f <path>` / `git add --force <path>` на любой путь,
  который игнорируется `.gitignore`. Принудительное добавление обходит
  `.gitignore` и может закоммитить служебные файлы CLI против желания
  пользователя. Разрешено только если PM явно попросил «добавить
  принудительно» в этой же реплике.
- ⛔ NEVER `git add .gigacode/` / `git add .qwen/` / `git add .codex/` /
  `git add .worktrees/` — это служебные директории CLI-плагинов. В
  `/pdlc:init`-сконфигурированном проекте они в `.gitignore`
  (см. append-блок в `skills/init/SKILL.md` шаг 5). Исключение —
  **файл** `.claude/settings.json` (НЕ директория `.claude/` целиком):
  это permission-allowlist для the Qwen CLI agent plugin'а, его коммитят
  целенаправленно.
- ⛔ NEVER модифицировать `.gitignore` ради того, чтобы «починить»
  untracked служебную директорию.

**Как парсить «закоммить всё, КРОМЕ X»**: это явное ИСКЛЮЧЕНИЕ, не
фокус. Не форсить X, не трогать `.gitignore` ради X, не переносить X в
tracked. При сомнении — переспросить PM.

**Untracked в `git status`**: если видишь `.gigacode/` / `.qwen/` /
`.codex/` / `.worktrees/` в untracked — это НОРМА, они попадают в
`.gitignore` после `/pdlc:init`. Не «помогай» добавлением. Про
`.venv/` / `node_modules/` / `vendor/` / `target/` и прочие stack-specific
пути: в template `.gitignore` они **закомментированы** — каждый проект
раскомментирует нужные под свой стек. Если видишь такой путь в
untracked и он должен быть игнорирован — попроси PM раскомментировать
соответствующую строку в `.gitignore`, **не** предлагай `git add -f`.

**Исключения для `.claude/`**: коммитится только `.claude/settings.json`
(создаётся `/pdlc:init`, см. `skills/init/SKILL.md:86`,
`README.md:106`). Прочее содержимое `.claude/` (локальные логи, cache,
planning-заметки в `.claude/plans/`) — **НЕ** коммитить, даже если PM
говорит «добавь всю папку `.claude`». Используй `git add .claude/settings.json`
поштучно, не `git add .claude/`.

## Self-Review Gate (Required Before Commit)

**⛔ MUST OUTPUT CHECKLIST before commit!**

Subagent MUST before committing:
1. **Use Read tool** — re-read ALL changed files
2. **OUTPUT checklist** in this format:

```
───────────────────────────────────────────
SELF-REVIEW CHECKLIST
───────────────────────────────────────────
[✓] Hardcoded values: no passwords/keys
[✓] Error handling: errors handled per stack conventions
[✓] Patterns: follows patterns from knowledge.json
[✓] Anti-patterns: no violations
[✓] Tests: tests added/updated
[✓] TDD: tests written before code (if testing.strategy: "tdd-first"; N/A if "test-along")
[✓] Acceptance criteria: all met
───────────────────────────────────────────
Ready to commit: YES
```

3. If any [✗] — **FIX and repeat checklist**
4. Only after all [✓] — commit

**⚠️ COMMIT WITHOUT EXPLICIT CHECKLIST OUTPUT = PROTOCOL VIOLATION!**

## Validation Rules

| Command | Accepts | Creates |
|---------|---------|---------|
| `/pdlc:spec` | PRD or FEAT with status `ready` | SPEC |
| `/pdlc:design` | PRD or SPEC with status `ready` | DESIGN-PKG (+ optional ADRs) |
| `/pdlc:roadmap` | SPEC with status `ready` | PLAN |
| `/pdlc:tasks` | PLAN, SPEC, FEAT, BUG, DEBT, or CHORE with status `ready` | TASK[] |
| `/pdlc:implement` | **ONLY TASK** with status `ready` | Code |

## System Boundary

When implementing TASKs, the agent works **ONLY** within the system specified
in `system_boundary` of the parent SPEC frontmatter (if set).

### Rules

1. **Code is created only for our system** — not for external systems listed in `external_systems`
2. **Integrations are implemented as clients/adapters** — we write an HTTP client to the external API,
   not the external system itself
3. **Consumed contracts are read-only** — files in `docs/contracts/consumed/` are never modified
4. **Provided contracts** — files in `docs/contracts/provided/` — are modified
   only through `/pdlc:design` or with explicit intent
5. **Integration tests** — use mocks/stubs/WireMock for external systems;
   this is test infrastructure, not production code of the external system
6. **If a TASK requires changes in an external system** — the agent creates an Open Question,
   not the change itself

These rules apply when the parent SPEC has a non-empty `external_systems` list.
If no SPEC or no `external_systems` — section is informational only.

## Status Output Format

```
═══════════════════════════════════════════
  PROJECT STATUS
═══════════════════════════════════════════

READY TO WORK (N):
   • TASK-001 → /pdlc:implement
   • SPIKE-001 → research

WAITING FOR PM (N):
   • TASK-003: "question"

BLOCKED (N):
   • TASK-005: reason

IN PROGRESS (N):
   • TASK-002: what's being done

IN REVIEW (N):
   • PR #123: FEAT-001

ARCHITECTURE:
   • Active ADRs: 5

RECOMMENDATION:
   → Specific action
```

## When to Work Autonomously

- Artifacts with status `ready` exist
- Task is clear and doesn't need clarification
- No technical blockers

## When to Stop and Ask PM

- Business decision required (priority, scope, trade-off)
- External information needed (API keys, credentials, access)
- Architectural choice with significant consequences
- Task contradicts existing requirements
- Creating > 3 TASKs
- FEAT size M or L

## How to Format PM Prompts (CRITICAL — terminal UX)

When you need to stop and ask PM for a decision, the prompt block MUST be the **last printed thing** in your turn. PM is reading a terminal: anything printed after the prompt scrolls it off-screen and forces the PM to scroll back to find the question.

**Rules:**

1. **Position:** PM-prompt block is the LAST output. Print all results, listings, diagnostics BEFORE it. Do not print "Жду вашего ответа", hints, or anything else AFTER the prompt block.
2. **Visual anchor:** Start the block with three repeats of `►►►` on a separate line. PM uses this as a scroll marker.
3. **Question first:** First line inside the block IS the question (action-oriented, e.g. "СОХРАНИТЬ 15 ЗАДАЧ?"), not a generic header like "НУЖНО РЕШЕНИЕ PM".
4. **Compact:** The block fits in ~10 lines. Move long context (listings, coverage tables, parent chains) ABOVE the block, in regular output.
5. **Empty line before** the block (separates from preceding output).
6. **Numbered options** with one-line descriptions. Mark recommended one with `(рекомендуется)`.
7. **Last line** = unambiguous prompt: `→ ответьте: 1 / 2 / 3` or `→ введите URL` or similar. No trailing prose.

**Canonical form:**

```
... (any results, listings, diagnostics — printed first) ...

►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
►  <ACTION-ORIENTED QUESTION>
►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1 — <option> (рекомендуется)
  2 — <option>
  3 — <option>

  Подробности — в выводе выше.

→ ответьте: 1 / 2 / 3
```

**Anti-patterns (do not do):**

- ❌ Print "Контекст:", "Создано задач: 15", "ФАЗА 1: ..." INSIDE the prompt block. Print all of that BEFORE.
- ❌ Use generic header "НУЖНО РЕШЕНИЕ PM" — the question itself is the header.
- ❌ Print anything after the prompt block in the same turn.
- ❌ Use thin `═══` rule without the `►►►` anchor — visually weaker, harder to scroll-find.

This rule applies to: `/pdlc:feature` size checkpoint, `/pdlc:tasks` consolidated checkpoint, `/pdlc:unblock` per-question prompts, `/pdlc:review-pr` 2-iteration `waiting_pm` prompt, any other interactive PM gate.

## ADR (Architecture Decision Records)

Create ADR when:
- Choosing technology (DB, framework)
- Architectural pattern choice
- Deviation from SPEC

ADR statuses: `proposed` → `accepted` → `deprecated`/`superseded`

## VCS providers

Все операции над PR (create / view / list / diff / merge / comment / close) проходят через единую абстракцию `scripts/pdlc_vcs.py`. Провайдер выбирается из `.state/PROJECT_STATE.json → settings.vcsProvider`:

- `github` (дефолт) — через `gh` CLI, обычный GitHub/GitHub Enterprise.
- `bitbucket-server` — self-hosted Atlassian Bitbucket Server через REST API.

### Bitbucket Server: настройка

1. Установи `settings.vcsProvider` в `"bitbucket-server"` (автоматически при `/pdlc:init`, вручную + `/pdlc:migrate --apply` для существующих проектов).
2. `/pdlc:migrate --apply` создаст `.env.example` (reference) и `.env` (stub). `.env` добавится в `.gitignore` (некомментированной строкой).
3. Заполни в `.env` хотя бы один домен:
   - `BITBUCKET_DOMAIN1_URL` + `BITBUCKET_DOMAIN1_TOKEN` (HTTP Access Token).
   - Опционально `BITBUCKET_DOMAIN2_URL` + `_TOKEN` для второго корпоративного Bitbucket.
   - `BITBUCKET_DOMAIN*_AUTH_TYPE=bearer` (дефолт) или `basic` при 401.
4. Инстанс выбирается автоматически по хосту `git remote get-url origin` — подходящий `BITBUCKET_DOMAIN{N}_URL` определяет, куда идти за PR.
5. Проверь конфигурацию:
   - `/pdlc:pr whoami` — валидность токена и выбор инстанса.
   - `/pdlc:doctor` — полная диагностика (`.env`, токены, origin-host match).

### Ручные операции над PR

Используй `/pdlc:pr <sub>`:
- `/pdlc:pr list [--head BRANCH]` — список открытых PR.
- `/pdlc:pr view <id>` — метаданные PR.
- `/pdlc:pr diff <id>` — полный diff.
- `/pdlc:pr merge <id> [--squash] [--delete-branch]` — merge и удаление source-ветки.
- `/pdlc:pr comment <id> --body "..."` — добавить комментарий.
- `/pdlc:pr close <id>` — закрыть (GitHub: `CLOSED`, Bitbucket: `DECLINED`).

Для длинных тел комментариев — вызывай скрипт напрямую с `--body-file` или `--body-stdin` вместо `/pdlc:pr comment --body "..."`, чтобы не страдать от shell-escape.

## Templates

Use templates from `docs/templates/` when creating documents:
- Always fill `status:` in frontmatter
- Always specify `id:` for tracking
- Link documents via `parent:` and `children:`
- For BUG specify `task:` with linked TASK; for DEBT/CHORE specify `task:` only when a linked TASK exists (DEBT: opt-in via `--task`; CHORE: default, opt-out via `--no-task`)
