---
name: pdlc-create-tests
description: Generate SQL data-quality test scripts (DataExist, Mandatory NOT-NULL, Double-PK, Broken-links) for a Hadoop data mart from its S2T Excel specification, as standalone CSV files for RDT and IFT. Use when PM mentions "create tests", "создай автотесты", "sql скрипты проверки", "DQ тесты", "проверки качества данных", "сгенерируй тесты", "create-tests".
---

Standalone-генерация data quality тестов для Hadoop витрины из S2T
Excel-спецификации. Симметрична `/pdlc:create-data` (тестовые данные):
каждая команда делает одно дело и запускается PM вручную.

⚠️ **Зачем отдельная команда.** Генерация DQ-тестов встроена в
`/pdlc:implement` как hook после review витрины-TASK (OPS-070). Но если
витрины **уже реализованы** (цикл завершён, TASK в done) — hook не
сработает повторно. `/pdlc:create-tests` — точка входа для этого случая:
витрина есть, тестов нет, PM хочет их сгенерировать сейчас.

Real-world basis (2026-06-01): PM прошёл цикл с `dataMartTesting.enabled
== false` (дефолт) — DQ-тесты молча не сгенерировались. При втором
запуске агент «не смог понять какие скрипты от него хотят», потому что
точки входа вне implement-цикла не существовало.

## Использование

```
/pdlc:create-tests                  # автоопределение витрин(ы) из кода
/pdlc:create-tests dm_product       # явное имя витрины
```

## Алгоритм

> **OPS-063 — reading references:** читай файлы через shell `cat`, не
> Read tool. **OPS-061 — Python:** `PY=${PY:-$(command -v python3 || command -v python)}`.

### 1. Конфиг и интерактивное восполнение (паттерн OPS-078)

Прочитай `.state/knowledge.json` (через `cat`), секцию `dataMartTesting`.

**Если `enabled == false` или секция отсутствует** — НЕ падай и НЕ
останавливайся молча. Спроси PM:

```
dataMartTesting сейчас выключен (enabled=false). Команда /pdlc:create-tests
требует включённого pipeline. Включить и продолжить? [Y/n]
```

При согласии — обнови `knowledge.json` (`enabled: true`) через
Edit/str_replace и продолжай.

**Если `s2t_excel_path` пуст или файл не существует** — спроси PM путь
к S2T Excel-файлу:

```
Укажите путь к S2T Excel-файлу со спецификацией колонок витрины
(лист "<s2t_sheet>", обычно "Target columns"):
```

После ответа — предложи сохранить в `knowledge.json`
(`dataMartTesting.s2t_excel_path`): «Сохранить путь в knowledge.json? [Y/n]».

Аналогично для `data_vars_path` если пуст (нужен для определения схемы).

### 2. Hadoop guard (OPS-074)

Подтверди что витрина — Hadoop, автодетектом по коду (НЕ спрашивай PM):

```bash
PLUGIN=${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}
# Ищи в <dataMartTesting.datamart_code_path> маркеры (Glob *.scala + cat):
#   org.apache.spark / org.apache.hadoop / spark.read / spark.sql /
#   DataFrame / Dataset[ / SparkSession / saveAsTable / .parquet / .orc / hdfs://
```

Если маркеров нет — STOP: «Витрина не Hadoop (нет Spark/HDFS маркеров).
DQ-тесты по требованиям проекта генерируются только для Hadoop витрин».

### 3. Определи имя витрины

- Из аргумента команды, если передан (`/pdlc:create-tests dm_product`)
- Иначе — автоопределение из кода в `datamart_code_path` (имена
  saveAsTable / целевых таблиц). Если витрин несколько и аргумент не
  задан — перечисли найденные и спроси PM какую (или все).

### 4. Генерация (та же механика что OPS-070 в implement)

```bash
PY=${PY:-$(command -v python3 || command -v python)}
PLUGIN=${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}

# 4a. Excel "Target columns" лист → CSV:
$PY "$PLUGIN/scripts/pdlc_datamart_tests.py" sheet-to-csv \
    --excel "<dataMartTesting.s2t_excel_path>" \
    --sheet "<dataMartTesting.s2t_sheet>" \
    --out "<s2t-dir>/target_columns.csv"

# 4b. Прочитай target_columns.csv (через cat). Изучи колонки:
#     «Является ли поле NULL» (NO=NOT NULL), «Является ли поле PK» (YES),
#     «Является ли поле FK» (YES), «Column Attribute Note» (FK→PK refs).

# 4c. Определи схему: из <dataMartTesting.data_vars_path>, параметр
#     <dataMartTesting.market_schema_var>. Прочитай через cat.

# 4d. Сгенерируй 2 файла тестов (РДТ без _ift, ИФТ с _ift):
$PY "$PLUGIN/scripts/pdlc_datamart_tests.py" dq-tests \
    --columns-csv "<s2t-dir>/target_columns.csv" \
    --datamart "<datamart_name>" \
    --schema-rdt "<marketSchema value>" \
    --schema-ift "<marketSchema value + ift suffix>" \
    --out-dir "<dataMartTesting.autotests_dir>"
```

Скрипт генерирует 4 типа тестов (формат
`Id;Entity;Test_name;Test_script;Expected_result`):
- **DataExist** — `SELECT COUNT(*)` → `>0`
- **Mandatory** — NOT-NULL поля → `WHERE attr IS NULL` → `0`
- **Double PK** — `GROUP BY ... HAVING COUNT(*) > 1` → `0`
- **Broken links** — FK→PK по «Column Attribute Note» → LEFT JOIN → `0`

**Если в проекте есть бизнес-требования** (PRD/SPEC body) — изучи их
и добавь дополнительные SQL-тесты строками в сгенерированный CSV, если
требования предполагают проверки вне 4 базовых типов.

### 5. Ограничения (OPS-074 — обязательны)

1. ⛔ **ТОЛЬКО SQL-скрипты** (CSV с SQL внутри). Ничего больше.
2. ⛔ **НЕ редактируй существующие Scala файлы** (особенно
   `autotests.scala`) — они принадлежат разработчику витрины.
3. ⛔ **НЕ создавай shell-скрипты** (`.sh`, `.bat`, `.ps1`).
4. ⛔ **НЕ создавай** Python/Scala/исполняемый код тестов.
5. Желание «обернуть тесты в скрипт запуска» — НЕ реализуй. Запуск —
   вне зоны оркестратора (см. `/pdlc:check-tests`).

### 6. Вывод

```
═══════════════════════════════════════════
/pdlc:create-tests → DQ-тесты созданы
═══════════════════════════════════════════

Витрина: dm_product (Hadoop)
Источник спецификации: s2t/<файл>.xlsx, лист "Target columns"
Схема РДТ: custom_cib_pkaptdul
Схема ИФТ: custom_cib_pkaptdul_ift

Созданные файлы (autotests/):
  + dm_product_tests.csv       (N тестов, РДТ)
  + dm_product_tests_ift.csv   (N тестов, ИФТ)

Типы: DataExist (1), Mandatory (X), Double PK (Y), Broken links (Z)

Следующие шаги:
  → /pdlc:create-data — сгенерировать тестовые данные для источников
  → после прогона витрины на стенде: /pdlc:check-tests — анализ результатов
═══════════════════════════════════════════
```

## Важно

- Команда **не коммитит** автоматически — предложи PM: «Добавить
  autotests/ в git? [Y/n]».
- Связанные команды: `/pdlc:create-data` (тестовые данные),
  `/pdlc:check-tests` (анализ результатов после прогона).