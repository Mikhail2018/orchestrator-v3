---
name: pdlc-unblock
description: Answer PM questions and unblock tasks waiting for input. Use when PM mentions "unblock", "answer PM questions", "resolve waiting_pm", "разблокируй", "ответы PM".
---

Интерактивная сессия для ответов на вопросы, которые ждут PM.

## Алгоритм

1. Прочитай `.state/PROJECT_STATE.json`
2. Получи список `waitingForPM`
3. Если список пуст → "Нет вопросов, ждущих ответа. Всё разблокировано!"
4. **OPS-065 — резолюция Q-XXX в файл/inline-контекст:**
   Список `waitingForPM` содержит **смесь** идентификаторов:
   - **Q-XXX:** stand-alone questions (`questions/Q-XXX-<slug>.md`)
     — отдельные файлы (созданы /pdlc:design, /pdlc:spec, /pdlc:prd
     с открытыми вопросами)
   - **TASK-XXX, FEAT-XXX, SPEC-XXX, ...:** inline-вопросы внутри
     соответствующих артефактов (frontmatter `open_questions:` или
     текст в body)
   - **pr_url_request, validation_failure, ...:** legacy markers
     встроенные прямо в state без файла

   Для **каждого** ID из waitingForPM:

   ```bash
   PLUGIN=${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}

   # Резолюция Q-XXX через Glob:
   if [[ "$ID" == Q-* ]]; then
       FILE=$(ls questions/${ID}*.md 2>/dev/null | head -1)
       if [ -n "$FILE" ]; then
           # Файл есть — читай контекст из него
           CTX=$(cat "$FILE")
       else
           # Файл отсутствует — fallback: ищи Q-XXX в parent артефакте
           # (часто Q был создан /pdlc:design и записан в SPEC body)
           # Glob: docs/specs/*.md, docs/prd/*.md, docs/architecture/**/manifest.yaml
           # Если найдено — извлеки секцию с этим Q-NNN
           # Если не найдено — print warning, спроси PM напрямую
           echo "⚠ Q-${ID#Q-} not found as file. Showing as inline question."
       fi
   else
       # TASK/FEAT/SPEC/... — читай артефакт через Glob по ID
       FILE=$(ls **/${ID}*.md 2>/dev/null | head -1)
   fi
   ```

5. Для каждого вопроса последовательно:
   a. Покажи контекст (какой артефакт, когда создан вопрос)

   **EARLY EXIT для pr_url_request (OPS-008):**
   a'. Если текст вопроса содержит "pr_url_request" или "Создайте PR вручную"
       или "Create PR manually" (вопрос создан continue Phase C fallback):
       - Показать PM: "TASK-XXX ждёт URL вручную созданного PR.
                       Ветка: <expected_branch>."
       - Варианты ответа:
         1. Указать PR URL
         2. Отложить (оставить waiting_pm)
         3. Отменить задачу
       - Если PM предоставляет URL:
         - Валидация: URL содержит `/pull/` или `/merge-requests/` или аналог
           (если не проходит — спросить снова, не fallback на status=ready)
         - Записать в TASK frontmatter: `pr_url: <url>`
           (только frontmatter — НЕ в PROJECT_STATE.artifacts)
         - Удалить из `waitingForPM`
         - Добавить в `inReview` (НЕ `readyToWork`!)
         - Статус TASK остаётся `review` (НЕ `ready`!)
         - Вывод: "PR URL записан. /pdlc:continue для resume quality review."
         - **Перейти к следующему вопросу (skip шаги b–g)**
       - Если PM говорит "отложить" → оставить waiting_pm (стандартный path)
       - Если PM говорит "отменить" → status=done cancelled (стандартный path)

   **Стандартный flow (для всех остальных вопросов):**
   b. Задай вопрос PM
   c. Дождись ответа
   d. Обнови артефакт с ответом
   e. Измени статус артефакта на `ready`
   f. Удали из `waitingForPM`
   g. Добавь в `readyToWork`
5. После всех вопросов — обнови PROJECT_STATE.json

## Формат вопроса

⚠️ **Правило размещения PM-prompt** (см. GIGACODE.md → "How to Format PM Prompts"):
prompt-блок ОБЯЗАН быть **последним** напечатанным в этом turn. Контекст
вопроса (артефакт, дата, что ждёт PM) — печатай ДО prompt-блока, как
обычный output.

**Шаг 1 — печатай ПЕРЕД prompt-блоком (обычный output):**

```
═══════════════════════════════════════════
ВОПРОС N/M: TASK-015
═══════════════════════════════════════════
Артефакт: tasks/TASK-015-stripe-integration.md
Ждёт с: 2024-01-14

Контекст:
"Нужен API ключ для интеграции со Stripe.
Тестовый или продакшн? Где его взять?"
═══════════════════════════════════════════
```

**Шаг 2 — пустая строка, затем prompt-блок (последнее в turn'е):**

```

►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
►  ОТВЕТЬТЕ ИЛИ ВЫБЕРИТЕ ДЕЙСТВИЕ:
►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1 — Предоставить значение (введите ниже)
  2 — Отложить задачу (оставить waiting_pm)
  3 — Отменить задачу

→ ответьте: 1 <значение> / 2 / 3
```

⛔ После prompt-блока агент НИЧЕГО больше не печатает до ответа PM.

## Обработка ответов

### Если PM даёт ответ
- Сохрани ответ в артефакте
- Измени статус на `ready`
- Продолжи к следующему вопросу

### Если PM говорит "отложить"
- Оставь статус `waiting_pm`
- Добавь заметку о причине
- Продолжи к следующему вопросу

### Если PM говорит "отменить"
- Измени статус на `done` с пометкой "cancelled"
- Удали из активных списков

## Завершение

```
═══════════════════════════════════════════
Готово! Обработано вопросов: N

Разблокировано: X артефактов
Отложено: Y артефактов
Отменено: Z артефактов

Следующий шаг:
   → /pdlc:continue для автономной работы
   → /pdlc:state для обзора
═══════════════════════════════════════════
```

## Важно

- Задавай вопросы по одному, не все сразу
- Давай контекст — PM может не помнить детали
- Предлагай варианты, если вопрос подразумевает выбор
- После каждого ответа сразу обновляй PROJECT_STATE.json