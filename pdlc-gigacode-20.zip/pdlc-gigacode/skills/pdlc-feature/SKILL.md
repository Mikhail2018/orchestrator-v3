---
name: pdlc-feature
description: Create a lightweight Feature Brief (FEAT-NNN) for incremental product work that does not warrant a full PRD. Use when PM mentions "create a feature", "add feature brief", "new feature work", "feature request", "add FEAT", "заведи фичу", "новая фича", or any request to capture a small-to-medium feature without PRD-level process. Trigger liberally — under-triggering forces the agent to improvise freeform docs; over-triggering is recoverable (PM can delete or upgrade to PRD).
---

<!-- argument hint: [описание] -->

Создание Feature Brief — короткого описания фичи для быстрой работы.

**Это основной способ добавления фич.** Используй PRD только для крупных инициатив.

## Использование

```
/pdlc:feature Добавить экспорт в PDF
/pdlc:feature Кнопка "Поделиться" в карточке товара
```

## Алгоритм

### Быстрое добавление (по умолчанию)

Если PM даёт короткое описание:

1. **Вычисли next-id для FEAT** по протоколу из
   `${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/assets/tasks/references/compute-next-id.md`
   (единый max по `.state/counters.json`, `PROJECT_STATE.artifactIndex` и
   file-scan `backlog/features/FEAT-*.md`). При **Counter drift** — АБОРТ
   с рекомендацией `${PY:-$(command -v python3 || command -v python)} ${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/scripts/pdlc_sync.py . --apply --yes`.
2. **Write-guard.** Перед `Write` проверь, что
   `backlog/features/FEAT-{N}-slug.md` не существует и что `FEAT-{N}` нет
   в `state.artifactIndex`. При коллизии — АБОРТ.
3. Создай файл `backlog/features/FEAT-XXX-slug.md`
4. Заполни базовую информацию
5. Спроси 2-3 уточняющих вопроса:
   - "Какой приоритет: P1 (высокий), P2 (средний), P3 (низкий)?"
   - "Это на несколько часов (S), дней (M) или неделю+ (L)?"
   - Если непонятно: "Можешь описать что именно должно происходить?"
6. Инкрементируй счётчик (`counters.json[FEAT] = N`).
7. Обнови PROJECT_STATE.json
8. **PM Checkpoint для M/L** (см. ниже)
9. Покажи результат с рекомендацией следующего шага

### Определение размера (size)

| Size | Описание | Следующий шаг |
|------|----------|---------------|
| S | Несколько часов, очевидная реализация | `/pdlc:tasks` сразу |
| M | Несколько дней, понятные требования | `/pdlc:tasks` или `/pdlc:spec` |
| L | Неделя+, сложная логика | Предложи `/pdlc:prd` |

## PM Checkpoint

⚠️ **Правило размещения PM-prompt** (см. GIGACODE.md → "How to Format PM Prompts"):
prompt-блок ОБЯЗАН быть **последним** напечатанным в этом turn. Контекст
(FEAT-XXX, размер, рассуждения) — печатай ДО prompt-блока, как обычный
output. После prompt-блока агент ничего не печатает.

### Для size M или L — ОБЯЗАТЕЛЬНАЯ остановка:

**Шаг 1 — печатай ПЕРЕД prompt-блоком (обычный output):**

```
═══════════════════════════════════════════
FEAT-001 СОЗДАН: Экспорт в PDF
═══════════════════════════════════════════
Размер: M (несколько дней)
Приоритет: P1
Файл: backlog/features/FEAT-001-pdf-export.md
═══════════════════════════════════════════
```

**Шаг 2 — пустая строка, затем prompt-блок (последнее в turn'е):**

```

►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
►  НУЖНА ЛИ ТЕХНИЧЕСКАЯ СПЕЦИФИКАЦИЯ ДЛЯ FEAT-001?
►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1 — Да — создать SPEC для проработки архитектуры
  2 — Нет — сразу /pdlc:tasks для создания задач (рекомендуется для M)

→ ответьте: 1 / 2 / continue
```

### Для size L — предложение PRD:

**Шаг 1 — печатай ПЕРЕД prompt-блоком:**

```
═══════════════════════════════════════════
FEAT-001 СОЗДАН: Система уведомлений
═══════════════════════════════════════════
Размер: L (неделя+)
Приоритет: P1
Файл: backlog/features/FEAT-001-notifications.md
═══════════════════════════════════════════
```

**Шаг 2 — prompt-блок:**

```

►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
►  L-РАЗМЕР: КАК ПРОРАБОТАТЬ FEAT-001?
►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1 — Создать полный PRD — для детальной проработки (рекомендуется)
  2 — Оставить как FEAT — если требования понятны
  3 — Создать SPIKE — если нужно исследование

→ ответьте: 1 / 2 / 3 / continue
```

⛔ После prompt-блока агент НИЧЕГО больше не печатает в этот turn.

## Шаблон файла

```markdown
---
id: FEAT-XXX
title: "[Описание]"
status: ready
created: YYYY-MM-DD
priority: P2
size: M
children: []
---

# Feature: [Описание]

## Что и зачем

**Что делаем:**
[Из описания PM]

**Зачем:**
[Если очевидно — заполни, иначе спроси]

**Для кого:**
[Если очевидно — заполни, иначе "Основные пользователи"]

## Требования

### Должно быть (Must have)
- [ ] [Основное требование из описания]

### Хорошо бы (Nice to have)
- [ ] [Если PM упомянул]

## Критерии готовности

- [ ] Функционал работает
- [ ] [Специфичные критерии если есть]

## Следующий шаг

→ /pdlc:tasks FEAT-XXX (для S/M)
→ /pdlc:spec FEAT-XXX (если нужна архитектура)
```

## Формат подтверждения

```
═══════════════════════════════════════════
FEATURE BRIEF СОЗДАН
═══════════════════════════════════════════

ID: FEAT-001
Название: Добавить экспорт в PDF
Файл: backlog/features/FEAT-001-export-pdf.md
Приоритет: P2
Размер: M (несколько дней)
Статус: ready

═══════════════════════════════════════════
СЛЕДУЮЩИЙ ШАГ:
   → /pdlc:tasks FEAT-001 — создать задачи и начать работу
   → /pdlc:spec FEAT-001 — если нужна техническая проработка
   → /pdlc:continue — автономная работа
═══════════════════════════════════════════
```

## Генерация slug

Из описания создай короткий slug:
- "Добавить экспорт в PDF" → `export-pdf`
- "Кнопка поделиться" → `share-button`
- Только латиница, lowercase, дефисы

## Важно

- Для size M/L — обязательно PM Checkpoint
- Для size L — предложи PRD
- Не начинай работу над M/L без подтверждения PM
- `/pdlc:tasks` создаёт TASK, которые идут в `/pdlc:implement`