---
name: pdlc-init
description: Initialize Polisade Orchestrator project structure. Use when PM mentions "init project", "initialize", "scaffold polisade", "set up polisade", "иницилизируй", "создай проект".
---

<!-- argument hint: [ProjectName] -->

Scaffold the full Polisade Orchestrator autonomous development framework into the current project.

## Usage

```
/pdlc:init MyProject
/pdlc:init              # uses current directory name
```

## What it creates

```
.state/
├── PROJECT_STATE.json
├── counters.json
└── knowledge.json

docs/
├── prd/
├── specs/
├── plans/
├── adr/
├── architecture/   # design packages from /pdlc:design
├── contracts/
│   ├── README.md       # integration map
│   ├── provided/       # contracts we provide (OpenAPI, AsyncAPI, Protobuf…)
│   └── consumed/       # contracts we consume from external systems (read-only)
└── templates/
    ├── prd-template.md
    ├── spec-template.md
    ├── plan-template.md
    ├── feature-brief-template.md
    ├── task-template.md
    ├── adr-template.md
    ├── chore-template.md
    ├── spike-template.md
    └── design-package-template.md

backlog/
├── features/
├── bugs/
├── tech-debt/
├── chores/
└── spikes/

tasks/

GIGACODE.md
.gitignore (updated)
```

## Algorithm

1. If `{{args}}` is provided, use it as project name. Otherwise use the current directory name.

   **Working directory hygiene (OPS-050):** all subsequent shell commands
   in this skill MUST run from the **project root** (cwd at skill entry).
   Before any shell command:

   ```bash
   PROJECT_ROOT="${PDLC_WORK_DIR:-$(pwd)}"
   cd "$PROJECT_ROOT"
   ```

   This protects against:
   - Subagent / tool calls that may have changed cwd silently
   - Recursive listing commands accidentally scanning system directories
     (Recycle Bin, mounted drives) when cwd is at filesystem root
   - PM running `/pdlc:init` from inside `$HOME` or `C:\` by mistake

   If `pwd` returns the user's home directory or root (`/`, `C:\`, `D:\`)
   — STOP and ask PM «You're trying to initialize Polisade in `{pwd}`.
   This is unusual. Please `cd` to the actual project directory first».

2. Check if Polisade Orchestrator is already initialized:
   - If `.state/PROJECT_STATE.json` exists → warn and ask to confirm overwrite

3. **Run scaffolding via `pdlc_init.py` (OPS-069 — Python-first init):**

   ```bash
   PY=${PY:-$(command -v python3 || command -v python)}
   PLUGIN_ROOT=${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}
   $PY "$PLUGIN_ROOT/scripts/pdlc_init.py" \
       --all "${PROJECT_NAME}" \
       --project-root "${PROJECT_ROOT}"
   ```

   This **single call** performs steps that were previously 6+ separate
   shell commands prone to cmd.exe quirks:
   - Создаёт 15 директорий через `Path.mkdir(parents=True, exist_ok=True)`
     (cross-platform, atomic, no recursive listing pitfalls)
   - Копирует шаблоны через `pdlc_install_templates.py` (OPS-060)
   - Обновляет `.gitignore` (idempotent — пропускает если блок уже есть)
   - Устанавливает `project.name` в `knowledge.json` и `PROJECT_STATE.json`
   - **Верифицирует** структуру через `Path.is_dir()` / `Path.is_file()`
     (БЕЗ recursive listing — protected against OPS-050 incident)

   **Почему один Python-вызов вместо shell-цепочки:**
   - **OPS-050** — `dir /s` recursive listing уходил в Recycle Bin
   - **OPS-051** — Read tool блокировался для plugin paths
   - **OPS-060** — `set VAR=... && if exist "%VAR%\..."` ломалось на cmd.exe scope
   - **OPS-061** — `python3` отсутствовал на Windows
   - **OPS-069** — каждое из этих частных решений требовало shell, который
     ломается на cmd.exe. Python-скрипт обходит весь shell-слой.

   **Output:** скрипт выводит structured progress (5 шагов с галочками),
   и финальное сообщение «✓ Polisade Orchestrator init завершён успешно»
   с подсказкой что делать дальше.

   **Exit codes:**
   - `0` — успех
   - `1` — generic error (mkdir/copy/git failed)
   - `2` — invalid args / project root недоступен
   - `3` — plugin templates не найдены (битый bundle)
   - `4` — verification failed (структура неполная после установки)

   **Recovery options** если что-то пошло не так — отдельные опции для
   повторного запуска шагов:

   ```bash
   $PY "$PLUGIN_ROOT/scripts/pdlc_init.py" --detect    --project-root .
   $PY "$PLUGIN_ROOT/scripts/pdlc_init.py" --scaffold  --project-root .
   $PY "$PLUGIN_ROOT/scripts/pdlc_init.py" --templates --project-root .
   $PY "$PLUGIN_ROOT/scripts/pdlc_init.py" --gitignore --project-root .
   $PY "$PLUGIN_ROOT/scripts/pdlc_init.py" --knowledge-name "MyProject" --project-root .
   $PY "$PLUGIN_ROOT/scripts/pdlc_init.py" --verify    --project-root .
   ```

   ⛔ **НЕ используй** shell-импровизацию для verification структуры
   (`dir /s`, `dir /b /s`, `ls -R`, `find . ...`). Если PM хочет
   подтверждения — `$PY pdlc_init.py --verify` — это **единственный**
   правильный способ. Real-world incident (2026-05-09): агент после
   успешного init запустил `dir /b /s ".state" "docs" "backlog" "tasks"`,
   который ушёл в `C:/Users/.NET v4.5 Classic`, `INetCache/Low/Content.IE5`
   и **6517 строк** мусора попало в context.

<!-- Steps 4, 5, 6, 6.5 (template copy, .gitignore update, name set
in knowledge.json/PROJECT_STATE.json) — consolidated into Python
script `pdlc_init.py --all` invoked in step 3. See OPS-069 in
GIGACODE.md and `scripts/pdlc_init.py` source for details. -->

6.6. **Tech stack autodetect** — scan project root for stack markers and pre-fill `knowledge.json`:

   Markers to check:
   - `package.json` → Node.js/TypeScript (check `dependencies`/`devDependencies`)
   - `tsconfig.json` → TypeScript (even without package.json, e.g. Deno)
   - `go.mod` → Go
   - `pyproject.toml` / `requirements.txt` / `setup.py` → Python
   - `Cargo.toml` → Rust
   - `pom.xml` / `build.gradle` / `build.gradle.kts` → Java/Kotlin
   - `build.sbt` / `.scalafmt.conf` → Scala/sbt
   - `gradlew` / `mvnw` → JVM wrapper scripts (Gradle/Maven)
   - `application.yml` / `application.properties` → Spring Boot
   - `*.csproj` / `*.sln` → C# / .NET
   - `docker-compose.yml` → infrastructure hints (DB, cache, queue, Kafka)
   - `.env.example` → environment variables
   - `Makefile` / `Justfile` → build/test commands
   - `jest.config.*` / `vitest.config.*` / `pytest.ini` / `.rspec` → test framework
   - `playwright.config.*` → Playwright (E2E)
   - `cucumber.yml` / `features/*.feature` → Cucumber (BDD)

   For each detected marker, update `knowledge.json`:
   - `projectContext.techStack` — append detected languages, frameworks, databases, infra
   - `testing.testCommand` — infer test command (e.g. `npm test`, `./gradlew test`, `sbt test`, `npx playwright test`, `npx cucumber-js`)
   - `testing.lintCommand` — infer lint command if detectable (e.g. `npx eslint .`, `./gradlew check`, `sbt scalafmtCheck`)

   This is best-effort: if nothing is detected, leave fields empty — `/pdlc:spec` and `/pdlc:design` will ask during their interview.

6.7. **VCS provider setup** — ask the PM which VCS hosts the project:

   Options:
   - `github` — GitHub cloud via `gh` CLI (default).
   - `bitbucket-server` — self-hosted Bitbucket Server (corporate, via REST API).

   Record the choice in `.state/PROJECT_STATE.json → settings.vcsProvider`.

   If the PM selects `bitbucket-server`:

   a) Copy `${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/templates/init/env.example` to the project root in **two** targets:
      - `.env.example` — reference that can be committed.
      - `.env` — stub for the PM to fill in (tokens and URLs). **Do not overwrite
        an existing `.env`.**

   b) Append an uncommented `.env` line to `.gitignore` if not already present.
      Match regex `^\s*\.env(\s|$)` on each non-`#` line to avoid false positives
      from pre-existing `# .env` template comments. If no match, append:
      ```
      # VCS provider (.env contains Bitbucket tokens)
      .env
      ```

   c) Remind the PM:
      ```
      ⚠️ Заполни BITBUCKET_DOMAIN1_URL / BITBUCKET_DOMAIN1_TOKEN (и/или DOMAIN2) в .env
      перед первым /pdlc:implement. Проверь через /pdlc:doctor.
      ```

   This logic is duplicated in `scripts/pdlc_migrate.py` (`compute_vcs_bootstrap_migrations`)
   so that existing projects can switch to Bitbucket later via `/pdlc:migrate --apply`.

6.8. **Verification of created structure** — выполнена автоматически
     в шаге 3 (`pdlc_init.py --all`).

   Скрипт `pdlc_init.py` сам делает verification через `Path.is_dir()`
   и `Path.is_file()` без recursive listing. Если шаг 3 завершился
   с exit code 0 — структура валидна.

   ⛔ **ЗАПРЕЩЕНО** дополнительно проверять структуру через shell
   команды. **Никаких** `dir /s`, `dir /b /s`, `ls -R`, `find . ...`,
   `[ -d X ]`, `wc -l`. Если ты подумал что хочешь это сделать —
   **это OPS-050 incident в новой форме**.

   Real-world incident (2026-05-09): после успешного init (OPS-069
   рабочей версии) агент **всё равно** запустил
   `dir /b /s ".state" "docs" "backlog" "tasks" 2>nul | find /c /v ""`
   для «verification». Команда обошла `C:/Users/.NET v4.5 Classic`,
   `C:/Users/21271087/AppData/Local/Microsoft/Windows/INetCache/Low/Content.IE5`
   и **6517 строк** мусора попало в context. Init завис на 2+ минуты.

   ✅ **Если PM явно требует доказательства** — единственный
   допустимый способ:

   ```bash
   PY=${PY:-$(command -v python3 || command -v python)}
   PLUGIN_ROOT=${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}
   $PY "$PLUGIN_ROOT/scripts/pdlc_init.py" --verify --project-root .
   ```

   Output скрипта: `✓ Structure valid: 15 dirs, 3 required files OK`
   при успехе или `✗ Structure issues:` со списком проблем при провале.

7. Output confirmation:

```
═══════════════════════════════════════════
Polisade Orchestrator INITIALIZED
═══════════════════════════════════════════

Project: {ProjectName}
Directory: {cwd}

Created:
  ✓ .state/ — project state files
  ✓ docs/templates/ — 9 document templates
  ✓ docs/architecture/ — design packages (created on demand by /pdlc:design)
  ✓ docs/contracts/ — integration contracts (provided/consumed)
  ✓ backlog/ — features, bugs, tech-debt, chores, spikes
  ✓ tasks/ — work items
  ✓ GIGACODE.md — framework instructions

Detected stack:                        ← only if autodetect found anything
  • TypeScript 5, Express 4
  • PostgreSQL 16, Redis 7
  • Jest (unit), Playwright (E2E)
  (saved to .state/knowledge.json)

═══════════════════════════════════════════
NEXT STEPS:
   → /pdlc:feature "Description" — add a feature
   → /pdlc:prd "Name" — create PRD for large initiative
   → /pdlc:state — view project status
   → /pdlc:continue — start autonomous work
═══════════════════════════════════════════
```