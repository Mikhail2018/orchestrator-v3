---
description: Connect to the IFT cluster via SSH, read the data-mart autotest results table, and report passed/failed tests. Use when PM mentions "check tests", "проверь тесты", "результаты автотестов", "test results", "check-tests", "прогон тестов витрины".
---

Запускается **после** того как витрина отработала на стенде ИФТ и
автотесты записали результаты в таблицу. Команда подключается по SSH,
читает таблицу результатов, анализирует и выводит отчёт по пройденным
и не пройденным тестам.

⚠️ **Не входит в общий цикл** `/pdlc:continue` / `/pdlc:implement` —
запускается PM **вручную** после отработки витрины (расчёт витрины
происходит вне оркестратора, на кластере).

## Использование

```
/pdlc:check-tests
```

## Предусловия

В `knowledge.json` должна быть заполнена секция `dataMartTesting`
(см. OPS-070), в частности `dataMartTesting.environments.ift`:
- `ssh_host` — хост ИФТ кластера
- `ssh_user` — логин
- `ssh_key_path` — путь к приватному ключу
- `results_schema` — схема с таблицей результатов
- `autotests_scala_path` — путь к autotests.scala (откуда берётся `name`)

Если секция не заполнена — STOP с waiting_pm: «Заполните
dataMartTesting.environments.ift в knowledge.json».

## Алгоритм

> **OPS-063 — reading references:** читай файлы через shell `cat`, не
> Read tool. **OPS-061 — Python:** `PY=${PY:-$(command -v python3 || command -v python)}`.

1. **Прочитай конфиг** из `.state/knowledge.json` (через `cat`):
   ```bash
   PY=${PY:-$(command -v python3 || command -v python)}
   cat .state/knowledge.json
   # Извлеки dataMartTesting.environments.ift.{ssh_host,ssh_user,
   #   ssh_key_path,results_schema,autotests_scala_path}
   ```

   ⚠️ **OPS-078 (П.6) — опрос SSH если config неполный.** Проверь что
   все обязательные SSH-параметры заполнены и не stub/placeholder:
   `ssh_host`, `ssh_user`, `ssh_key_path` — непустые.

   **Если хотя бы один пуст** — НЕ падай, спроси PM интерактивно
   (AskUserQuestion / waiting_pm) недостающие:
   ```
   Для подключения к стенду ИФТ нужны параметры SSH. Укажите:
     - Хост (ssh_host)
     - Логин (ssh_user)
     - Путь к ppk-ключу (ssh_key_path)
   ```
   После ответа — предложи сохранить в knowledge.json
   `dataMartTesting.environments.ift` чтобы не спрашивать повторно:
   «Сохранить параметры в knowledge.json? [Y/n]». Если да — обнови файл.

   Если `dataMartTesting.enabled != true` — waiting_pm с просьбой
   включить и заполнить.

2. **Определи `name`** таблицы результатов. Прочитай
   `<autotests_scala_path>` (через `cat`), найди параметр `name`:
   ```bash
   cat "<autotests_scala_path>" | grep -i "name"
   # Извлеки значение name (например, val name = "dm_product_autotest_results")
   ```
   Полное имя таблицы: `<results_schema>.<name>`.

3. **Подключись по SSH и прочитай таблицу.** Сформируй команду
   (значения подставь из конфига, НЕ хардкодь):

   ```bash
   # Прочитать таблицу результатов через spark-shell / hive / beeline
   # на удалённом кластере. Точная команда зависит от того, как на
   # кластере доступен SQL-движок — типичный паттерн через ssh:
   ssh -i "<ssh_key_path>" "<ssh_user>@<ssh_host>" \
       "beeline -e 'SELECT * FROM <results_schema>.<name>;'"
   ```

   ⚠️ Путь к ключу `<ssh_key_path>` может содержать `%USERPROFILE%`
   (Windows env var) — на Windows ssh её раскроет сам; на POSIX
   используй `$HOME` эквивалент если нужно.

   ⚠️ **OPS-080 — формат ключа: .ppk vs OpenSSH.** Стандартный OpenSSH
   `ssh -i` **НЕ принимает** `.ppk` (PuTTY-формат). Перед подключением
   проверь расширение `<ssh_key_path>`:
   - **`.ppk`** → используй PuTTY `plink` вместо ssh:
     ```bash
     plink -i "<ssh_key_path>" -batch "<ssh_user>@<ssh_host>" \
         "beeline -e 'SELECT * FROM <results_schema>.<name>;'"
     ```
     Если `plink` не найден в PATH — предложи PM один из вариантов:
     (a) установить PuTTY (plink.exe), или (b) конвертировать ключ в
     OpenSSH формат: `puttygen private.ppk -O private-openssh -o id_rsa`
     и указать новый путь.
   - **без `.ppk`** (OpenSSH `id_rsa`/`.pem`) → обычный `ssh -i` (выше).

   Если SSH-подключение падает (timeout, auth fail, host unreachable) —
   НЕ повторяй бесконечно. После 1-2 попыток → waiting_pm с конкретной
   ошибкой и просьбой проверить: VPN, доступность хоста, валидность ключа.

4. **Проанализируй таблицу результатов** и выведи отчёт:

   ```
   ═══════════════════════════════════════════
   /pdlc:check-tests → отчёт по автотестам витрины
   ═══════════════════════════════════════════

   Таблица: <results_schema>.<name>
   Стенд: ИФТ (<ssh_host>)
   Всего тестов: N

   ✅ ПРОЙДЕНО: X
     • Data exists (dm_product)
     • Mandatory attribute filled: agr_sk
     • ...

   ❌ НЕ ПРОЙДЕНО: Y
     • Double PK: agr_sk, report_dt
       Ожидалось: 0, получено: 3 (есть дубли!)
     • Broken links: agr_subj_sk -> dns_subj.subj_sk
       Ожидалось: 0, получено: 12 (orphan FK!)

   ═══════════════════════════════════════════
   ```

   Структура таблицы результатов зависит от того, как autotests.scala
   их пишет — типично содержит: test_name, test_script, expected_result,
   actual_result, status (PASS/FAIL). Сопоставь expected vs actual,
   классифицируй PASS/FAIL.

5. **Если есть FAIL** — кратко прокомментируй вероятную причину каждого
   (на основе типа теста), но НЕ предлагай автоматических фиксов —
   PM решает что делать с упавшими тестами.

## Замечания

- Команда **read-only** на стороне кластера — только SELECT, никаких
  мутаций таблиц.
- Не сохраняет креды в логи / артефакты — ключ и логин только в
  команде SSH, не пиши их в trace или PROJECT_STATE.
- Если PM запускает на проекте где `dataMartTesting.enabled != true` —
  объясни что команда только для data-mart проектов и предложи
  заполнить конфиг.