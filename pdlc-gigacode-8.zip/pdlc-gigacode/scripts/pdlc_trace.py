#!/usr/bin/env python3
"""Polisade Orchestrator — Structured event tracing (OPS-043).

Each /pdlc:* skill run writes structured events to:
    .pdlc/traces/<command>-<timestamp>.jsonl

Events are newline-delimited JSON. Each event has:
    - `ts` (ISO 8601, UTC)
    - `phase` (string from a known vocabulary)
    - `command` (e.g. "implement", "tasks", "review-pr")
    - `task_id` (optional)
    - `subagent_id` (optional, for events scoped to a subagent run)
    - `decision` (optional, what the agent decided)
    - `tokens_used` (optional, when known)
    - `payload` (optional, freeform dict for context)

Phase vocabulary (extensible — unknown phases are accepted):
    command_started, command_completed, command_failed
    context_built, context_failed
    subagent_prompt_sent, subagent_completed, subagent_failed,
    subagent_retry
    tool_called, tool_failed
    verification_step, verification_passed, verification_failed
    pm_gate, pm_resumed
    state_updated
    error, warning

CLI usage from skills (bash):
    python3 scripts/pdlc_trace.py log \\
        --phase subagent_started \\
        --command implement \\
        --task-id TASK-001 \\
        --payload '{"subagent_type":"general-purpose"}'

CLI usage for inspection:
    python3 scripts/pdlc_trace.py tail        # last 20 events from latest trace
    python3 scripts/pdlc_trace.py tail -n 50  # last 50 events
    python3 scripts/pdlc_trace.py list        # all trace files with metadata
    python3 scripts/pdlc_trace.py show <file> # full trace pretty-printed

Python import usage (preferred when available):
    from pdlc_trace import log_event
    log_event(phase="subagent_started", command="implement",
              task_id="TASK-001", payload={"...": "..."})

Always best-effort: if the trace file can't be written (permissions,
disk full, etc.), the function silently returns False. Tracing must
never break the actual workflow.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

TRACE_VERSION = "1.0"
TRACE_DIR_REL = ".pdlc/traces"

# Known phases — for documentation. Unknown phases are still accepted.
KNOWN_PHASES = {
    "command_started", "command_completed", "command_failed",
    "context_built", "context_failed",
    "subagent_prompt_sent", "subagent_completed", "subagent_failed",
    "subagent_retry",
    "tool_called", "tool_failed",
    "verification_step", "verification_passed", "verification_failed",
    "pm_gate", "pm_resumed",
    "state_updated",
    "error", "warning",
}


def _trace_dir(project_root: Path) -> Path:
    return project_root / TRACE_DIR_REL


def _current_trace_file(project_root: Path, command: str) -> Path:
    """Return path to the active trace file for a given command.

    Strategy: if the env var PDLC_TRACE_FILE is set — use that exact path.
    Otherwise, look for the most recent file matching `<command>-*.jsonl`
    in the trace dir from the last 10 minutes. If none exists — create
    a new one with current timestamp.
    """
    explicit = os.environ.get("PDLC_TRACE_FILE")
    if explicit:
        return Path(explicit)

    d = _trace_dir(project_root)
    d.mkdir(parents=True, exist_ok=True)
    # Find most recent <command>-*.jsonl file, modified in last 10 min
    now = time.time()
    candidates = []
    for f in d.glob(f"{command}-*.jsonl"):
        try:
            age = now - f.stat().st_mtime
        except OSError:
            continue
        if age < 600:  # 10 min
            candidates.append((age, f))
    if candidates:
        candidates.sort()
        return candidates[0][1]

    # New trace file — name with current UTC timestamp
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return d / f"{command}-{ts}.jsonl"


def log_event(
    *,
    phase: str,
    command: str = "unknown",
    project_root: Path | str | None = None,
    task_id: str | None = None,
    subagent_id: str | None = None,
    decision: str | None = None,
    tokens_used: int | None = None,
    payload: dict[str, Any] | None = None,
) -> bool:
    """Write a single event to the active trace file. Best-effort.

    Returns True if write succeeded, False otherwise. Never raises.
    """
    try:
        root = Path(project_root) if project_root else Path(os.environ.get("PDLC_WORK_DIR", "."))
        root = root.resolve()
        path = _current_trace_file(root, command)
        path.parent.mkdir(parents=True, exist_ok=True)

        event = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "trace_version": TRACE_VERSION,
            "phase": phase,
            "command": command,
        }
        if task_id is not None:
            event["task_id"] = task_id
        if subagent_id is not None:
            event["subagent_id"] = subagent_id
        if decision is not None:
            event["decision"] = decision
        if tokens_used is not None:
            event["tokens_used"] = tokens_used
        if payload is not None:
            event["payload"] = payload

        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
        return True
    except Exception:
        # Tracing must never break the workflow.
        return False


# ---------------------------------------------------------------------------
# Inspection helpers
# ---------------------------------------------------------------------------


def _all_trace_files(root: Path) -> list[Path]:
    d = _trace_dir(root)
    if not d.is_dir():
        return []
    return sorted(d.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)


def cmd_tail(args: argparse.Namespace) -> int:
    root = Path(args.project_root).resolve()
    files = _all_trace_files(root)
    if not files:
        print("No trace files found.", file=sys.stderr)
        return 1
    target = files[0]
    n = args.n
    try:
        lines = target.read_text(encoding="utf-8").splitlines()
    except OSError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    tail = lines[-n:]
    print(f"# {target} (showing last {len(tail)} of {len(lines)} events)")
    for line in tail:
        try:
            event = json.loads(line)
            ts = event.get("ts", "?").split("T")[1].split(".")[0] if "T" in event.get("ts", "") else "?"
            phase = event.get("phase", "?")
            tid = event.get("task_id", "")
            tid_str = f" {tid}" if tid else ""
            decision = event.get("decision", "")
            decision_str = f" → {decision}" if decision else ""
            print(f"  {ts} [{phase}]{tid_str}{decision_str}")
        except json.JSONDecodeError:
            print(f"  {line}")
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    root = Path(args.project_root).resolve()
    files = _all_trace_files(root)
    if not files:
        print("No trace files found.")
        return 0
    print(f"Trace dir: {_trace_dir(root)}")
    for f in files:
        try:
            stat = f.stat()
            size_kb = stat.st_size / 1024
            mtime = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
            # Quick line count
            try:
                with f.open("r", encoding="utf-8") as fh:
                    line_count = sum(1 for _ in fh)
            except OSError:
                line_count = -1
            print(f"  {f.name:50}  {size_kb:>6.1f}K  {line_count:>5} events  {mtime}")
        except OSError:
            print(f"  {f.name:50}  (unreadable)")
    return 0


def cmd_show(args: argparse.Namespace) -> int:
    root = Path(args.project_root).resolve()
    target_arg = args.file
    target = Path(target_arg)
    if not target.is_absolute():
        # Try relative to trace dir
        target = _trace_dir(root) / target_arg
    if not target.exists():
        print(f"error: file not found: {target}", file=sys.stderr)
        return 2
    try:
        for line in target.read_text(encoding="utf-8").splitlines():
            try:
                event = json.loads(line)
                # Pretty-print as JSON object
                print(json.dumps(event, indent=2, ensure_ascii=False))
                print("---")
            except json.JSONDecodeError:
                print(line)
    except OSError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    return 0


def cmd_log(args: argparse.Namespace) -> int:
    """CLI entry-point for shell-level logging from skills."""
    payload = None
    if args.payload:
        try:
            payload = json.loads(args.payload)
        except json.JSONDecodeError as e:
            print(f"warning: --payload not valid JSON ({e}), storing as string", file=sys.stderr)
            payload = {"raw": args.payload}

    ok = log_event(
        phase=args.phase,
        command=args.command,
        project_root=args.project_root,
        task_id=args.task_id,
        subagent_id=args.subagent_id,
        decision=args.decision,
        tokens_used=args.tokens_used,
        payload=payload,
    )
    return 0 if ok else 1


def cmd_log_view(args: argparse.Namespace) -> int:
    """OPS-052: Convert structured trace events to a human-readable
    log format and write to debug_pdlc.log (or specified --output).

    Produces:
      [12:53:33] command_started   /pdlc:implement TASK-001
      [12:53:34] context_built     TASK-001 (tokens=3380)
      [12:53:35] subagent_prompt   TASK-001 sa=sa-1 (template=A)
      [12:53:42] subagent_failed   TASK-001 sa=sa-1 → retry
      [12:53:43] subagent_retry    TASK-001 (reduced context)
      [12:54:00] subagent_complete TASK-001 sa=sa-2 (tokens=4500)
      [12:54:00] command_complete  TASK-001 → pr_created
    """
    root = Path(args.project_root).resolve()
    out_path = Path(args.output) if args.output else (root / "debug_pdlc.log")
    if not out_path.is_absolute():
        out_path = root / out_path

    files = _all_trace_files(root)
    if args.all:
        targets = files
    else:
        targets = files[:1] if files else []

    if not targets:
        print("No trace files to convert.", file=sys.stderr)
        return 1

    lines_out = []
    for tf in reversed(targets):  # oldest first when --all
        lines_out.append(f"# === Trace: {tf.name} ===")
        try:
            for raw in tf.read_text(encoding="utf-8").splitlines():
                try:
                    e = json.loads(raw)
                except json.JSONDecodeError:
                    lines_out.append(f"  [parse-error] {raw[:200]}")
                    continue
                ts = e.get("ts", "?")
                # Extract HH:MM:SS portion
                if "T" in ts:
                    short_ts = ts.split("T")[1].split(".")[0].split("+")[0]
                else:
                    short_ts = ts[:19]
                phase = e.get("phase", "?")
                cmd_str = e.get("command", "")
                tid = e.get("task_id", "")
                sa = e.get("subagent_id", "")
                dec = e.get("decision", "")
                tokens = e.get("tokens_used")
                payload = e.get("payload") or {}

                # Build human-readable context fields
                fields = []
                if cmd_str and cmd_str != "unknown":
                    fields.append(f"/pdlc:{cmd_str}")
                if tid:
                    fields.append(tid)
                if sa:
                    fields.append(f"sa={sa}")
                if dec:
                    fields.append(f"→ {dec}")
                if tokens is not None:
                    fields.append(f"tokens={tokens}")
                # Useful payload subset
                for key in ("status", "files_changed", "reason",
                            "tool_calls_before_fail", "score", "iteration"):
                    if key in payload:
                        val = payload[key]
                        if isinstance(val, list):
                            fields.append(f"{key}={len(val)}")
                        else:
                            fields.append(f"{key}={val}")

                fields_str = " ".join(fields) if fields else ""
                lines_out.append(f"  [{short_ts}] {phase:22} {fields_str}")
        except OSError as e:
            lines_out.append(f"  [read-error] {e}")
        lines_out.append("")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines_out) + "\n", encoding="utf-8")
    print(f"Wrote {sum(1 for line in lines_out if line.startswith('  ['))} events to {out_path}")
    return 0


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pdlc_trace.py",
        description="Polisade structured event tracing.",
    )
    p.add_argument("--project-root", default=".", help="Project root (default: cwd)")
    sub = p.add_subparsers(dest="mode", required=True)

    s_log = sub.add_parser("log", help="Append an event to the active trace")
    s_log.add_argument("--phase", required=True)
    s_log.add_argument("--command", default="unknown")
    s_log.add_argument("--task-id", default=None)
    s_log.add_argument("--subagent-id", default=None)
    s_log.add_argument("--decision", default=None)
    s_log.add_argument("--tokens-used", type=int, default=None)
    s_log.add_argument("--payload", default=None,
                       help="JSON string with arbitrary context")
    s_log.set_defaults(func=cmd_log)

    s_tail = sub.add_parser("tail", help="Show last N events from the latest trace")
    s_tail.add_argument("-n", type=int, default=20)
    s_tail.set_defaults(func=cmd_tail)

    s_list = sub.add_parser("list", help="List all trace files with metadata")
    s_list.set_defaults(func=cmd_list)

    s_show = sub.add_parser("show", help="Pretty-print a trace file")
    s_show.add_argument("file")
    s_show.set_defaults(func=cmd_show)

    s_log_view = sub.add_parser(
        "log-view",
        help=(
            "Convert structured trace into human-readable debug_pdlc.log. "
            "Useful when PM wants 'all debug output in a file' (OPS-052)."
        ),
    )
    s_log_view.add_argument(
        "--output", default=None,
        help="Output file path (default: <project-root>/debug_pdlc.log)"
    )
    s_log_view.add_argument(
        "--all", action="store_true",
        help="Include all trace files (default: only the latest)"
    )
    s_log_view.set_defaults(func=cmd_log_view)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = make_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
