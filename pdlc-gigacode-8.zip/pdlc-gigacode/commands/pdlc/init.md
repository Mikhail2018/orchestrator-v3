---
description: Initialize Polisade Orchestrator project structure
---

<!-- argument hint: [ProjectName] -->

Scaffold the full Polisade Orchestrator autonomous development framework into the current project.

## Usage

```
/pdlc:init MyProject
/pdlc:init              # uses current directory name
```

## What it creates

```
.state/
├── PROJECT_STATE.json
├── counters.json
└── knowledge.json

docs/
├── prd/
├── specs/
├── plans/
├── adr/
├── architecture/   # design packages from /pdlc:design
├── contracts/
│   ├── README.md       # integration map
│   ├── provided/       # contracts we provide (OpenAPI, AsyncAPI, Protobuf…)
│   └── consumed/       # contracts we consume from external systems (read-only)
└── templates/
    ├── prd-template.md
    ├── spec-template.md
    ├── plan-template.md
    ├── feature-brief-template.md
    ├── task-template.md
    ├── adr-template.md
    ├── chore-template.md
    ├── spike-template.md
    └── design-package-template.md

backlog/
├── features/
├── bugs/
├── tech-debt/
├── chores/
└── spikes/

tasks/

GIGACODE.md
.gitignore (updated)
```

## Algorithm

1. If `{{args}}` is provided, use it as project name. Otherwise use the current directory name.

   **Working directory hygiene (OPS-050):** all subsequent shell commands
   in this skill MUST run from the **project root** (cwd at skill entry).
   Before any shell command:

   ```bash
   PROJECT_ROOT="${PDLC_WORK_DIR:-$(pwd)}"
   cd "$PROJECT_ROOT"
   ```

   This protects against:
   - Subagent / tool calls that may have changed cwd silently
   - Recursive listing commands accidentally scanning system directories
     (Recycle Bin, mounted drives) when cwd is at filesystem root
   - PM running `/pdlc:init` from inside `$HOME` or `C:\` by mistake

   If `pwd` returns the user's home directory or root (`/`, `C:\`, `D:\`)
   — STOP and ask PM «You're trying to initialize Polisade in `{pwd}`.
   This is unusual. Please `cd` to the actual project directory first».

2. Check if Polisade Orchestrator is already initialized:
   - If `.state/PROJECT_STATE.json` exists → warn and ask to confirm overwrite

3. Create directory structure:
   ```
   mkdir -p .state
   mkdir -p docs/prd docs/specs docs/plans docs/adr docs/architecture docs/contracts/provided docs/contracts/consumed docs/templates
   mkdir -p backlog/features backlog/bugs backlog/tech-debt backlog/chores backlog/spikes
   mkdir -p tasks
   ```

4. Copy template files from plugin templates directory.

   The plugin templates are located at: `${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/templates/init/` relative to the plugin root
   (or, for converted bundles, at `templates/init/` inside the extension dir).

   ⚠️ **OPS-051 — НЕ используй Read tool для template files.**

   Причина: в некоторых CLI (GigaCode на Windows) Read tool блокирует
   пути вне workspace, а templates лежат в установленной директории
   плагина — это **вне** workspace проекта пользователя. ReadFile
   возвращает ошибку «File path must be within one of the workspace
   directories», и PM видит 9-10 строк failures + 9-10 allow-prompts.

   ✅ **Используй shell `cp` для бинарного-копирования и `cat` для
   trivial-чтения** — shell-команды через Bash tool работают для путей
   вне workspace (с одним `Yes, allow always` в начале сессии).

   **Алгоритм копирования (для каждого template файла):**

   ```bash
   # PDLC_PLUGIN_ROOT is set by the host CLI (e.g., GigaCode sets it
   # to ~/.gigacode/extensions/pdlc/). Fall back to common install paths.
   PLUGIN_ROOT=${PDLC_PLUGIN_ROOT:-}
   if [ -z "$PLUGIN_ROOT" ]; then
       for candidate in \
           "$HOME/.claude/plugins/pdlc" \
           "$HOME/.gigacode/extensions/pdlc" \
           "$HOME/.gigacode/extensions/pdlc"; do
           if [ -d "$candidate/templates/init" ]; then
               PLUGIN_ROOT=$candidate
               break
           fi
       done
   fi
   if [ -z "$PLUGIN_ROOT" ]; then
       echo "ERROR: cannot locate plugin root; set PDLC_PLUGIN_ROOT" >&2
       exit 1
   fi

   # Copy as a single batch — minimizes per-file allow prompts
   cp "$PLUGIN_ROOT/templates/init/PROJECT_STATE.json" .state/PROJECT_STATE.json
   cp "$PLUGIN_ROOT/templates/init/counters.json"      .state/counters.json
   cp "$PLUGIN_ROOT/templates/init/knowledge.json"     .state/knowledge.json
   cp "$PLUGIN_ROOT/templates/init/GIGACODE.md"          GIGACODE.md
   cp "$PLUGIN_ROOT/templates/init/docs/"*.md          docs/templates/
   cp "$PLUGIN_ROOT/templates/init/docs/contracts-readme-template.md" docs/contracts/README.md
   touch docs/contracts/provided/.gitkeep
   touch docs/contracts/consumed/.gitkeep
   ```

   **Fallback если `cp` не доступен** (нет Bash tool, или путь
   нерезолвится): один-единственный `cat` через shell:
   ```bash
   cat "${PLUGIN_ROOT}/templates/init/PROJECT_STATE.json" > .state/PROJECT_STATE.json
   ```

   ⛔ **НЕ используй** Read tool для этих файлов. Read tool — для
   user's workspace files, не для plugin internals.

   **После копирования** — Read tool можно использовать (теперь файлы
   в workspace) для шага 6 (update knowledge.json) — это нормально.

   Files to copy (для справки, копирование делает shell-команда выше):
   - `templates/init/PROJECT_STATE.json` → `.state/PROJECT_STATE.json`
   - `templates/init/counters.json` → `.state/counters.json`
   - `templates/init/knowledge.json` → `.state/knowledge.json`
     (project name будет обновлён в шаге 6 через Edit/str_replace)
   - `templates/init/GIGACODE.md` → `GIGACODE.md`
   - `templates/init/docs/*.md` → `docs/templates/*.md` (all 9 templates)
   - `templates/init/docs/contracts-readme-template.md` → `docs/contracts/README.md`
   - Create empty `docs/contracts/provided/.gitkeep`
   - Create empty `docs/contracts/consumed/.gitkeep`

5. Update `.gitignore` — append Polisade Orchestrator-specific entries if not already present:
   ```
   # Polisade Orchestrator state (regenerated by Claude)
   .state/
   !.state/knowledge.json

   # Polisade Orchestrator worktrees (git worktree isolation)
   .worktrees/

   # PDLC intermediate artefacts — project-local temp dir
   # (issue #57 / legacy OPS-009; /tmp is sandboxed in GigaCode CLI).
   .pdlc/tmp/

   # CLI extensions — service dirs (issue #74 / OPS-027).
   # NB: .claude/ intentionally excluded — settings.json is committed.
   .gigacode/
   .qwen/
   .codex/
   ```

   Append is **idempotent** — each line is added only if not already present in `.gitignore`.

6. Update `knowledge.json` with the project name from arguments.

6.5. Update `PROJECT_STATE.json` — set `project.name` from the project name argument.

6.6. **Tech stack autodetect** — scan project root for stack markers and pre-fill `knowledge.json`:

   Markers to check:
   - `package.json` → Node.js/TypeScript (check `dependencies`/`devDependencies`)
   - `tsconfig.json` → TypeScript (even without package.json, e.g. Deno)
   - `go.mod` → Go
   - `pyproject.toml` / `requirements.txt` / `setup.py` → Python
   - `Cargo.toml` → Rust
   - `pom.xml` / `build.gradle` / `build.gradle.kts` → Java/Kotlin
   - `build.sbt` / `.scalafmt.conf` → Scala/sbt
   - `gradlew` / `mvnw` → JVM wrapper scripts (Gradle/Maven)
   - `application.yml` / `application.properties` → Spring Boot
   - `*.csproj` / `*.sln` → C# / .NET
   - `docker-compose.yml` → infrastructure hints (DB, cache, queue, Kafka)
   - `.env.example` → environment variables
   - `Makefile` / `Justfile` → build/test commands
   - `jest.config.*` / `vitest.config.*` / `pytest.ini` / `.rspec` → test framework
   - `playwright.config.*` → Playwright (E2E)
   - `cucumber.yml` / `features/*.feature` → Cucumber (BDD)

   For each detected marker, update `knowledge.json`:
   - `projectContext.techStack` — append detected languages, frameworks, databases, infra
   - `testing.testCommand` — infer test command (e.g. `npm test`, `./gradlew test`, `sbt test`, `npx playwright test`, `npx cucumber-js`)
   - `testing.lintCommand` — infer lint command if detectable (e.g. `npx eslint .`, `./gradlew check`, `sbt scalafmtCheck`)

   This is best-effort: if nothing is detected, leave fields empty — `/pdlc:spec` and `/pdlc:design` will ask during their interview.

6.7. **VCS provider setup** — ask the PM which VCS hosts the project:

   Options:
   - `github` — GitHub cloud via `gh` CLI (default).
   - `bitbucket-server` — self-hosted Bitbucket Server (corporate, via REST API).

   Record the choice in `.state/PROJECT_STATE.json → settings.vcsProvider`.

   If the PM selects `bitbucket-server`:

   a) Copy `${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/templates/init/env.example` to the project root in **two** targets:
      - `.env.example` — reference that can be committed.
      - `.env` — stub for the PM to fill in (tokens and URLs). **Do not overwrite
        an existing `.env`.**

   b) Append an uncommented `.env` line to `.gitignore` if not already present.
      Match regex `^\s*\.env(\s|$)` on each non-`#` line to avoid false positives
      from pre-existing `# .env` template comments. If no match, append:
      ```
      # VCS provider (.env contains Bitbucket tokens)
      .env
      ```

   c) Remind the PM:
      ```
      ⚠️ Заполни BITBUCKET_DOMAIN1_URL / BITBUCKET_DOMAIN1_TOKEN (и/или DOMAIN2) в .env
      перед первым /pdlc:implement. Проверь через /pdlc:doctor.
      ```

   This logic is duplicated in `scripts/pdlc_migrate.py` (`compute_vcs_bootstrap_migrations`)
   so that existing projects can switch to Bitbucket later via `/pdlc:migrate --apply`.

6.8. **Verification of created structure** — НЕ нужна.

   `mkdir -p` идемпотентен и тихо успешен. Если вы успешно его выполнили,
   структура существует. Не нужно дополнительно проверять её через
   `dir`, `ls -R`, `find . -type d`, или подобные команды.

   ⛔ **ОСОБОЕ ПРАВИЛО:** не используй рекурсивный listing (`dir /s`,
   `dir /b /s`, `ls -R`, `find . ...` без `-maxdepth`) для проверки
   структуры. Это может уйти в Recycle Bin, mounted drives, или
   системные директории и принести **тысячи строк** мусора в context.

   Real-world incident (2026-05-06): агент в `/pdlc:init` запустил
   `dir /b /s ".state" "docs" "backlog" "tasks" 2>nul | find /c /v ""`,
   который рекурсивно прошёлся через `C:/$RECYCLE.BIN/`, вернув 5960+
   строк мусора из удалённых проектов в Корзине Windows.

   ✅ **Если PM явно требует verification** — используй простую
   existence-проверку:

   ```bash
   [ -d ".state" ] && [ -d "docs" ] && [ -d "backlog" ] && [ -d "tasks" ] \
       && echo "Structure verified"
   ```

   или (windows-friendly POSIX):

   ```bash
   ls -d .state docs backlog tasks 2>/dev/null | wc -l
   # Должно вывести: 4
   ```

   Эти команды **не рекурсивные**, не уйдут в Recycle Bin.

7. Output confirmation:

```
═══════════════════════════════════════════
Polisade Orchestrator INITIALIZED
═══════════════════════════════════════════

Project: {ProjectName}
Directory: {cwd}

Created:
  ✓ .state/ — project state files
  ✓ docs/templates/ — 9 document templates
  ✓ docs/architecture/ — design packages (created on demand by /pdlc:design)
  ✓ docs/contracts/ — integration contracts (provided/consumed)
  ✓ backlog/ — features, bugs, tech-debt, chores, spikes
  ✓ tasks/ — work items
  ✓ GIGACODE.md — framework instructions

Detected stack:                        ← only if autodetect found anything
  • TypeScript 5, Express 4
  • PostgreSQL 16, Redis 7
  • Jest (unit), Playwright (E2E)
  (saved to .state/knowledge.json)

═══════════════════════════════════════════
NEXT STEPS:
   → /pdlc:feature "Description" — add a feature
   → /pdlc:prd "Name" — create PRD for large initiative
   → /pdlc:state — view project status
   → /pdlc:continue — start autonomous work
═══════════════════════════════════════════
```