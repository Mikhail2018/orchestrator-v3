# pdlc — Qwen extension

Version: `2.24.0`

Polisade Orchestrator — autonomous development framework by Polisade. The agent operates as a full dev team: implement → test → PR → review → merge. (Technical id: pdlc)

## About

This Qwen CLI extension was converted from a Claude Code plugin of the same name. It provides **26 slash commands** under the `/pdlc:` namespace.

## Bundled paths

- **Extension root**: `$HOME/.gigacode/extensions/pdlc`
- **Scripts**: `$HOME/.gigacode/extensions/pdlc/scripts/` — Python helpers called by commands.
- **Templates**: `$HOME/.gigacode/extensions/pdlc/templates/` — files copied into target projects by setup commands.

Command bodies resolve the extension root via the `PDLC_PLUGIN_ROOT` environment variable, with a fallback to the literal path shown above (bash expands `$HOME` at invocation time). Override when the extension lives elsewhere:

  a) `export PDLC_PLUGIN_ROOT=<new_path>` in your shell rc, or
  b) rerun the converter with `--fallback-plugin-root <path>` to bake a different default.

## Non-interactive invocation

Interactive REPL approves shell calls inline. For scripted use with `-p '/pdlc:<cmd>'`, bypass the approval gate:

```bash
qwen --allowed-tools=run_shell_command -p '/pdlc:review-pr 21'
```

The CLI's own hint (`--approval-mode=auto-edit`) covers edit tools only, not shell.

## Commands

- `/pdlc:chore` — Capture a simple task that does not need planning (CHORE + TASK in readyToWork by default, or registration-only with --no-task). Use when PM mentions "simple task", "chore", "small task", "housekeeping", "quick task", "мелкая задача", "чора", or any request to log routine work without PRD/SPEC overhead. Trigger liberally — under-triggering pushes tiny work into freeform chat; over-triggering is recoverable (PM can delete).
- `/pdlc:codex-review` — [DEPRECATED] Renamed to /pdlc:review (OPS-017). Alias kept for one release. *(deprecated)*
- `/pdlc:codex-review-pr` — [DEPRECATED] Renamed to /pdlc:review-pr (OPS-017). Alias kept for one release. *(deprecated)*
- `/pdlc:continue` — Autonomous work — find and execute ready tasks. Use when PM mentions "continue", "продолжай", "автономно работай", "find next ready task", "do next task", "go next".
- `/pdlc:debt` — Record a technical-debt item (DEBT-NNN) — registration only by default, or register + auto-generate a fix TASK with --task. Use when PM mentions "add tech debt", "record tech debt", "technical debt", "tech debt item", "refactor tracking", "технический долг", "запиши техдолг", or any request to capture deferred refactoring / cleanup work. Trigger liberally — under-triggering loses debt visibility; over-triggering is recoverable (PM can delete or defer).
- `/pdlc:defect` — Register a defect (BUG-NNN) and auto-generate the fix TASK so the bug enters the normal implement/review flow. Use when PM mentions "file a bug", "report defect", "bug report", "register defect", "report a bug", "заведи баг", "баг-репорт", or any request to capture a defect for tracking. Trigger liberally — under-triggering leaves bugs in chat where they get lost; over-triggering is recoverable (PM can delete the BUG artefact).
- `/pdlc:design` — Create a doc-as-code design package from a PRD or SPEC. Conditionally generates C4 diagrams (Context/Container/Component), sequence diagrams, ER diagram + Data Dictionary, OpenAPI 3.0, AsyncAPI 3.0, ADRs, domain glossary, state diagrams, and deployment view as Mermaid-rendered Markdown files. Use when PM mentions "design", "architecture diagrams", "doc-as-code artifacts", "C4", "ERD", "OpenAPI spec", "AsyncAPI", "event-driven", "Kafka", "message broker", "sequence diagram", "state machine", "domain glossary", "ADR", or before handing a SPEC to another team. Trigger liberally — undertriggering loses architectural value, overtriggering is recoverable (PM can delete).
- `/pdlc:doctor` — Diagnose Polisade Orchestrator project health. Use when PM mentions "diagnose", "doctor", "health check", "validate project state", "check pdlc", "проверь состояние", "продиагностируй".
- `/pdlc:feature` — Create a lightweight Feature Brief (FEAT-NNN) for incremental product work that does not warrant a full PRD. Use when PM mentions "create a feature", "add feature brief", "new feature work", "feature request", "add FEAT", "заведи фичу", "новая фича", or any request to capture a small-to-medium feature without PRD-level process. Trigger liberally — under-triggering forces the agent to improvise freeform docs; over-triggering is recoverable (PM can delete or upgrade to PRD).
- `/pdlc:implement` — Implement TASK end-to-end through TDD-first cycle. Use when PM mentions "implement TASK", "реализуй задачу", "do TASK", "code this task", "сделай таск".
- `/pdlc:init` — Initialize Polisade Orchestrator project structure. Use when PM mentions "init project", "initialize", "scaffold polisade", "set up polisade", "иницилизируй", "создай проект".
- `/pdlc:lint-skills` — Lint and validate Polisade Orchestrator skill definitions. Use when PM mentions "lint skills", "validate skill definitions", "check skill consistency", "проверь скилы".
- `/pdlc:migrate` — Upgrade PROJECT_STATE.json schema to current version. Use when PM mentions "migrate", "upgrade schema", "schema migration", "обнови схему", "мигрируй state".
- `/pdlc:pr` — Provider-agnostic PR operations (GitHub / Bitbucket Server) for PM — create, list, view, diff, merge, comment, close, whoami. Use when PM mentions "open a PR", "create pull request", "push and open PR", "submit for review", "commit and open PR", "merge PR", "review PR status", "закоммить и сделай pr", "сделай пиар", "сделай pr", or any request to operate on GitHub / Bitbucket Server pull requests. Trigger liberally — skipping forces the agent to improvise with ad-hoc REST calls that bypass OPS-028 push verification; over-triggering is recoverable (PM can redirect).
- `/pdlc:prd` — Create a full Product Requirements Document (PRD-NNN) via a structured PM interview — for large initiatives that justify the overhead. Use when PM mentions "create PRD", "write product requirements", "PRD document", "product brief", "requirements doc", "напиши PRD", "создай PRD", or any request to capture a full product vision before handing to design / engineering. Trigger liberally — under-triggering forces the agent to write freeform docs that drift from the canonical PRD template; over-triggering is recoverable (PM can downgrade to Feature Brief).
- `/pdlc:questions` — Show and manage open questions across all artifacts. Use when PM mentions "show questions", "open questions", "pending questions", "покажи вопросы", "открытые вопросы".
- `/pdlc:reconcile-docs` — Show drift between design artifacts and implemented code (advisory). Use when PM mentions "reconcile docs", "drift between design and code", "docs vs code", "design drift", "сверь docs", "проверь doc-vs-code".
- `/pdlc:review` — Run a second-opinion quality review on a completed TASK via an independent clean-context subagent (self-review path only on Qwen/GigaCode; the `self` flag is accepted for Claude/Codex parity and is a no-op here). Use when PM mentions "review TASK", "second opinion", "check my implementation", "codex review", "self-review", "review task", "сделай ревью", or any request to get another pass over TASK work before marking it done. Trigger liberally — under-triggering lets half-baked TASKs land without a second look; over-triggering is recoverable (PM can accept the review output and move on).
- `/pdlc:review-pr` — Run a quality review on an open pull request (by PR number or linked TASK) via an independent clean-context subagent and post the verdict (self-review path only on Qwen/GigaCode; the `self` flag is accepted for Claude/Codex parity and is a no-op here). Use when PM mentions "review PR", "PR review", "review pull request", "quality review", "review this pr", "сделай ревью pr", or any request to evaluate an open PR before merge. Trigger liberally — under-triggering lets PRs land without a second look; over-triggering is recoverable (PM can ignore the review comments).
- `/pdlc:roadmap` — Build an implementation PLAN (PLAN-NNN) from a technical SPEC — milestones, phases, dependencies — via a clean-context subagent. Use when PM mentions "create PLAN", "plan from SPEC", "roadmap", "implementation plan", "milestones", "create roadmap", "сделай план", or any request to sequence SPEC work into execution phases. Trigger liberally — under-triggering lets the agent jump straight to TASKs without a milestone view; over-triggering is recoverable (PM can delete or regenerate).
- `/pdlc:spec` — Generate a technical SPEC (SPEC-NNN) from an existing PRD or Feature Brief via a clean-context subagent. Use when PM mentions "create SPEC", "write spec", "turn PRD into SPEC", "functional spec", "specification from PRD", "создай spec", "напиши спеку", or any request to translate product intent into engineering-ready specification. Trigger liberally — under-triggering forces the agent to improvise design/API calls in chat without the canonical SPEC template; over-triggering is recoverable (PM can delete or regenerate).
- `/pdlc:spike` — Create a timeboxed research SPIKE-NNN for answering an open technical / product question before committing to implementation. Use when PM mentions "research task", "spike", "investigation", "research question", "explore a problem", "ресёрч", "спайк", or any request to investigate an unknown before locking a design. Trigger liberally — under-triggering forces the agent to speculate without recording the research trail; over-triggering is recoverable (PM can close the spike early).
- `/pdlc:state` — Show project status across all artifacts and tasks. Use when PM mentions "show state", "project status", "current state", "what is in progress", "статус проекта", "покажи состояние".
- `/pdlc:sync` — Rebuild PROJECT_STATE derived fields from artifact files. Use when PM mentions "sync", "rebuild project state", "rebuild from artifacts", "пересобери state", "синхронизируй".
- `/pdlc:tasks` — Decompose a PLAN / SPEC / FEAT / BUG / DEBT / CHORE into atomic TASK-NNN items ready for the implement flow, via a clean-context subagent. Use when PM mentions "create tasks", "generate TASKs", "break down into tasks", "tasks from PLAN", "break this into tasks", "декомпозиция", "сделай таски", or any request to explode upstream artefacts into executable work. Trigger liberally — under-triggering forces ad-hoc task-creation in chat that drifts from backlog conventions; over-triggering is recoverable (PM can delete).
- `/pdlc:unblock` — Answer PM questions and unblock tasks waiting for input. Use when PM mentions "unblock", "answer PM questions", "resolve waiting_pm", "разблокируй", "ответы PM".

## Natural-language intent → command routing

If the user's natural-language request matches any of the phrases below, invoke the matching slash command directly. This augments skill auto-discovery — both paths are acceptable.

- "simple task", "chore", "small task", "housekeeping", "quick task", "мелкая задача", "чора" → `/pdlc:chore`
- "continue", "продолжай", "автономно работай", "find next ready task", "do next task", "go next" → `/pdlc:continue`
- "add tech debt", "record tech debt", "technical debt", "tech debt item", "refactor tracking", "технический долг", "запиши техдолг" → `/pdlc:debt`
- "file a bug", "report defect", "bug report", "register defect", "заведи баг", "баг-репорт", "report a bug" → `/pdlc:defect`
- "design", "architecture diagrams", "doc-as-code artifacts", "C4", "ERD", "OpenAPI spec", "AsyncAPI", "event-driven", "Kafka", "message broker", "sequence diagram", "state machine", "domain glossary", "ADR" → `/pdlc:design`
- "diagnose", "doctor", "health check", "validate project state", "check pdlc", "проверь состояние", "продиагностируй" → `/pdlc:doctor`
- "create a feature", "add feature brief", "new feature work", "feature request", "add FEAT", "заведи фичу", "новая фича" → `/pdlc:feature`
- "implement TASK", "реализуй задачу", "do TASK", "implement", "code this task", "сделай таск" → `/pdlc:implement`
- "initialize", "init project", "scaffold polisade", "set up polisade", "иницилизируй", "создай проект" → `/pdlc:init`
- "lint skills", "validate skill definitions", "check skill consistency", "проверь скилы" → `/pdlc:lint-skills`
- "migrate", "upgrade schema", "schema migration", "обнови схему", "мигрируй state" → `/pdlc:migrate`
- "open a PR", "create pull request", "push and open PR", "submit for review", "commit and open PR", "merge PR", "review PR status", "закоммить и сделай pr", "сделай пиар", "сделай pr" → `/pdlc:pr`
- "create PRD", "write product requirements", "PRD document", "product brief", "напиши PRD", "создай PRD", "requirements doc" → `/pdlc:prd`
- "show questions", "open questions", "pending questions", "покажи вопросы", "открытые вопросы" → `/pdlc:questions`
- "reconcile docs", "drift between design and code", "docs vs code", "design drift", "сверь docs", "проверь doc-vs-code" → `/pdlc:reconcile-docs`
- "review TASK", "second opinion", "check my implementation", "codex review", "self-review", "review task", "сделай ревью" → `/pdlc:review`
- "review PR", "PR review", "review pull request", "quality review", "review this pr", "сделай ревью pr" → `/pdlc:review-pr`
- "create PLAN", "plan from SPEC", "roadmap", "implementation plan", "milestones", "сделай план", "create roadmap" → `/pdlc:roadmap`
- "create SPEC", "write spec", "turn PRD into SPEC", "functional spec", "specification from PRD", "создай spec", "напиши спеку" → `/pdlc:spec`
- "research task", "spike", "investigation", "research question", "explore a problem", "ресёрч", "спайк" → `/pdlc:spike`
- "show state", "project status", "current state", "what is in progress", "статус проекта", "покажи состояние" → `/pdlc:state`
- "sync", "rebuild project state", "rebuild from artifacts", "пересобери state", "синхронизируй" → `/pdlc:sync`
- "create tasks", "generate TASKs", "break down into tasks", "декомпозиция", "tasks from PLAN", "сделай таски", "break this into tasks" → `/pdlc:tasks`
- "unblock", "answer PM questions", "resolve waiting_pm", "разблокируй", "ответы PM" → `/pdlc:unblock`

## Conversion warnings

- templates/init: renamed CLAUDE.md → GIGACODE.md (Qwen convention)
- templates/init: skipped Claude Code permission file settings.json (no equivalent in Qwen)
- commands/pdlc/lint-skills.md references plugin internals — likely a meta-skill that won't function in the converted extension
- scripts/pdlc_doctor.py reads .claude/settings.json — this code path is dead in the Qwen extension; consider removing the function manually
- scripts/pdlc_lint_skills.py references .claude-plugin/ — this Claude Code plugin path doesn't exist in the converted Qwen extension
- scripts/pdlc_migrate.py reads .claude/settings.json — this code path is dead in the Qwen extension; consider removing the function manually
- scripts/pdlc_install_templates.py reads .claude/settings.json — this code path is dead in the Qwen extension; consider removing the function manually
- overlay: skipped 1 files outside known extension subdirs (agents, assets, commands, scripts, skills, templates): README.md
