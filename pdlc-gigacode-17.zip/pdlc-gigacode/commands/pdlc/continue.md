---
description: Autonomous work — find and execute ready tasks. Use when PM mentions "continue", "продолжай", "автономно работай", "find next ready task", "do next task", "go next".
---

Найти готовые к работе артефакты и выполнять их автономно.

---


> **OPS-063 — reading references:** все ссылки на `**\`skills/.../${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/assets/continue/references/*.md\`**`
> в этом скилле подразумевают чтение через shell `cat`, не Read tool
> (Read блокируется на GigaCode для plugin paths). Pattern:
> `cat "$PLUGIN_ROOT/skills/<skill>/${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/assets/continue/references/<file>.md"` где
> `PLUGIN_ROOT=${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}`.
> Подробнее — `GIGACODE.md` § «Reading Plugin Reference Files (OPS-063)».

## ⛔ КРИТИЧЕСКИ ВАЖНО: Полный цикл обязателен!

```
┌─────────────────────────────────────────────────────────────┐
│  ⛔ ЗАПРЕЩЕНО ставить status: done если:                    │
│                                                             │
│     ✗ Regression tests НЕ прогнаны                          │
│     ✗ PR НЕ создан                                          │
│     ✗ Review НЕ пройден                                     │
│     ✗ Merge НЕ выполнен                                     │
│                                                             │
│  После написания кода статус: in_progress                   │
│  После создания PR статус: review                           │
│  После merge PR статус: done                                │
└─────────────────────────────────────────────────────────────┘
```

**Каждая TASK проходит ПОЛНЫЙ ЦИКЛ:**
```
1. IMPLEMENT    → код + unit tests + commit      → статус: in_progress
2. REGRESSION   → запуск ВСЕХ тестов проекта     → исправить если упали
3. CREATE PR    → push + pr-create (pdlc_vcs.py)  → статус: review
4. REVIEW LOOP  → ждать/исправлять               → повторять до approve
5. MERGE        → pr-merge + delete-branch       → статус: done
```

**НЕ ПЕРЕХОДИ к следующей TASK пока текущая не завершена полностью!**

---

## Использование

```
/pdlc:continue    # Начать автономную работу
```

## Алгоритм

### Idempotency на resume (OPS-042)

`/pdlc:continue` — это мульти-итеративный скилл. Если прерван
`[API Error: terminated]` посреди какой-то итерации, на `продолжи`:

- **Не повторяй итерации, которые уже завершились** — каждая итерация
  трогает state (PROJECT_STATE + frontmatter), это и есть индикатор
  «сделано». Re-read state на старте каждой итерации.
- **Если итерация прервалась посреди** (TASK перешла в `in_progress` но
  PR не создан / не закоммичен код) — `/pdlc:continue` подхватит её на
  следующем заходе через нормальный flow `/pdlc:implement` (с его
  собственными idempotency правилами).
- **При подозрении на рассинхрон** — reference PM на
  `/pdlc:doctor --resume-check`.

### State Reconciliation Guard (OPS-046) — рассинхрон → waiting_pm, не размышления

⛔ **КРИТИЧЕСКОЕ ПРАВИЛО:** в `/pdlc:continue` существуют **три**
независимых source of truth для состояния TASK:

1. **`.state/PROJECT_STATE.json`** — `tasksByStatus` bucket
2. **`tasks/TASK-XXX-*.md` frontmatter** — `status:` поле
3. **`git log` / `git worktree list`** — реальное состояние веток
   и коммитов

Эти три **могут расходиться** после: prerunteruption (terminate),
ручной правки PM, работы в нескольких worktrees, неудачного push'а.
**Любой рассинхрон между ними — это сигнал STOP, а НЕ повод размышлять
"какая из трёх правда".**

**Триггеры рассинхрона:**

- TASK status в frontmatter ≠ bucket в PROJECT_STATE
- TASK в `readyToWork` bucket, но имеет git commits с `[TASK-XXX]` в main
- TASK в `inProgress` bucket, но PR уже merged
- TASK existit в worktree branch, но в main worktree statuse `ready`
- TASK-A имеет `parent: TASK-B`, и TASK-A в работе пока TASK-B `ready`

**Что делать при обнаружении:**

⛔ **НЕ рассуждай** в стиле "но... однако... но если... однако с другой
стороны...". Это **rumination loop**, типичный анти-паттерн LLM при
противоречивых данных. Каждый "но" / "однако" / "значит, следовательно"
— это знак что ты в петле, а не приближаешься к решению.

✅ **СРАЗУ waiting_pm** с structured output:

```
═══════════════════════════════════════════
/pdlc:continue → waiting_pm: state mismatch detected
═══════════════════════════════════════════

Обнаружен рассинхрон между источниками состояния:

PROJECT_STATE.json:
  - readyToWork: [TASK-001, TASK-002, TASK-003, ..., TASK-007]
  - inProgress: []

TASK frontmatter:
  - TASK-001: status=ready
  - TASK-002: status=ready

git log main:
  - TASK-001 уже merged (PR #11)
  - TASK-002 уже merged (PR #12)

git worktree list:
  - feat__FEAT-002-tests: TASK-005 in_progress (commit bc30c18)
  - feat__FEAT-002-dns-agr-frs: TASK-001..004 done

Конкретные несостыковки:
  • TASK-001/002: state=ready, git=merged, frontmatter=ready
  • TASK-005: state=ready, worktree=in_progress
═══════════════════════════════════════════

►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
►  ВЫБЕРИТЕ ДЕЙСТВИЕ:
►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1 — Sync state с git (TASK-001/002 → done; TASK-005 остаётся
      in_progress в feat__FEAT-002-tests)
  2 — Запустить /pdlc:doctor --resume-check для полной диагностики
  3 — Откатить state к последней консистентной точке (требует
      git log изучения)

→ ответьте: 1 / 2 / 3
```

**Self-check rule (rumination detector):**

Если в твоём собственном размышлении ты произнёс одну из фраз более
**3 раз**:
- "но..."
- "однако..."
- "значит..."
- "но это невозможно..."
- "вижу, что..."
- "но я не должен..."

— это сигнал что ты в rumination loop. **Немедленно остановись**, не
дописывай размышление, и переходи к waiting_pm с тем что у тебя уже
есть в анализе.

**Real-world incident (2026-05-04):** на проекте promissory_note после
context overflow + restart агент крутился 8 страниц самодиалога между
TASK-001/002/003/004/005, не выходя в waiting_pm. PM пришлось вручную
прервать. Корень — отсутствие explicit exit-rule в скилле.

### Post-merge code visibility (OPS-049) — где находится код после merge

⛔ **КРИТИЧЕСКОЕ ПРАВИЛО:** после успешного merge PR код **НЕ исчезает**,
а **переезжает** из feature ветки в main:

| Где код **до** merge | Где код **после** merge |
|---|---|
| feature branch (`feat/...`) в worktree | `main` ветка (history главного репо) |
| Working tree feature worktree (rendered files) | Working tree main (rendered files) |
| Уникальные коммиты feature ветки | Squash commit в main с тем же содержимым |

**Что обычно происходит**, и почему агент путается:

1. PR merged через `--squash` (наш OPS-028 default) → feature commits
   "схлопываются" в один squash commit на main.
2. OPS-044 worktree auto-cleanup удаляет feature worktree.
3. Агент в новой сессии запускает `/pdlc:continue`, **в main worktree**
   видит:
   - PROJECT_STATE.json: TASK-001 status=done
   - tasks/TASK-001.md frontmatter: status=done
   - **но в working tree main файла из TASK-001 НЕТ** (feature worktree удалён)

⛔ **НЕ делай:**
- "Восстановить файл из stash" — stash к этому не относится, в нём нет
  файлов merged'нутого PR
- "Восстановить из feature ветки" — она удалена (`--delete-branch`)
- Считать что "код потерян" и пробовать его реимплементировать
- Считать что TASK-001 "не сделан" если файла нет в текущем working tree

✅ **Делай:**

1. Сначала проверь main ветку:
   ```bash
   git -C "$MAIN_WORKTREE" log --all --oneline | grep "[TASK-001]"
   ```
   Если есть merged commit — TASK-001 done корректно.

2. Если нужен код для следующих TASKs которые **зависят** от
   TASK-001 кода — он **уже в main**, не нужно его "восстанавливать":
   ```bash
   git -C "$MAIN_WORKTREE" show <main-HEAD>:path/to/file.scala
   ```
   Или просто работай в main worktree — файл там.

3. Если рабочая копия пуста, потому что worktree был удалён ПО ПЛАНУ
   (OPS-044) — это **правильное состояние**, не баг. Создай новый
   worktree для следующей TASK через стандартный flow `/pdlc:implement`.

**Real-world incident (2026-05-06):** на проекте promissory_note после
успешного merge PR #15 для TASK-001 через squash + delete-branch +
worktree cleanup, агент в новой сессии увидел "код отсутствует в
рабочей директории" и начал процедуру "восстановления из stash". Это
вело к рассинхрону, потому что stash не содержал merged-кода. PM
пришлось разбираться вручную.

**Если рабочая копия main worktree сильно расходится с git log
main** (т.е. main HEAD содержит файлы, которых нет в рабочей копии) —
**это рассинхрон**, не нормальное состояние. Проверь:

```bash
git -C "$MAIN_WORKTREE" status
git -C "$MAIN_WORKTREE" diff HEAD --stat
```

Если diff показывает удаления, которых не должно быть — выйди в
waiting_pm с описанием, не пытайся "восстановить" самостоятельно
(см. OPS-046).

### Decomposition Integrity Guard (OPS-064) — readyToWork vs deps consistency

⛔ **КРИТИЧЕСКОЕ ПРАВИЛО:** перед запуском работы над любой TASK из
`readyToWork`, проверь **консистентность декомпозиции**:

1. Прочитай TASK frontmatter: `depends_on: [TASK-A, TASK-B, ...]`
2. Для каждого ID в `depends_on` — проверь его статус (frontmatter +
   `tasksByStatus`)
3. **IF любая dependency не в `done`** → это **рассинхрон декомпозиции**

Возможные сценарии:
- TASK-007 в `readyToWork` НО его deps (TASK-003, TASK-004) в `draft`
- TASK-005 в `readyToWork` НО его parent SPEC ещё в `waitingForPM`
- TASK в `readyToWork` НО `priority: P0` а есть P1 без deps в `draft`

⛔ **НЕ принимай самостоятельных решений** в стиле:
- «Это документация, можно параллельно»
- «Эта задача не зависит от кода других, только от их существования»
- «Декомпозиция выглядит ошибочной, но я выполню для удобства»
- «Низкоприоритетная задача, влияния не окажет»

Каждое такое **обоснование** — это **rumination loop в маске**
(OPS-046). Агент придумывает рациональное объяснение чтобы продолжить
работу вместо остановки.

✅ **При обнаружении любого рассинхрона** — STOP с structured waiting_pm:

```
═══════════════════════════════════════════
/pdlc:continue → waiting_pm: decomposition mismatch
═══════════════════════════════════════════

Обнаружен рассинхрон в декомпозиции. Не могу продолжить
автономную работу до вашего решения.

TASK-007 находится в readyToWork, но:
  - TASK-007.depends_on = [TASK-003, TASK-004, TASK-005, TASK-006]
  - TASK-003: status=draft (не выполнен)
  - TASK-004: status=draft (не выполнен)
  - TASK-005: status=draft (не выполнен)
  - TASK-006: status=draft (не выполнен)

Возможные причины:
  • Декомпозиция была изменена вручную (PM)
  • Прерванный запуск /pdlc:tasks оставил state в неконсистентном виде
  • Bug в /pdlc:sync (deps пересчитались некорректно)

►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
►  ВЫБЕРИТЕ ДЕЙСТВИЕ:
►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1 — Убрать TASK-007 из readyToWork (исправить декомпозицию)
      → state будет: readyToWork без TASK-007, tasks-graph пройдёт

  2 — Decomposition correct, deps unнужны для этой TASK
      → удалить depends_on из TASK-007, оставить в readyToWork

  3 — Запустить /pdlc:doctor --resume-check для полной диагностики

  4 — Запустить /pdlc:sync для пересчёта derived state из артефактов

→ ответьте: 1 / 2 / 3 / 4
```

**Real-world incident (2026-05-08):** на проекте promissory_note FEAT-001
агент в `/pdlc:continue` обнаружил TASK-007 в readyToWork с
deps=[TASK-003..006] все в draft. Самостоятельно решил «это документация,
можно параллельно», выполнил без PR/review цикла, обновил status=done.
PM это явно не санкционировал; декомпозиция оказалась некорректной.

### TodoWrite — фиксация рассинхронов в декомпозиции

⚠️ **Дополнительное правило:** если рассинхрон **обнаружен в TodoWrite
list** (агент сам пишет «TASK-007 не должен быть в readyToWork»),
**это уже триггер waiting_pm**. Само-обнаружение проблемы — не повод
для само-разрешения.

Если в TodoWrite появилась запись содержащая фразы:
- «не должен быть в readyToWork»
- «ошибка декомпозиции»
- «это исключение из правила»
- «решение: ... выполню параллельно»
- «can be done out of order»

— STOP, переходи к OPS-064 waiting_pm flow выше.

### Алгоритм

**Перед чтением TASK файла (OPS-054):** TASK ID НЕ предсказывает
полное имя файла (`tasks/TASK-XXX-<slug>.md`). НЕ угадывай slug по
SPEC/контексту — используй `Glob 'tasks/TASK-XXX*.md'`, затем
`ReadFile` найденного path. Подробнее — `GIGACODE.md` § «Finding TASK
files by ID».

1. Прочитай `.state/PROJECT_STATE.json`
2. Прочитай `.state/knowledge.json` для контекста проекта
3. Проверь `waitingForPM`:
   - Если не пусто → "Есть N вопросов к тебе. Запусти /pdlc:unblock сначала."
4. Проверь `readyToWork`:
   - Если пусто → "Всё сделано или заблокировано. /pdlc:state для деталей."
5. Если `workspaceMode: "worktree"`:
   - Выполни `git worktree list --porcelain`
   - Извлеки ветки активных worktree
   - Сопоставь ветки → TASK-ID (по конвенции именования)
   - Пропусти задачи с активным worktree (заняты другим агентом)
6. Выбери задачу по приоритету (см. ниже)
7. **Выполни ПОЛНЫЙ ЦИКЛ для задачи** (см. ниже)
8. Повтори с шага 1

## Полный цикл для TASK (максимальная автономность)

```
┌─────────────────────────────────────────────────────────────┐
│  АВТОНОМНЫЙ ЦИКЛ TASK                                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. IMPLEMENT                                               │
│     ├─ Создать ветку (gitBranching: true)                   │
│     ├─ Реализовать код через субагент                       │
│     ├─ Написать unit тесты                                  │
│     └─ Коммит                                               │
│              │                                              │
│              ▼                                              │
│  2. REGRESSION TEST                                         │
│     ├─ Запустить ВСЕ тесты проекта                          │
│     ├─ Если упали → исправить → коммит → повторить          │
│     └─ Если прошли → продолжить                             │
│              │                                              │
│              ▼                                              │
│  3. CREATE PR                                               │
│     ├─ Push ветки                                           │
│     ├─ Создать Pull Request                                 │
│     └─ TASK → status: review                                │
│              │                                              │
│              ▼                                              │
│  3.5. PRE-CHECK: REVIEWER CLI                              │
│     ├─ $PY scripts/pdlc_cli_caps.py detect             │
│     │    → reviewer.mode = codex | self | blocked          │
│     └─ mode=blocked → STOP с диагностикой                  │
│              │                                              │
│              ▼                                              │
│  4. QUALITY REVIEW (Independent)                            │
│     ├─ /pdlc:review-pr [self] для независимого ревью       │
│     ├─ Ревьюер оценивает diff vs TASK                       │
│     ├─ Если score < 8 → improve → re-review (макс 2 итер.) │
│     └─ Если PASS → merge → delete branch → TASK: done       │
│              │                                              │
│              ▼                                              │
│  5. NEXT TASK                                               │
│     └─ Вернуться к шагу 1 алгоритма                         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  ПРЕРЫВАНИЕ ЦИКЛА (только при):                             │
│  • waiting_pm — нужно решение PM                            │
│  • blocked — неразрешимая техническая проблема              │
│  • Все задачи завершены                                     │
├─────────────────────────────────────────────────────────────┤
│  НЕ ПРЕРЫВАЙСЯ для:                                         │
│  • Падающих тестов — исправь автоматически                  │
│  • Review замечаний — исправь автоматически                 │
│  • Merge конфликтов — разреши автоматически                 │
└─────────────────────────────────────────────────────────────┘
```

### Детали каждого шага

**1. IMPLEMENT**
- Создай ветку согласно режиму (PLAN mode или стандартный)
- Запусти субагент для реализации
- Субагент пишет код + unit тесты для новой функциональности
- Коммит с сообщением `[TASK-XXX] description`

**2. REGRESSION TEST**
```
while tests_failing:
    run_all_project_tests()
    if failed:
        analyze_failures()
        fix_code()
        commit("[TASK-XXX] Fix test failures")
    else:
        break
```

**3. CREATE PR**
- Push ветки на remote
- Создать PR через `pdlc_vcs.py pr-create` (провайдер выбирается автоматически из settings.vcsProvider)
- Обновить статус TASK → `review`
  <!-- # OPS-010: правка frontmatter TASK.md + PROJECT_STATE.json task-bucket
  НЕ отдельный commit. Либо бандли в следующий `commit_and_push()`
  (IMPROVE-ветка review-loop), либо — при терминальном STOP через
  review_mode="off"/"blocked" — вынеси в единственный `finalize` commit
  `[TASK-ID] Finalize status: review (PR #N)`. НЕ пиши lastUpdated
  в PROJECT_STATE.json (OPS-010 / issue #58) — поле всегда null. -->
- ⛔ **НЕ пиши `lastUpdated`** в PROJECT_STATE.json — поле зарезервировано,
  всегда `null` (OPS-010 / issue #58).

### ⛔ PR-without-review barrier (OPS-068) — ОБЯЗАТЕЛЬНОЕ ПРАВИЛО

**После того как PR создан (`pdlc_vcs.py pr-create` вернул URL/число),
агент НЕ ИМЕЕТ ПРАВА:**
- ❌ возвращать управление PM с сообщением «PR #N создан»
- ❌ переходить к следующей TASK в readyToWork
- ❌ обновлять TodoWrite со статусом «task complete»
- ❌ спрашивать PM «хочешь чтобы я запустил review?»
- ❌ объявлять TASK завершённым (даже status=review это **в работе**, не done)

**Единственный допустимый переход** после `pr-create` — **немедленно**
к шагу 4 (QUALITY REVIEW) того же TASK, в той же tool-call sequence,
без промежуточных return-в-PM.

**Если агент обнаруживает что хочет** написать «PR создан» / «работа
завершена» / «жду PM» / «review это отдельный skill» / «решает PM» —
это **rumination loop** (OPS-046) **в новой форме**: агент рационализирует
пропуск обязательного шага через делегирование PM.

**Self-check перед выводом:** прочитай свой готовый output. Содержит
ли он одну из фраз:
- «PR #N создан и готов к review»
- «Хочешь чтобы я запустил review?»
- «PR в статусе ready for review»
- «Quality review должен запустить PM»
- «Не запускал /pdlc:review-pr для независимого quality review»
- «Согласно auto_merge=false, PR ждёт PM»

— если **да**, то это **bug**: review **должен** быть запущен агентом
в этом же turn, **до** возврата в PM. Запусти review-pr **прямо сейчас**
и переделай output.

**Real-world incident (2026-05-09):** агент в `/pdlc:continue` создал
PR #21 для TASK-003..006 и **сам признался**: «Не запускал /pdlc:review-pr
для независимого quality review. Хочешь чтобы я запустил?». PM явно
не санкционировал пропуск; pipeline разорван. Признание агента **после
действия** не отменяет нарушения flow.

**Note про auto_merge:** `knowledge.workflow.auto_merge = false` (OPS-056)
блокирует **только финальный merge**, не review. Review **всегда**
обязателен, независимо от auto_merge. После passing review:
- `auto_merge: true` → merge напрямую
- `auto_merge: false` → STOP в waiting_pm, ждём PM. Но review **сделан**,
  PM имеет результаты в комментарии PR.

См. также `GIGACODE.md` § «Promised Handoff Discipline (OPS-055)» и
«Decomposition Integrity (OPS-064)» — это **родственные** правила.

**4. QUALITY REVIEW И MERGE (автоматически, без вопросов!)**

```
⚠️ ВАЖНО:
- PM не делает code review — это автоматизированный процесс
- НЕ СПРАШИВАЙ "Продолжить?" — делай автоматически!
- Ревью делает Codex CLI (default) или текущий агент (`self`) — независимое мнение!
- GitHub не позволяет approve свой PR — merge напрямую после PASS
```

Алгоритм:
0. Pre-check: определить reviewer CLI через единый helper (OPS-011):
   - `caps=$($PY ${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/scripts/pdlc_cli_caps.py detect)` → JSON с `reviewer.mode`
   - `review_mode = caps.reviewer.mode` → `"codex"` | `"self"` | `"blocked"` | `"off"` (OPS-017)
   - `reason = caps.reviewer.reason` (может быть пустым)
   - `warning = caps.reviewer.warning` — OPS-007 / issue #55: непустое значение означает, что в PATH нашёлся чужой `codex` и был отбит identity-проверкой. Напечатать `⚠ {warning}` перед ветвлением по `review_mode`, чтобы самозванец не оставался silent в логе.
0a. Если `review_mode == "off"` → STOP: reviewer отключён в `settings.reviewer.mode`. TASK остаётся в `review` с созданным PR; PM делает ревью руками и выполняет merge через `/pdlc:pr merge <id>` (или закрывает PR).
0b. Если `review_mode == "blocked"` → STOP. Прочитать `reason` и подсказать соответственно:
   - Если `reason` упоминает «settings …» → проблема в настройках:
     ```
     ═══════════════════════════════════════════
     REVIEWER BLOCKED
     ═══════════════════════════════════════════
     Reason: {reason}

     Проверьте settings.reviewer.mode и settings.reviewer.cli
     в .state/PROJECT_STATE.json — текущее значение конфликтует
     с доступными CLI в окружении.

     TASK остаётся в статусе: review
     ═══════════════════════════════════════════
     ```
   - Иначе (reason не задан или указывает на отсутствие CLI) — показать варианты установки:
     ```
     ═══════════════════════════════════════════
     REVIEWER CLI НЕ НАЙДЕН
     ═══════════════════════════════════════════
     Reason: {reason or "no reviewer CLI available"}

     Quality review требует CLI ревьюера.

     Варианты:
       • Codex CLI: npm install -g @openai/codex
       • Claude Code: https://docs.anthropic.com/claude-code
       • Qwen CLI: документация Qwen

     TASK остаётся в статусе: review
     ═══════════════════════════════════════════
     ```
1. Запусти `/pdlc:review-pr` (или `/pdlc:review-pr self` если `review_mode == self`) — независимый quality review:
   - Ревьюер оценивает PR diff vs TASK requirements
   - Score 1-10 по критериям (acceptance, полнота, качество, тесты, безопасность)
2. Если score < 8 (IMPROVE):
   - Improvement субагент исправляет код
   - Прогоняет тесты, коммит, push
   - Re-review (макс. 2 итерации)
3. Если score >= 8 (PASS):
   - **Проверь `knowledge.workflow.auto_merge`** (OPS-056):
     - Если `true` (legacy) — агент мерджит сам через
       `pdlc_vcs.py pr-merge` и продолжает со следующей TASK
     - Если `false` (default since OPS-056) — **STOP**, не мержить!
       PR остаётся в `ready_for_review` (review approved, но не merged).
       TASK status → `inReview` (не `done`). Вывести структурированное
       сообщение PM:
       ```
       ═══════════════════════════════════════════
       /pdlc:continue → review passed: PM action required
       ═══════════════════════════════════════════

       ✅ TASK-XXX: code review passed (score 8/10)
       ✅ PR #N: ready for your approval

       Что я сделал:
         • Реализовал TASK-XXX
         • Запустил code review (score 8+)
         • Code review успешно пройден

       Что нужно от вас (PM):
         1 — Проверить PR #N: <url>
         2 — Approve + merge через ваш VCS UI (Bitbucket/GitHub)
         3 — После merge — /pdlc:continue для следующей TASK

       (Чтобы вернуть автоматический merge — установите
        knowledge.workflow.auto_merge = true)
       ═══════════════════════════════════════════
       ```
   - Если auto_merge=true: merge → status `done`, **автоматически
     продолжи** (не спрашивай!)
   - Если auto_merge=false: stop, status `inReview`, ждём PM
4. Если 2 итерации пройдены и score < 8:
   - **STOP** — НЕ мержить, НЕ переходить к следующей задаче
   - Статус TASK → waiting_pm
   - Вывести подробный отчёт и варианты для PM

```python
iterations = 0
while iterations < 2:
    review = run_review(pr_number, review_mode)  # Codex CLI or self
    iterations += 1
    if review.score >= 8:  # PASS
        # OPS-056: PM-gated merge — default `auto_merge=false`.
        # Agent does NOT merge; PR is left for PM to approve+merge.
        if knowledge.workflow.auto_merge:
            run('$PY ${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/scripts/pdlc_vcs.py pr-merge N --squash --delete-branch --project-root "${PDLC_WORK_DIR:-.}"')
            task.status = "done"
        # OPS-010: post-merge `status=done` — терминальная правка frontmatter
        # TASK.md + PROJECT_STATE.json. Если семантического коммита больше нет
        # (переход к следующей ready TASK в шаге 5 запускает новый цикл), это
        # единственный `finalize` commit `[TASK-ID] Finalize status: done (PR #N)`.
        # diff: только TASK.md frontmatter + PROJECT_STATE.json. НЕ пиши lastUpdated.
        #
        # OPS-044: Worktree auto-cleanup (after successful merge).
        # ОЧЕНЬ ОСТОРОЖНО — рискуем потерять работу если там остались
        # uncommitted changes или ветка не действительно merged.
        # Применяется только если ВСЕ условия:
        #   1. workspaceMode == "worktree" (skip для inplace)
        #   2. branch ВЕРИФИЦИРОВАНА как merged: `git log <branch>..main`
        #      должен быть ПУСТЫМ (все коммиты ветки уже в main)
        #   3. `git status --porcelain` в worktree пуст (нет uncommitted)
        #   4. `git stash list` в worktree пуст (нет stash'ей)
        # Если хоть одно условие не выполнено — НЕ удаляем worktree, только
        # выводим warning «worktree {path} requires manual cleanup, see
        # /pdlc:doctor --resume-check`.
        if state.workspaceMode == "worktree":
            wt_path = find_worktree_for_branch(branch)
            if wt_path:
                # Pre-checks
                merged_check = run(f'cd "{wt_path}" && git log {branch}..main --oneline 2>/dev/null')
                status_check = run(f'cd "{wt_path}" && git status --porcelain 2>/dev/null')
                stash_check  = run(f'cd "{wt_path}" && git stash list 2>/dev/null')
                if not merged_check.stdout.strip() and \
                   not status_check.stdout.strip() and \
                   not stash_check.stdout.strip():
                    # Safe to remove
                    run(f'git worktree remove "{wt_path}" --force')
                    run('git worktree prune')
                    log_event(phase="state_updated", command="continue",
                              task_id=task.id, decision="worktree_removed",
                              payload={"path": wt_path})
                else:
                    # Unsafe — keep, ask PM
                    reasons = []
                    if merged_check.stdout.strip():
                        reasons.append("branch has commits not in main")
                    if status_check.stdout.strip():
                        reasons.append("uncommitted changes in worktree")
                    if stash_check.stdout.strip():
                        reasons.append("stash entries in worktree")
                    print(f"⚠ Worktree {wt_path} kept (manual cleanup required): {', '.join(reasons)}")
                    log_event(phase="warning", command="continue",
                              task_id=task.id, decision="worktree_kept",
                              payload={"path": wt_path, "reasons": reasons})
        else:
            # OPS-056: PM-gated merge — review passed, but agent stops.
            # Worktree NOT cleaned up (PM may want to inspect locally).
            # PR remains in `ready_for_review`. TASK status → inReview.
            task.status = "inReview"
            update_project_state(task_id, "inReview",
                reason=f"Review passed (score {review.score}/10), waiting PM merge of PR #{pr_number}")
            log_event(phase="pm_gate", command="continue",
                      task_id=task.id, decision="waiting_pm_merge",
                      payload={"pr": pr_number, "score": review.score})
            print_pm_merge_required_message(pr_number, review.score)
        break
    else:  # IMPROVE
        run_improvement(review.recommendations)
        run_all_tests()
        # OPS-028: commit_and_push() =
        #   git commit ... && $PY ${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/scripts/pdlc_vcs.py git-push \
        #       --branch <expected_branch> --project-root "$WORK_DIR"
        # На exit=2 (push verification failed) → task.status = "waiting_pm",
        # в waitingForPM процитировать remote_lines + reason из JSON. break.
        commit_and_push()
else:
    # Max iterations — STOP, ждём PM
    task.status = "waiting_pm"
    update_project_state(task_id, "waitingForPM",
        reason=f"Review ({review_mode}): score {review.score}/10 after 2 iterations")
    # OPS-010: терминальный waiting_pm без следующего коммита. Бандли
    # task.status + update_project_state в единственный `finalize` commit
    # `[TASK-ID] Finalize status: waiting_pm (PR #N)`. diff: только TASK.md
    # frontmatter + PROJECT_STATE.json. НЕ пиши lastUpdated.
    STOP  # НЕ переходить к следующей задаче!
```

**5. NEXT TASK**
- Вернуться к началу алгоритма
- Выбрать следующую ready задачу

## Приоритет выбора (v2.1)

### Уровень 0: Завершить начатое (ОБЯЗАТЕЛЬНО сначала!)
```
⚠️ НЕ НАЧИНАЙ новую TASK пока есть незавершённые!
```
0. `review` — resume-процедура (OPS-008):

   Полный алгоритм resume (Phase A: resolve workspace, Phase B: auto-discover PR,
   Phase C: create PR если не нашли, Phase D: quality review) — в:

   **`${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/assets/continue/references/resume-procedure.md`** —
   читай через Read tool, когда выбираешь TASK из `inReview`.

   Ключевые инварианты процедуры:
   - source of truth для `pr_url` — frontmatter TASK (НЕ PROJECT_STATE.artifacts)
   - assertion `cd "$WORK_DIR" && git rev-parse --abbrev-ref HEAD == <expected>`
   - clean working tree через `git status --porcelain` ДО любых git-операций
   - OPS-028 verified push на Phase C; exit=2 → `waiting_pm`, не `blocked`
   - `pdlc_vcs.py pr-create` failure → `waiting_pm` (не blocked, иначе
     зацикливается); сообщение содержит "pr_url_request" (`/pdlc:unblock` ловит)

1. `changes_requested` — исправить замечания code review
2. `in_progress` — доделай начатое

### Уровень 1: Следующая по порядку (в рамках PLAN)
```
Если текущая TASK из PLAN, следующая = первая ready TASK из того же PLAN.
Не прыгай на другие PLAN пока текущий не завершён или не заблокирован.
```
3. `ready` TASK из текущего PLAN (по roadmap_item order)

### Уровень 2: Прямая реализация (если нет активного PLAN)
4. `ready` TASK от BUG — исправь баги (P0 > P1 > P2)
5. `ready` TASK — реализуй задачи
6. `ready` TASK от CHORE — выполни простые задачи

### Уровень 3: Критичный техдолг
7. `ready` TASK от DEBT (P0-P1) — security/performance

### Уровень 4: Исследование
8. `ready` SPIKE — исследуй (следи за timebox)

### Уровень 5: Создание задач (если нет готовых TASK)
9. `ready` PLAN → создай задачи (`/pdlc:tasks`)
10. `ready` SPEC → создай задачи (`/pdlc:tasks`)
11. `ready` FEAT → создай задачи (`/pdlc:tasks`) или spec если сложно

### Уровень 6: Проработка
12. `ready` PRD → создай спецификацию (`/pdlc:spec`)

### Уровень 7: Обычный техдолг
13. `ready` TASK от DEBT (P2+) — обычный техдолг

## Логика выбора из нескольких ready

Если несколько артефактов одного типа:
1. Сначала по приоритету: P0 > P1 > P2 > P3
2. Затем по дате создания: старые раньше

## Условия остановки

Останавливайся и сообщай PM когда:

### Требуется решение PM
- Бизнес-выбор (приоритет, скоуп)
- Архитектурный trade-off с последствиями
- Неясные требования

→ Поставь `waiting_pm`, добавь вопрос, продолжи с другими задачами

### Техническая блокировка
- Тесты падают и непонятно почему
- Зависимость недоступна
- Ошибка окружения

→ Поставь `blocked`, продолжи с другими задачами

### Всё готово
- Нет больше `ready` задач
- Все `waiting_pm` или `blocked`

→ Выведи итоги и останови работу

## Формат вывода

Все варианты вывода (начало работы, полный цикл одной задачи, при падении
тестов с автоисправлением, при quality review с улучшением, при блокировке,
итоги сессии) — в:

**`${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/assets/continue/references/output-formats.md`** —
читай через Read tool ПЕРЕД печатью соответствующего блока.

## Git Branching поведение

Подробности (branch naming, worktree mode lifecycle, inplace mode fallback,
статус в .md frontmatter после merge) — в:

**`${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/assets/continue/references/git-branching-behavior.md`** —
читай через Read tool ПЕРЕД операциями с ветками/worktree.

Source-of-truth для имён веток и `compute_expected_branch(TASK)` —
общий с `/pdlc:implement`: `${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/assets/implement/references/branch-and-worktree-setup.md`.

## Важно

- Коммить после каждой завершённой задачи
- Не накапливай много изменений
- При сомнениях — лучше спросить PM (waiting_pm)
- Обновляй PROJECT_STATE.json после каждого изменения
- `/pdlc:implement` работает только с TASK
- Следи за timebox для SPIKE

## ⛔ ЗАПРЕЩЕНО спрашивать разрешение на продолжение!

```
НЕ ПИШИ:
  "Продолжить с TASK-039?"
  "Хочешь чтобы я продолжил?"
  "Начать следующую задачу?"

ВМЕСТО ЭТОГО — просто продолжай автоматически!
```

Автономный режим означает:
- После merge PR → сразу следующая задача
- После завершения TASK → сразу следующая задача
- Не жди подтверждения PM для технических операций

**Останавливайся ТОЛЬКО при:**
- `waiting_pm` — бизнес-вопрос к PM
- `blocked` — техническая проблема которую не можешь решить
- Все задачи завершены

## GitHub Self-Approve Limitation

GitHub не позволяет approve свой собственный PR:
```
Error: Review Can not approve your own pull request
```

**Решение:** После успешного Independent Quality Review (score >= 8) делай merge напрямую:
```bash
PY=${PY:-$(command -v python3 || command -v python)}
$PY ${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/scripts/pdlc_vcs.py pr-merge N --squash --delete-branch --project-root "${PDLC_WORK_DIR:-.}"
```

Не approve собственного PR (ни через VCS CLI, ни через REST API) — это не сработает.