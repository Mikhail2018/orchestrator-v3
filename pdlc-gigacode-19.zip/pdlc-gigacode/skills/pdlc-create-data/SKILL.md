---
name: pdlc-create-data
description: Generate relevant test data CSV files for a Hadoop data mart's source tables, so the mart can be computed non-empty and all autotests can run. Use when PM mentions "create test data", "тестовые данные", "create-data", "подготовь данные", "test data for datamart", "сгенерируй тестовые данные".
---

Готовит CSV-файлы с тестовыми данными для таблиц-источников Hadoop
витрины. Данные релевантны (джойнятся между собой), итоговая витрина
получается непустой, по ней можно прогнать все автотесты.

⚠️ **Отдельная команда — НЕ часть общего цикла** `/pdlc:continue` /
`/pdlc:implement` (OPS-075). Запускается PM **вручную** когда нужны
тестовые данные. Это сделано намеренно: генерация тестовых данных
требует контроля PM и не нужна в каждом цикле разработки.

## Использование

```
/pdlc:create-data                  # автоопределение витрины из контекста
/pdlc:create-data dm_product       # явное имя витрины
```

## Предусловия

1. В `knowledge.json` заполнена секция `dataMartTesting` (см. OPS-070),
   в частности `datamart_code_path` и `sources_output_dir`.
2. Витрина **Hadoop** (Spark/Scala). Для не-Hadoop витрин команда не
   применима — тестовые данные в CSV предназначены для загрузки в
   Hadoop-таблицы перед прогоном Spark-расчёта.

Если `dataMartTesting` не заполнена или `enabled == false` — STOP с
waiting_pm: «Заполните dataMartTesting в knowledge.json и установите
enabled=true».

## Алгоритм

> **OPS-063 — reading references:** читай файлы через shell `cat`, не
> Read tool. **OPS-061 — Python:** `PY=${PY:-$(command -v python3 || command -v python)}`.

### 1. Hadoop guard (OPS-074)

Подтверди что витрина — Hadoop, автодетектом по коду (НЕ спрашивай PM):

```bash
PLUGIN=${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}
# Ищи в <dataMartTesting.datamart_code_path> маркеры:
#   org.apache.spark / org.apache.hadoop / spark.read / spark.sql /
#   DataFrame / Dataset[ / SparkSession / saveAsTable / .parquet / .orc / hdfs://
# Через Glob *.scala + cat, либо grep если доступен.
```

Если маркеров нет — STOP: «Витрина не Hadoop (нет Spark/HDFS маркеров).
Тестовые данные в CSV предназначены для Hadoop витрин».

### 2. Найди таблицы-источники

```bash
# 2a. Изучи скрипты тестов в <dataMartTesting.autotests_dir> и код витрин
#     в <dataMartTesting.datamart_code_path> (через cat / Glob).
#     Найди ВСЕ таблицы-источники, используемые в расчёте витрины.
#     Источники — это spark.read.table("schema.table"), .parquet(path),
#     FROM schema.table в SQL внутри Scala, и т.п.
```

### 3. Создай CSV-скелеты

```bash
PY=${PY:-$(command -v python3 || command -v python)}
$PY "$PLUGIN/scripts/pdlc_datamart_tests.py" test-data-skeleton \
    --sources "<schema.table1>,<schema.table2>,..." \
    --out-dir "<dataMartTesting.sources_output_dir>"
```

Скрипт создаёт корректные скелеты с правильными именами файлов:
- Имя: `<schema_name>_<table_name>.csv` (ПОЛНОЕ имя схемы, не переменная)
- Все файлы в одной папке (`sources_output_dir`, обычно `docs/sources`),
  **без поддиректорий**

### 4. Заполни данными (semantic reasoning — делает агент)

⚠️ **Это главная работа команды.** Скрипт создаёт только скелеты;
осмысленные данные заполняет агент:

- **≥5 строк** на каждый источник
- Данные **джойнятся** между собой: FK-значения в одной таблице
  совпадают с PK-значениями в связанной
- Итоговая витрина после расчёта — **непустая**
- По витрине можно прогнать **ВСЕ** автотесты из `autotests_dir`
  (изучи их SQL — какие значения нужны чтобы тесты были осмысленны)
- ⛔ **НЕ создавай пустых записей** — каждая строка содержит данные

Чтобы данные были релевантны:
1. Прочитай DQ-тесты из `autotests_dir` (через cat) — пойми что
   проверяется (mandatory поля, PK uniqueness, FK links)
2. Прочитай код витрины — пойми join-логику между источниками
3. Заполни так, чтобы:
   - mandatory-поля не были NULL
   - PK были уникальны
   - FK ссылались на существующие PK
   - после join'ов витрина была непустой

### 5. Вывод

```
═══════════════════════════════════════════
/pdlc:create-data → тестовые данные созданы
═══════════════════════════════════════════

Витрина: dm_product (Hadoop)
Источников: N

Созданные файлы (docs/sources/):
  + custom_cib_pkaptdul_dns_agr_frs.csv      (5 строк)
  + custom_cib_pkaptdul_dim_subject.csv      (6 строк)
  ...

Данные релевантны: FK→PK связи согласованы, витрина после расчёта
непустая, все N автотестов могут быть прогнаны.

Следующий шаг: загрузите данные на стенд и запустите расчёт витрины.
После прогона автотестов — /pdlc:check-tests для анализа результатов.
═══════════════════════════════════════════
```

## Важно

- Команда **не коммитит** автоматически — PM сам решает что делать с
  файлами (часто тестовые данные не идут в git, а загружаются на стенд).
  Можно предложить PM: «Добавить в git или оставить локально?»
- ⛔ Только CSV с данными. Не создавай скриптов загрузки (`.sh`), не
  редактируй код витрины или Scala-тесты.