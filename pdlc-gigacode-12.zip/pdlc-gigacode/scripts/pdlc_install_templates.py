#!/usr/bin/env python3
"""OPS-060 — Install Polisade Orchestrator templates from plugin to project.

Replaces the OPS-051 shell-based copy approach which broke on Windows cmd.exe
due to variable expansion scope issues (`set VAR=... && if exist "%VAR%\\..."`
expands `%VAR%` before `set` runs in a single command line).

Why a dedicated script:
- Python `shutil.copy` works identically across Linux/macOS/Windows
- Plugin root is auto-detected from script's own location, no shell variables
- File paths are absolute Path objects, no shell expansion quirks
- Skips files that already exist in target (idempotent re-runs are safe)
- Auto-detects context-file name (CLAUDE.md / GIGACODE.md / GIGACODE.md) per CLI

Usage (from /pdlc:init step 4):
    python "$PLUGIN_ROOT/scripts/pdlc_install_templates.py" \\
        --project-root "$WORK_DIR"

Or with explicit plugin root:
    python pdlc_install_templates.py \\
        --plugin-root "C:/Users/me/.gigacode/extensions/pdlc" \\
        --project-root "C:/Users/me/IdeaProjects/myproj"

Exit codes:
    0 - all templates installed (or already present, idempotent)
    1 - plugin root not found / invalid
    2 - target project root not writable
    3 - one or more critical templates missing in plugin
"""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


# Map: source-relative-to-plugin-templates/init -> target-relative-to-project
# Critical files (must exist):
TEMPLATE_MAP_CRITICAL = [
    ("PROJECT_STATE.json", ".state/PROJECT_STATE.json"),
    ("counters.json", ".state/counters.json"),
    ("knowledge.json", ".state/knowledge.json"),
]

# Doc templates (best-effort; warn if missing but continue):
TEMPLATE_MAP_DOCS = [
    ("docs/prd-template.md", "docs/templates/prd-template.md"),
    ("docs/spec-template.md", "docs/templates/spec-template.md"),
    ("docs/plan-template.md", "docs/templates/plan-template.md"),
    ("docs/feature-brief-template.md", "docs/templates/feature-brief-template.md"),
    ("docs/chore-template.md", "docs/templates/chore-template.md"),
    ("docs/spike-template.md", "docs/templates/spike-template.md"),
    ("docs/task-template.md", "docs/templates/task-template.md"),
    ("docs/adr-template.md", "docs/templates/adr-template.md"),
    ("docs/design-package-template.md", "docs/templates/design-package-template.md"),
    ("docs/contracts-readme-template.md", "docs/contracts/README.md"),
]

# Optional files (skip silently if missing):
TEMPLATE_MAP_OPTIONAL = [
    ("settings.json", ".claude/settings.json"),  # Claude Code only
    ("env.example", ".env.example"),
    ("gitignore", ".gitignore.polisade"),  # Reference only — actual gitignore is appended in step 5
]

# Empty .gitkeep markers (no source file, just create empty file in target)
GITKEEP_PATHS = [
    "docs/contracts/provided/.gitkeep",
    "docs/contracts/consumed/.gitkeep",
]


def autodetect_plugin_root(script_path: Path) -> Path | None:
    """Plugin root is two levels up from this script.

    Layout:
        <plugin_root>/
            scripts/pdlc_install_templates.py   <-- this file
            templates/init/PROJECT_STATE.json
            ...
    """
    candidate = script_path.resolve().parent.parent
    if (candidate / "templates" / "init").is_dir():
        return candidate
    return None


def detect_context_file(src_init: Path) -> tuple[str, str] | None:
    """Detect which CLI's context file is in the plugin.

    Returns (source_filename, target_filename) or None if not found.
    Claude Code → CLAUDE.md; Qwen → GIGACODE.md; GigaCode → GIGACODE.md.
    Target name in user project is always CLAUDE.md by convention
    (Polisade uses CLAUDE.md as the project's agent context file
    regardless of which CLI is running it — sed-pass converts at
    install time on plugin side, but user project keeps a single
    canonical name).

    Actually — different CLIs look for DIFFERENT context files in
    user projects too. Need to preserve the runtime-specific name.
    """
    for cli_filename in ("CLAUDE.md", "GIGACODE.md", "GIGACODE.md"):
        candidate = src_init / cli_filename
        if candidate.exists():
            # Target keeps the CLI-specific name so the runtime finds it
            return (cli_filename, cli_filename)
    return None


def install_templates(
    plugin_root: Path,
    project_root: Path,
    overwrite: bool = False,
) -> tuple[int, list[str], list[str]]:
    """Copy all templates. Returns (exit_code, copied_list, error_list)."""
    src_init = plugin_root / "templates" / "init"
    if not src_init.is_dir():
        return (1, [], [f"Plugin templates dir not found: {src_init}"])

    if not project_root.is_dir():
        try:
            project_root.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return (2, [], [f"Cannot create project root {project_root}: {e}"])

    copied: list[str] = []
    errors: list[str] = []
    skipped_existing: list[str] = []
    missing_critical: list[str] = []

    # Build full template map dynamically (context file name varies by CLI)
    template_map: list[tuple[str, str]] = list(TEMPLATE_MAP_CRITICAL)

    ctx = detect_context_file(src_init)
    if ctx is not None:
        template_map.append(ctx)
    else:
        errors.append(
            "WARN: no context file (CLAUDE.md / GIGACODE.md / GIGACODE.md) "
            "found in plugin templates"
        )

    template_map.extend(TEMPLATE_MAP_DOCS)
    template_map.extend(TEMPLATE_MAP_OPTIONAL)

    for src_rel, dst_rel in template_map:
        src = src_init / src_rel
        dst = project_root / dst_rel

        is_critical = (src_rel, dst_rel) in TEMPLATE_MAP_CRITICAL

        if not src.exists():
            if is_critical:
                missing_critical.append(src_rel)
            elif (src_rel, dst_rel) in TEMPLATE_MAP_OPTIONAL:
                # silent skip for optional
                pass
            else:
                # docs warn-but-continue
                errors.append(f"WARN: source missing (skipped): {src_rel}")
            continue

        if dst.exists() and not overwrite:
            skipped_existing.append(dst_rel)
            continue

        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            copied.append(dst_rel)
        except OSError as e:
            errors.append(f"ERROR copying {src_rel} -> {dst_rel}: {e}")

    # Empty marker files
    for marker in GITKEEP_PATHS:
        dst = project_root / marker
        if dst.exists():
            skipped_existing.append(marker)
            continue
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.touch()
            copied.append(marker)
        except OSError as e:
            errors.append(f"ERROR creating marker {marker}: {e}")

    if missing_critical:
        errors.append(
            "FATAL: critical templates missing in plugin: "
            + ", ".join(missing_critical)
        )
        return (3, copied, errors)

    # Report summary
    print(f"Installed {len(copied)} templates to {project_root}")
    for path in copied:
        print(f"  + {path}")
    if skipped_existing:
        print(
            f"\nSkipped {len(skipped_existing)} existing files "
            "(use --overwrite to replace):"
        )
        for path in skipped_existing[:5]:
            print(f"  - {path}")
        if len(skipped_existing) > 5:
            print(f"  ... and {len(skipped_existing) - 5} more")

    if errors:
        print("\nWarnings/errors:", file=sys.stderr)
        for err in errors:
            print(f"  {err}", file=sys.stderr)

    return (0, copied, errors)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Install Polisade Orchestrator templates into a project (OPS-060)."
    )
    parser.add_argument(
        "--plugin-root",
        type=Path,
        default=None,
        help="Path to plugin install dir (e.g., ~/.gigacode/extensions/pdlc). "
             "If omitted, auto-detected from this script's location.",
    )
    parser.add_argument(
        "--project-root",
        type=Path,
        default=Path.cwd(),
        help="Path to user's project root (default: current directory).",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing target files (default: skip them — idempotent).",
    )
    args = parser.parse_args(argv)

    if args.plugin_root is None:
        script_path = Path(__file__)
        plugin_root = autodetect_plugin_root(script_path)
        if plugin_root is None:
            print(
                f"ERROR: cannot autodetect plugin root from script location "
                f"{script_path}. Use --plugin-root to specify explicitly.",
                file=sys.stderr,
            )
            return 1
        print(f"Auto-detected plugin root: {plugin_root}")
    else:
        plugin_root = args.plugin_root.resolve()
        if not plugin_root.is_dir():
            print(
                f"ERROR: --plugin-root not a directory: {plugin_root}",
                file=sys.stderr,
            )
            return 1

    project_root = args.project_root.resolve()
    print(f"Target project root: {project_root}")

    exit_code, copied, errors = install_templates(
        plugin_root=plugin_root,
        project_root=project_root,
        overwrite=args.overwrite,
    )

    return exit_code


if __name__ == "__main__":
    sys.exit(main())
