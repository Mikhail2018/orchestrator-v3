# Subagent Prompts — `/pdlc:tasks`

Шаблоны промптов, которые основной агент `/pdlc:tasks` формирует для
general-purpose субагента (Task tool) при декомпозиции артефактов в TASK.

SKILL.md `### 3. Формирование prompt для субагента` ссылается сюда.
Здесь живут три варианта шаблонов:

1. **Для отдельного roadmap item из PLAN** — параллельно по item'ам.
2. **Для SPEC / FEAT напрямую** — один субагент.
3. **Для BUG / DEBT / CHORE** — один общий шаблон с тремя подстановками.

---

## Field mapping: pdlc_context.py JSON → шаблоны

OPS-029 / Пакет 1: основной агент вызывает
`pdlc_context.py for-tasks-source SOURCE-ID`, получает JSON, и подставляет
поля в плейсхолдеры шаблона. Маппинг:

| Плейсхолдер | Поле JSON |
|---|---|
| `{полное содержимое SPEC/FEAT}` | `source.body` |
| `{содержимое конкретного roadmap item из PLAN}` | извлекается из `source.body` (для PLAN) |
| `{релевантные секции из SPEC}` | `spec_excerpts.body` (если spec_id ≠ null), иначе fallback к `source.body` для SPEC-source |
| `{Out of scope из SPEC §1}` | `out_of_scope[]` (или "N/A") |
| `{Constraints (C-N) и Dependencies (D-N) из SPEC §4}` | `constraints_and_assumptions.constraints` + `.dependencies` (или "N/A") |
| `{system_boundary}` | `system_boundary.boundary` (или "N/A") |
| `{external_systems}` | `system_boundary.external_systems` (или "N/A") |
| `{patterns}` / `{antiPatterns}` / `{decisions}` | `knowledge.patterns` / `.anti_patterns` / `.decisions` |
| `{glossary}` | `knowledge.glossary[]` |
| `{techStack}` | `knowledge.tech_stack` |
| `{keyFiles}` | `knowledge.key_files` |
| `{содержимое task-template.md}` | прочитать `docs/templates/task-template.md` (НЕ через context.py — это шаблон, а не контекст) |
| `{next_task_id}` | `next_task_id_hint` (use as starting ID for batch creation) |

**Для BUG / DEBT / CHORE source:**
- `{SOURCE_TYPE}` — `source.type` (BUG/DEBT/CHORE)
- `{SOURCE_FILE_PATH}` — `source.body_path`
- `{SYSTEM_ROLE}` — Bug Fix / Tech Debt / Chore Task Planner соответственно
- `requirements_resolved` будет пуст (BUG/DEBT/CHORE без SPEC), это OK

`design_package` поле JSON: если non-null — инжектируй
`design_package.api_contract` и `design_package.readme` в секцию ARCHITECTURE
шаблона; иначе "N/A — у parent SPEC нет DESIGN package".

`warnings[]` НЕ инжектируются в промпт субагента — выводятся PM как diagnostics.

---

## Шаблон A — РЕКОМЕНДУЕМЫЙ (через cached JSON-context)

OPS-029 path. Основной агент:
1. Запускает `pdlc_context.py for-tasks-source SOURCE-ID --output .pdlc/cache/json_outputs/context-tasks-<id>.json`
2. Stdout даёт путь.
3. Передаёт **только путь** в субагент.

### Strict-режим декомпозиции (OPS-033)

`pdlc_context.py` пробрасывает `knowledge.decomposition.mode` в JSON-context
(`knowledge.decomposition.mode` ∈ `"legacy"` | `"strict"`, default `"legacy"`).

**Если mode = "strict"** — основной агент инжектирует в промпт субагента
дополнительный блок `STRICT-RULES`:

```
═══════════════════════════════════════════
STRICT-RULES (knowledge.decomposition.mode == "strict")
═══════════════════════════════════════════

ОБЯЗАТЕЛЬНЫЕ правила декомпозиции:

1. VERTICAL SLICING — каждая TASK закрывает один end-to-end use case
   через все слои (model + service + API + тесты в ОДНОЙ TASK), а не
   один слой одной фичи. Запрещено создавать «model layer TASK» +
   «service layer TASK» + «API layer TASK» для одной фичи — это
   горизонтальная декомпозиция, никогда не мержится независимо.

2. ONE FR — ONE OWNER — каждый FR/NFR из SPEC указывается в
   `requirements:` ровно ОДНОЙ TASK (primary owner). Helper TASKs,
   которые работают над тем же FR (например, рефакторинг для подготовки
   к фиче), используют `depends_on:` для ссылки на primary owner, но
   НЕ дублируют `requirements`.

3. NO REQUIREMENT-FREE TASK для бизнес-логики — TASK для FR/NFR ОБЯЗАНА
   иметь непустой `requirements:`. Исключения только: CHORE (build/CI),
   DEBT (technical debt), pure refactor без бизнес-эффекта (помеченный
   как `task_type: refactor` в frontmatter).

4. PHASE-BASED PRIORITY — приоритет вычисляется ИЗ phase, не «на глаз»:
   - Phase 1 / Setup / "phase 1: setup"   → P0
   - Phase 2 / Core / "phase 2: core"     → P1
   - Phase 3 / Tests / "phase 3: tests"   → P2
   - Phase 4 / Polish / "phase 4: polish" → P2
   Если хочешь нарушить — добавь `priority_override: "<reason>"` в
   frontmatter, иначе `pdlc_check.py tasks-graph` это flag'нет.

5. SIBLING-CONSISTENCY — после генерации списка TASK сравни scope
   каждой пары: если две TASK трогают перекрывающиеся файлы И обе
   указывают `requirements`, это знак duplicate ownership — выбери
   primary, остальные конвертируй в helpers через `depends_on`.

ВЫХОД strict-режима ОБЯЗАТЕЛЕН: каждая TASK должна пройти `pdlc_check.py
tasks-graph` без findings. Если ты не уверен в декомпозиции — лучше
вернуть меньше TASK с явными gaps в coverage, чем больше TASK с
дубликатами или фантомными requirements.
```

**Если mode = "legacy"** (default) — STRICT-RULES блок НЕ инжектируется,
поведение как раньше (агент применяет нестрогие принципы из основного
тела промпта).

`pdlc_check.py tasks-graph` запускается ВНЕ зависимости от mode (валидация
не вредит legacy-проектам — просто warnings будут чаще). Но в strict-mode
основной агент **обязан** реагировать на findings (см. OPS-032 в
SKILL.md §4.5: 2 итерации, потом fallback на PM Checkpoint с предложением).

---

### Tool Call Budget для всех шаблонов A (OPS-038)

Каждый Шаблон A.* инжектируется в субагент с обязательным блоком:

```
═══════════════════════════════════════════
TOOL CALL BUDGET (OPS-038)
═══════════════════════════════════════════

⛔ Лимит: максимум 8 Read/Glob/Bash операций.

Причина — известный Node.js баг (claude-code#2629, gemini-cli#5950): на
каждый tool call вешается abort-listener на AbortSignal, не удаляется.
После 11 — warning. После большего — terminate.

Стратегия:
- Один Read JSON-context даёт ПОЛНЫЙ контекст для декомпозиции.
- Если нужно дополнительно — Read до 4-5 конкретных файлов из source
  ("Files to Change", knowledge.key_files), не Glob по всему репо.
- Не Glob/Read случайные части репозитория "чтобы посмотреть".

Если нужно >8 Read для декомпозиции — source TASK слишком большая,
её надо разбить на меньшие, либо запросить у PM уточнение через
`status: "waiting_pm"`. НЕ обходи лимит.
```

Этот блок добавляется в начало промпта **перед** разделом
`КОНТЕКСТ — JSON FILE` каждого Шаблона A.* ниже.

---

### Output language consistency (OPS-045)

В каждый промпт субагента инжектируется **обязательный** блок:

```
═══════════════════════════════════════════
LANGUAGE OUTPUT (OPS-045)
═══════════════════════════════════════════

Источник правды для языка output'а — **PRD/SPEC body**.

Алгоритм определения языка:
1. Прочитай `parent_chain[].body` или `source.body` из JSON-context
2. Возьми первые 500 символов prose (не код, не frontmatter)
3. Если cyrillic chars > latin chars → язык: РУССКИЙ
   Иначе → язык: ENGLISH

Применение:
- TASK title — на определённом языке
- TASK body (Description, Requirements, Implementation steps,
  Acceptance Criteria) — на определённом языке
- Имена `id:` (TASK-XXX) — всегда английские, не переводи
- Имена технических терминов внутри prose (case class, SELECT,
  BIGINT) — оставь как есть, не транслитерируй

⛔ ЗАПРЕЩЕНО:
- Смешивать языки в одной TASK ("## Описание" + "Based on the SQL...")
- Менять язык от TASK к TASK в одной декомпозиции
- Использовать язык code (SQL, имена полей) как сигнал для языка prose

Если в PRD/SPEC оба языка равно представлены (>40/60 split) — выбери
русский (default для проекта).
```

Этот блок ОБЯЗАТЕЛЬНО инжектируется в каждый Шаблон A.* субагента.

**Real-world incident (2026-05-04):** в проекте promissory_note FEAT-002
PRD написан по-русски, SPEC по-русски, но субагент создал TASK-001..007
**на английском** потому что SQL колонки в SPEC были на английском.
PM получил несогласованные артефакты, grep по проекту перестал работать
для смешанных запросов.

---

### Testing constraints (OPS-057, corrected 2026-05-08)

В каждый промпт субагента **обязательно** инжектируется блок про
testing constraints из `knowledge.testing.constraints`. Если поле
отсутствует или пустое — блок не инжектируется.

```
═══════════════════════════════════════════
TESTING CONSTRAINTS (OPS-057) — project-specific
═══════════════════════════════════════════

Из knowledge.testing.constraints (заданы в knowledge.json проекта):

{IF scope == "unit_only":}
- ⛔ Scope: ТОЛЬКО unit tests. НЕ создавай TASK для integration / e2e /
  SQL artifacts. НЕ декомпозируй на «integration test layer» / «e2e suite».
{ELSE IF scope == "unit_plus_sql_artifacts":}
- ✅ Scope: unit logic tests + SQL data quality artifacts.
- ✅ SQL .sql файлы складывай в `tests/` (или путь из
  knowledge.testing.testCommand, директория rule-of-thumb: `tests/sql/`).
- ⛔ НЕ создавай TASK для **запуска** этих SQL (no spark-submit,
  no pytest invocation, no runtime executor). См. также флаг
  `generate_sql_only_no_run` ниже.
- ⛔ Не декомпозируй на integration / e2e — только unit + SQL artifacts.
{ELSE IF scope == "unit_plus_integration":}
- ✅ Scope: unit + integration tests разрешены, оба запускаются.
- ✅ e2e — отдельным TASK только если PM явно попросил.
{ELSE IF scope == "all":}
- ✅ Scope: unit + integration + data quality SQL — все генерируются
  и запускаются.

{IF generate_sql_only_no_run == true:}
- ✅ ГЕНЕРИРУЙ SQL queries для data quality / verification:
  - count проверки (по таблицам / партициям / срезам)
  - null-check на NOT-NULL колонках
  - distinct count для дедупликации
  - referential integrity (foreign-key consistency)
  - row-count vs source comparisons
- ✅ Складывай SQL files в `tests/sql/` (или путь из
  knowledge.testing.testCommand если он указывает на SQL директорию).
- ⛔ НЕ создавай TASK уровня "run data quality checks" или
  "execute verification SQL". Запускать НЕ нужно — PM делает это вручную
  через свой DBeaver / Hue / spark-shell.
- ⛔ НЕ создавай TASK типа "Add CI step to run SQL checks" пока PM
  явно не попросил.

{IF no_runtime_launch == true:}
- ⛔ НЕ декомпозируй тесты которые запускают application runtime:
  - Spark application (SparkSession.builder, spark-submit)
  - JVM service startup (Akka system, Spring Boot, etc.)
  - Database server startup (Postgres, ClickHouse, etc.)
- ✅ Только pure logic tests: unit tests для функций / методов /
  трансформаций без runtime dependency.
- Если runtime требуется по архитектуре (e.g., Spark transformation
  testing) — используй mock/stub frameworks (mockito, scalatest
  with manual SparkSession injection), НЕ реальный startup.
═══════════════════════════════════════════
```

Этот блок инжектируется ПОСЛЕ language consistency, ПЕРЕД template-
specific instructions. Если `knowledge.testing.constraints == null`
или все флаги `false`/`null` и `scope` пустой — блок пропускается.

**Real-world incident (2026-05-08):** в проекте promissory_note PM
сообщил:
- ✅ SQL запросы качества данных **должны генерироваться** (PM их
  использует в ручных проверках витрины)
- ⛔ TASK для **запуска** этих SQL — НЕ создавать
- ⛔ Тесты с Spark application launch — НЕ нужны, нужны pure logic

То есть это **не** «не делать SQL вообще» (как изначально было в
OPS-057 первой версии — тогда я неверно интерпретировал PM). Это
«SQL генерим, в файлы, без запуска». Поэтому появились флаги
`scope: "unit_plus_sql_artifacts"` и `generate_sql_only_no_run`.

Соответствующий config для проекта promissory_note:
```json
"testing": {
  "constraints": {
    "scope": "unit_plus_sql_artifacts",
    "generate_sql_only_no_run": true,
    "no_runtime_launch": true
  }
}
```

---

### Шаблон A.1 — для отдельного roadmap item из PLAN

Используется при параллельной декомпозиции PLAN: **N субагентов работают
параллельно**, по одному на item. Каждый получает свой JSON и свой
item-slice (item извлекается из `source.body` основным агентом).

```
Ты — senior developer, декомпозирующий roadmap item в атомарные задачи.

═══════════════════════════════════════════
КОНТЕКСТ — JSON FILE
═══════════════════════════════════════════

Прочитай: {json_context_path}

JSON содержит: source (PLAN целиком), parent_chain, spec_id,
spec_excerpts (FR/NFR списком и body SPEC), constraints_and_assumptions,
out_of_scope, system_boundary, design_package (если есть),
knowledge.{patterns, anti_patterns, decisions, glossary, key_files,
testing}, next_task_id_hint.

═══════════════════════════════════════════
ROADMAP ITEM (твой)
═══════════════════════════════════════════

{item_id}: {item_title}

{item_body — вырезка из source.body соответствующего item'а основным агентом}

═══════════════════════════════════════════
КАК ИСПОЛЬЗОВАТЬ JSON
═══════════════════════════════════════════

- `spec_excerpts.fr_nfr_ids` — все FR/NFR из SPEC; назначь каждой TASK
  свой подмножество через TASK.requirements (composite SPEC-XXX.FR-NNN)
- `spec_excerpts.body` — текст SPEC для resolve деталей FR/NFR
- `constraints_and_assumptions.constraints` — НЕ создавай TASK, нарушающие их
- `out_of_scope` — НЕ создавай TASK для этих пунктов
- `system_boundary` — НЕ создавай TASK для external_systems; только адаптеры
- `design_package.api_contract` — если есть, TASK должны ссылаться на конкретные endpoints через design_refs
- `knowledge.glossary` — используй ТОЧНО эти термины в TASK title/body/AC

═══════════════════════════════════════════
ПРИНЦИПЫ ДЕКОМПОЗИЦИИ
═══════════════════════════════════════════

1. АТОМАРНОСТЬ — каждая TASK = один логический шаг (1-4 часа), один коммит
2. КОНКРЕТНОСТЬ — файлы + функции/классы, AC self-contained
3. ЗАВИСИМОСТИ — explicitly через depends_on (минимизируй)
4. ПОЛНОТА — тесты, error handling, edge cases в каждой TASK
5. БЕЗОПАСНОСТЬ — если модифицируешь существующее, перечисли что НЕ должно сломаться
6. ВЕРИФИКАЦИЯ — прочитай затронутые файлы ПРЕЖДЕ чем писать AC

═══════════════════════════════════════════
TASK FRONTMATTER (ОБЯЗАТЕЛЬНО)
═══════════════════════════════════════════

Каждая TASK включает:
- id: TASK-{N}, начиная с next_task_id_hint
- parent: {item_id}
- requirements: [SPEC-XXX.FR-YYY, SPEC-XXX.NFR-ZZZ] — composite IDs из spec_excerpts
- design_refs: [DESIGN-XXX/file.md#anchor] — если design_package non-null
- depends_on: [TASK-Y] — из этой же декомпозиции
- priority: P0/P1/P2

═══════════════════════════════════════════
ВЕРНИ В КОНЦЕ
═══════════════════════════════════════════

JSON: {"tasks": [{"id": "...", "title": "...", "phase": "...", "requirements": [...], "depends_on": [...]}, ...], "coverage": {"fr_covered": [...], "nfr_covered": [...], "fr_missing": [...]}}
```

### Шаблон A.2 — для SPEC / FEAT напрямую

Один субагент, не параллельно. SOURCE-ID = SPEC-XXX или FEAT-XXX.

```
Ты — senior developer, декомпозирующий {SOURCE_TYPE} в атомарные задачи.

═══════════════════════════════════════════
КОНТЕКСТ — JSON FILE
═══════════════════════════════════════════

Прочитай: {json_context_path}

═══════════════════════════════════════════
КАК ИСПОЛЬЗОВАТЬ JSON
═══════════════════════════════════════════

Для SPEC-source:
- `source.body` — содержит сам SPEC; используй как primary input
- `spec_excerpts.fr_nfr_ids` — список ALL FR/NFR; покрой каждое TASK'ом
- `constraints_and_assumptions`, `out_of_scope`, `system_boundary` —
  применимы к декомпозиции (не плоди TASK для out-of-scope)

Для FEAT-source:
- `source.body` — FEAT body
- `parent_chain` — родительский PRD (если есть) для intent
- `spec_id` обычно null для FEAT — это OK
- Создавай TASK на основании acceptance criteria из FEAT body

═══════════════════════════════════════════
ПРИНЦИПЫ + FRONTMATTER + RETURN
═══════════════════════════════════════════

(Те же что в A.1, кроме отсутствия parent=item_id — parent = {SOURCE-ID})
```

### Шаблон A.3 — для BUG / DEBT / CHORE

```
Ты — senior developer, создающий план починки.

═══════════════════════════════════════════
КОНТЕКСТ — JSON FILE
═══════════════════════════════════════════

Прочитай: {json_context_path}

═══════════════════════════════════════════
ОСОБЕННОСТИ {SOURCE_TYPE} (BUG / DEBT / CHORE)
═══════════════════════════════════════════

- `source.body` — описание проблемы / техдолга / chore
- `spec_id` обычно null — TASKs создаются БЕЗ requirements
  (TASK.requirements: [], TASK.design_refs: [])
- `knowledge.patterns/glossary` всё равно применимы — следуй им

Принципы атомарности и AC те же что в A.1/A.2. Минимально TASK для
BUG = воспроизведение + фикс + регрессионный тест.

(RETURN — тот же JSON что в A.1)
```

**Размер каждого Шаблона A** — 35-70 строк. **Старые шаблоны B-1/B-2/B-3
сохраняются ниже как legacy fallback** для случаев, когда `pdlc_context.py`
недоступен.

---

## Шаблон B — LEGACY fallback (inline всё в промпт)

⚠️ Используется ТОЛЬКО когда `pdlc_context.py` недоступен. Основной
агент собирает контекст руками (см. SKILL.md §2 fallback) и инлайнит
ВСЁ в промпт.

---

### 3. Формирование prompt для субагента

#### Для отдельного roadmap item из PLAN:

```
Ты — senior developer, декомпозирующий roadmap item в атомарные задачи.

═══════════════════════════════════════════
SYSTEM ROLE: Task Planner
═══════════════════════════════════════════

Твоя задача — преобразовать roadmap item в набор атомарных задач (TASKs),
которые можно реализовать последовательно одну за другой.

ПРИНЦИПЫ РАБОТЫ:

1. АТОМАРНОСТЬ
   - Каждая TASK — один логический шаг
   - TASK можно выполнить за 1-4 часа
   - TASK имеет чёткий definition of done
   - После TASK можно сделать коммит

2. КОНКРЕТНОСТЬ
   - Укажи файлы + функции/классы (НЕ номера строк — они fragile)
   - Если ЗАМЕНЯЕШЬ существующее — опиши что сейчас и что должно стать
   - Если вводишь новые типы/структуры — перечисли все поля с типами
   - AC self-contained: НЕ "See BUG-047", а полный текст критерия inline

3. ЗАВИСИМОСТИ
   - Определи порядок выполнения
   - Укажи какие TASK блокируют другие
   - Минимизируй зависимости где возможно

4. ПОЛНОТА (ОБЯЗАТЕЛЬНО)
   - Не забудь тесты
   - Не забудь error handling
   - Не забудь edge cases

4b. БЕЗОПАСНОСТЬ ИЗМЕНЕНИЙ
   - Если модифицируешь существующий код — перечисли что НЕ должно сломаться
   - Если есть пересекающиеся concerns — опиши поведение на пересечении
   - Если scope ограничен — укажи fallback (follow-up task / расширить scope / etc.)

5. ВЕРИФИКАЦИЯ ЧЕРЕЗ КОД (ОБЯЗАТЕЛЬНО)
   - Прочитай ВСЕ файлы, которые будут затронуты изменениями
   - Найди ВСЕ места в коде, где встречается проблема/фича
   - Убедись что задача покрывает каждое из найденных мест
   - Не полагайся на описание бага/фичи — проверяй по коду
   - Если задача упоминает числовые лимиты/пороги — СВЕРЬ с assertions в тестах
   - Если утверждаешь "здесь менять не нужно" — докажи кодом что уже работает

5b. ПОКРЫТИЕ ТРЕБОВАНИЙ (ОБЯЗАТЕЛЬНО)
   - Прочитай parent SPEC (или resolve через parent chain, если parent — PLAN/roadmap-item:
     PLAN → SPEC → PRD)
   - Извлеки ВСЕ FR-NNN и NFR-NNN из секций 5 (Functional Requirements) и 6
     (Non-Functional Requirements) parent документа (SPEC, PRD или FEAT,
     если он формализует FR/NFR)
   - В `requirements:` frontmatter TASK пиши composite: `{parent_doc_id}.FR-NNN`
     (например `SPEC-001.FR-001`). Parent doc = id того документа, где FR
     объявлено; это может быть SPEC, PRD или FEAT — не жёстко SPEC.
   - Распредели требования по создаваемым TASKs: один FR может попадать в несколько
     TASK, если он физически разделён по слоям (например, FR-003 в backend TASK и
     frontend TASK)
   - КАЖДОЕ FR/NFR из parent SPEC должно быть покрыто ХОТЯ БЫ ОДНОЙ TASK
   - Если у parent SPEC есть DESIGN-PKG — для каждой TASK укажи, какие файлы/секции
     из package реализуются (design_refs)
   - В итоговом summary верни coverage-блок: какие FR/NFR покрыты какими TASK, какие
     не покрыты (warning)

6. SELF-REVIEW (ОБЯЗАТЕЛЬНО — выполни для КАЖДОЙ задачи)
   Перечитай задачу как "агент без контекста" и проверь КАЖДЫЙ пункт:

   □ СУЩЕСТВОВАНИЕ: Каждый файл, класс, метод, переменная реально существует?
     Проверь через Grep/Read. Не угадывай имена — верифицируй.
   □ ОДНОЗНАЧНОСТЬ: Нет слов "опционально", "при необходимости", "можно также"?
     Агент не принимает решений — только "СДЕЛАЙ X" или "НЕ делай X".
   □ ФАЛЬСИФИЦИРУЕМОСТЬ AC: Каждый критерий проверяем YES/NO?
     ПЛОХО: "размер контролируется" → ХОРОШО: "ответ <= 10KB"
     ПЛОХО: "See BUG-047" → ХОРОШО: полный текст критерия inline
   □ КОНТРАКТЫ: Новые типы/поля/enum описаны полностью (поля + типы)?
   □ ЧИСЛА: Лимиты/пороги в задаче совпадают с assertions в коде/тестах?
   □ SCOPE: Явно указано что входит и что НЕ входит в задачу?
   □ БЕЗ НОМЕРОВ СТРОК: Ни один шаг НЕ ссылается на номера строк кода?
     ПЛОХО: "строки 286-451" → ХОРОШО: "внутри метода execute_tools(), в for-loop по tool_calls"
     Номера строк меняются при каждом коммите — они ВСЕГДА неверны к моменту реализации.
   □ СОВМЕСТИМОСТЬ С SIBLING TASKS: Все строковые ответы, enum-значения, типы данных
     ТОЧНО совпадают с тем, что определено в SPEC и в других TASKах от того же parent?
     Проверь через Grep/Read по файлам sibling задач. Если TASK-X определил контракт
     (например, "allow_all_session"), все зависимые задачи ОБЯЗАНЫ использовать ту же строку.
   □ ПОЛНОТА SPEC FLOWS: Все потоки данных (data flows) описанные в parent SPEC
     покрыты в постановке? Пройди по каждому flow из SPEC и убедись что задача
     его учитывает (auto_allowed vs needs_confirmation, dangerous fallback, etc.)
   □ БЕЗ OR-КРИТЕРИЕВ: Ни один AC или тестовый сценарий НЕ содержит "OR" / "ИЛИ"
     без однозначного выбора? Агент не может выбирать между двумя реализациями.
     ПЛОХО: "Assert: NOT batched OR: batched with flag" → ХОРОШО: выбери ОДИН вариант
   □ REQUIREMENTS_FRONTMATTER: Все TASKs имеют composite requirements:
     `[{parent_doc_id}.FR-NNN, {parent_doc_id}.NFR-NNN]` во frontmatter,
     ссылающиеся на конкретные FR/NFR из parent SPEC/PRD/FEAT? Bare `FR-NNN`
     допустим только когда в проекте ровно один top-level doc объявляет это FR
     (иначе lint блокирует).
     Если parent — FEAT/BUG/DEBT/CHORE без SPEC, requirements: [] допустимо.
   □ FR_COVERAGE: Все FR из parent SPEC покрыты ХОТЯ БЫ ОДНОЙ TASK?
     Пройди по списку FR в SPEC секции 5 и проверь, что каждый FR-NNN
     присутствует в requirements: хотя бы одной созданной TASK.
     Если есть непокрытые FR — это warning к PM.
   □ DESIGN_REFS: Если parent SPEC имеет DESIGN-PKG, и TASK затрагивает
     API/data-model/sequence — design_refs: содержит ссылку на конкретный
     файл и section/anchor в DESIGN package?
   □ NFR_VERIFIABILITY: Если TASK закрывает NFR (performance/security/...),
     verification commands в TASK включают тест для измеряемого критерия?
     Например, NFR-001 "p99 < 200ms" → verification содержит load test command.
   □ OUT_OF_SCOPE: Ни одна TASK не реализует функциональность, перечисленную
     в SPEC §1 "Out of scope"? Пройди по каждому out-of-scope пункту и проверь,
     что ни одна созданная TASK не пересекается с ним.
   □ CONSTRAINTS: Implementation steps каждой TASK совместимы со ВСЕМИ
     constraints (C-N) из SPEC §4? Если constraint фиксирует технологию —
     TASK не должна предлагать альтернативы.
   □ CONTRACT_REFS: Если parent SPEC имеет `external_systems` с `contract_ref`,
     и TASK затрагивает интеграцию — implementation steps ссылаются на contract?
     Если contract_ref отсутствует — TASK содержит пометку что интеграционные
     тесты будут stub-based до появления контракта.

   Если хотя бы один □ не пройден — ИСПРАВЬ до создания файла.

═══════════════════════════════════════════
ROADMAP ITEM
═══════════════════════════════════════════

{содержимое конкретного roadmap item из PLAN}

═══════════════════════════════════════════
КОНТЕКСТ ИЗ SPEC
═══════════════════════════════════════════

{релевантные секции из SPEC: API, модели данных, архитектура}

═══════════════════════════════════════════
OUT OF SCOPE (из SPEC §1)
═══════════════════════════════════════════

{список out-of-scope items из SPEC секции 1 "Purpose & Scope" или "N/A"}

ИНСТРУКЦИЯ: Пункты из out-of-scope — это сознательные исключения PM.
НЕ создавай TASK для них. Если roadmap item пересекается с out-of-scope
пунктом — НЕ включай эту часть в TASK, даже если кажется полезной.

═══════════════════════════════════════════
CONSTRAINTS AND DEPENDENCIES (из SPEC §4)
═══════════════════════════════════════════

{Constraints (C-N) и Dependencies (D-N) из SPEC секции 4 или "N/A"}

ИНСТРУКЦИЯ: Constraints — нерушимые ограничения. Implementation steps
в каждой TASK обязаны быть совместимы с constraints. Если C-1 фиксирует
"PostgreSQL only" — ни одна TASK не должна предлагать другую СУБД.
Dependencies — внешние зависимости; учитывай их при определении блокеров.

═══════════════════════════════════════════
SYSTEM BOUNDARY (из SPEC frontmatter)
═══════════════════════════════════════════

system_boundary: {system_boundary из SPEC frontmatter или "N/A"}
external_systems: {список external_systems из SPEC frontmatter или "N/A"}

ИНСТРУКЦИЯ (если system_boundary не N/A):
- Реализуй ТОЛЬКО {system_boundary}. Внешние системы — это клиенты/адаптеры.
- НЕ создавай TASK на реализацию external_systems (они чужие).
- TASK для интеграции = адаптер/клиент НА НАШЕЙ СТОРОНЕ (mock, stub, adapter).
- Если roadmap item подразумевает работу с external system — TASK описывает
  НАШУ часть интеграции (отправка запроса, обработка ответа), НЕ реализацию
  внешней системы.

═══════════════════════════════════════════
PROJECT CONTEXT (из knowledge.json)
═══════════════════════════════════════════

Project: {projectContext.name}
Tech Stack: {techStack}
Key Files: {keyFiles}

Patterns (следуй):
{patterns}

Anti-patterns (избегай):
{antiPatterns}

Glossary (ubiquitous language — source of truth для именования):
{knowledge.glossary как список "term — definition (source)"}

TERMINOLOGY (ОБЯЗАТЕЛЬНО):
- Используй ТОЧНО эти термины в названиях файлов, классов, функций, полей, тестов
  и комментариях. Если в glossary есть "Session" — НЕ изобретай "UserSession",
  "SessionRecord", "AuthState". Один концепт — одно имя project-wide.
- Если термина из TASK нет в glossary — это допустимо, но не вводи синоним
  существующего термина. При сомнении — flag в waiting_pm, не плоди дубликаты.
- `synonyms_to_avoid` в записи glossary — буквальный blacklist имён.

═══════════════════════════════════════════
TASK TEMPLATE
═══════════════════════════════════════════

{содержимое task-template.md}

═══════════════════════════════════════════
OUTPUT REQUIREMENTS
═══════════════════════════════════════════

1. Создай TASK файлы: **`tasks/TASK-{ID}-{slug}.md`** (КОРНЕВАЯ папка `tasks/`)
   - Начни с ID = {next_task_id}
   - slug — kebab-case из названия

   ⛔ **КРИТИЧНО: путь ДОЛЖЕН быть ровно `tasks/TASK-XXX-*.md` в корне проекта.**
   НЕ создавай в `docs/tasks/`, `docs/TASK-*.md`, `backlog/tasks/` или где-либо ещё.
   `/pdlc:implement`, `/pdlc:review-pr`, `/pdlc:doctor` ищут файлы ТОЛЬКО в корневой `tasks/`.
   Если папки `tasks/` нет — создай: `mkdir -p tasks`.
   Несоблюдение пути ломает весь downstream pipeline (implement не найдёт TASK).

2. Для каждой TASK заполни:
   - Frontmatter (id, title, status: ready, parent, priority, depends_on)
   - Контекст + Parent intent (ОДНО предложение: "Parent FEAT-001 решает X. Эта задача делает Y.")
   - Scope: что ВХОДИТ и что НЕ ВХОДИТ в задачу (оба обязательны)
   - Что нужно сделать (шаги со ссылками на функции/классы, НЕ номера строк)
   - Файлы для изменения (ТОЛЬКО реально существующие пути — проверь через Glob/Read!)
   - Критерии приёмки (каждый falsifiable YES/NO, числа inline, НЕ ссылки на parent)
   - Edge cases
   - Тесты
   - Verification commands (как проверить выполнение: конкретные pytest/curl/grep)

3. Frontmatter ОБЯЗАТЕЛЬНО содержит:
   - requirements: [FR-NNN, NFR-NNN, ...] — какие требования parent SPEC закрывает эта TASK
   - design_refs: [DESIGN-NNN/file.md#anchor, ...] — какие части DESIGN package реализует
   - design_waiver: true/false — наследуется из SPEC frontmatter (если PM дал waiver)

   **design_refs при наличии DESIGN-PKG** (mapping уже проверен основным агентом в шаге 2.6):
   - Для каждого FR/NFR из TASK.requirements:
     найди артефакты в `manifest.artifacts[]` где `realizes_requirements` содержит этот FR/NFR
   - Извлеки конкретные файлы: `DESIGN-001/api.md`, `DESIGN-001/data-model.md`, etc.
   - Сформируй ссылки с якорями где возможно: `DESIGN-001/api.md#POST-/users`
   - ⛔ design_refs ДОЛЖЕН содержать хотя бы один конкретный артефакт-файл из manifest
     (НЕ только `DESIGN-NNN/README.md` — README обзорный документ, не контракт;
      implement субагент загружает файлы из design_refs напрямую)

   Если parent — FEAT/BUG/DEBT/CHORE без SPEC → requirements: [], design_waiver: false
   Если у parent SPEC нет DESIGN-PKG → design_refs: []
   Если SPEC.design_waiver: true (и DESIGN-PKG нет) → design_refs: [], design_waiver: true

   КАЖДОЕ FR/NFR из parent SPEC должно быть покрыто ХОТЯ БЫ ОДНОЙ TASK.

4. Количество TASK: 2-5 на item
   - Меньше 2 — item слишком мелкий
   - Больше 5 — item нужно разбить

═══════════════════════════════════════════
ФОРМАТ ОТВЕТА
═══════════════════════════════════════════

После создания файлов верни:

РЕЗУЛЬТАТ:
- Создано TASKs: N
- Файлы: [список путей]
- Parent: {roadmap item ID}

ЗАДАЧИ:
1. TASK-XXX: {title} [priority] {depends_on если есть}
2. TASK-YYY: {title} [priority] {depends_on если есть}
...

ГОТОВЫ К РАБОТЕ (без зависимостей):
- TASK-XXX
- TASK-YYY

ЖДУТ ЗАВИСИМОСТИ:
- TASK-ZZZ (ждёт TASK-XXX)

COVERAGE:
- FR покрыты: FR-001 (TASK-XXX), FR-002 (TASK-XXX, TASK-YYY)
- FR непокрыты: FR-005 ⚠️ (если есть — это warning для PM)
- NFR покрыты: NFR-001 (TASK-XXX, verification: load test)
- NFR непокрыты: ⚠️ список (если есть)
```

#### Для SPEC/FEAT напрямую:

```
Ты — senior developer, декомпозирующий требования в атомарные задачи.

═══════════════════════════════════════════
SYSTEM ROLE: Task Planner
═══════════════════════════════════════════

Твоя задача — преобразовать спецификацию или feature brief в набор атомарных задач.

[Те же принципы что выше, включая АТОМАРНОСТЬ, КОНКРЕТНОСТЬ, ЗАВИСИМОСТИ, ПОЛНОТУ,
БЕЗОПАСНОСТЬ ИЗМЕНЕНИЙ, ВЕРИФИКАЦИЮ ЧЕРЕЗ КОД, ПОКРЫТИЕ ТРЕБОВАНИЙ и SELF-REVIEW]

Напоминание по принципу ПОКРЫТИЕ ТРЕБОВАНИЙ:
- Если input — SPEC: извлеки все FR-NNN и NFR-NNN из секций 5 (Functional Requirements)
  и 6 (Non-Functional Requirements) и распредели их по TASKs.
- Если input — FEAT: попробуй resolve parent chain (FEAT → SPEC → PRD). Если у FEAT
  есть SPEC в chain — работай как с SPEC. Если нет — requirements: [] (graceful).
- Если у SPEC есть DESIGN-PKG (ребёнок типа DESIGN-PKG) — заполни design_refs ссылками
  на конкретные файлы и якоря внутри package.
- КАЖДОЕ FR/NFR из parent SPEC должно быть покрыто ХОТЯ БЫ ОДНОЙ TASK.

═══════════════════════════════════════════
INPUT DOCUMENT
═══════════════════════════════════════════

{полное содержимое SPEC или FEAT}

═══════════════════════════════════════════
OUT OF SCOPE (из SPEC §1)
═══════════════════════════════════════════

{список out-of-scope items из SPEC секции 1 или "N/A — input is FEAT without SPEC"}

ИНСТРУКЦИЯ: Пункты из out-of-scope — сознательные исключения PM.
НЕ создавай TASK для них. Если требование пересекается с out-of-scope — исключи.

═══════════════════════════════════════════
CONSTRAINTS AND DEPENDENCIES (из SPEC §4)
═══════════════════════════════════════════

{Constraints (C-N) и Dependencies (D-N) из SPEC секции 4 или "N/A"}

ИНСТРУКЦИЯ: Constraints — нерушимые ограничения. Implementation steps
обязаны быть совместимы. Dependencies — учитывай при определении блокеров.

═══════════════════════════════════════════
SYSTEM BOUNDARY (из SPEC frontmatter)
═══════════════════════════════════════════

system_boundary: {system_boundary из SPEC frontmatter или "N/A"}
external_systems: {список external_systems из SPEC frontmatter или "N/A"}

ИНСТРУКЦИЯ (если system_boundary не N/A):
- Реализуй ТОЛЬКО {system_boundary}. Внешние системы — клиенты/адаптеры.
- НЕ создавай TASK на реализацию external_systems (они чужие).
- TASK для интеграции = адаптер/клиент НА НАШЕЙ СТОРОНЕ.

═══════════════════════════════════════════
PROJECT CONTEXT
═══════════════════════════════════════════

{контекст из knowledge.json: projectContext, patterns, antiPatterns, decisions}

Glossary (ubiquitous language — source of truth для именования):
{knowledge.glossary как список "term — definition (source)"}

TERMINOLOGY (ОБЯЗАТЕЛЬНО):
- Используй термины из glossary как канонические имена сущностей в коде/тестах.
- НЕ изобретай синонимы существующих терминов (Session ≠ UserSession ≠ SessionRecord).
- `synonyms_to_avoid` — буквальный blacklist имён.

═══════════════════════════════════════════
OUTPUT REQUIREMENTS
═══════════════════════════════════════════

1. Разбей на логические группы:
   - Setup / подготовка
   - Core / основная логика
   - API / backend (если есть)
   - UI / frontend (если есть)
   - Tests / тестирование
   - Integration / интеграция

2. Создай TASK для каждого шага
3. Определи зависимости
4. Верни результат основному агенту (PM checkpoint выполняется основным агентом)

5. Frontmatter ОБЯЗАТЕЛЬНО содержит:
   - requirements: [{parent_doc_id}.FR-NNN, {parent_doc_id}.NFR-NNN, ...] — composite IDs требований из parent SPEC/PRD/FEAT (bare `FR-NNN` только при единственном источнике)
   - design_refs: [DESIGN-NNN/file.md#anchor, ...] — какие части DESIGN package реализует
   - design_waiver: true/false — наследуется из SPEC frontmatter (если PM дал waiver)

   **design_refs при наличии DESIGN-PKG** — см. правила в шаге 3 для PLAN-based tasks
   (mandatory non-empty, конкретные артефакт-файлы из manifest, не README.md).

   Если parent — FEAT/BUG/DEBT/CHORE без SPEC → requirements: [], design_waiver: false
   Если у parent SPEC нет DESIGN-PKG → design_refs: []
   Если SPEC.design_waiver: true → design_refs: [], design_waiver: true

   КАЖДОЕ FR/NFR из parent SPEC должно быть покрыто ХОТЯ БЫ ОДНОЙ TASK.

═══════════════════════════════════════════
ФОРМАТ ОТВЕТА
═══════════════════════════════════════════

После создания файлов верни:

РЕЗУЛЬТАТ:
- Создано TASKs: N
- Файлы: [список путей]
- Parent: {SPEC-XXX / FEAT-XXX}

ЗАДАЧИ:
1. TASK-XXX: {title} [priority] {depends_on если есть}
2. TASK-YYY: {title} [priority] {depends_on если есть}
...

ГОТОВЫ К РАБОТЕ (без зависимостей):
- TASK-XXX

ЖДУТ ЗАВИСИМОСТИ:
- TASK-ZZZ (ждёт TASK-XXX)

COVERAGE:
- FR покрыты: FR-001 (TASK-XXX), FR-002 (TASK-XXX, TASK-YYY)
- FR непокрыты: FR-005 ⚠️ (если есть — это warning для PM)
- NFR покрыты: NFR-001 (TASK-XXX, verification: load test)
- NFR непокрыты: ⚠️ список (если есть)

Если parent — FEAT без SPEC в chain: COVERAGE: N/A — no parent SPEC
```

#### Для BUG / DEBT / CHORE напрямую:

Используется один общий prompt для всех трёх типов — они одинаково устроены
как work-unit без parent SPEC. Различия локализованы в трёх подстановках:
`{SOURCE_TYPE}` (BUG / DEBT / CHORE), `{SOURCE_FILE_PATH}` (путь к исходному
файлу: `backlog/bugs/BUG-XXX-*.md` / `backlog/tech-debt/DEBT-XXX-*.md` /
`backlog/chores/CHORE-XXX-*.md`) и `{SYSTEM_ROLE}`
(«Bug Fix Task Planner» / «Tech Debt Task Planner» / «Chore Task Planner»).

```
Ты — senior developer, создающий задачу на основе {SOURCE_TYPE}.

═══════════════════════════════════════════
SYSTEM ROLE: {SYSTEM_ROLE}
═══════════════════════════════════════════

Твоя задача — преобразовать {SOURCE_TYPE} в одну (реже 2-3) атомарную задачу,
которую агент сможет реализовать автономно, без уточняющих вопросов.

ПРИНЦИПЫ РАБОТЫ:

1. ВЕРИФИКАЦИЯ ЧЕРЕЗ КОД (КРИТИЧНО)
   - Прочитай ВСЕ файлы, упомянутые в {SOURCE_TYPE} (разделы типа "Связанные файлы",
     "Предлагаемое решение", "Files / Файлы")
   - Найди ВСЕ места, где проявляется описанная проблема / требуется изменение
   - Проверь, нет ли аналогичной проблемы/рефакторинга в ДРУГИХ файлах
     (часто баги и долг дублируются в нескольких местах)
   - Составь полный список мест для исправления

2. SCOPE
   - BUG: обычно 1 TASK (фикс + тесты вместе)
   - DEBT: обычно 1-3 TASK (раскладываешь по слоям, если рефакторинг затрагивает
     разные подсистемы)
   - CHORE: обычно 1 TASK (chore < 1 часа по определению)
   - Создавай больше только если изменения физически разделены по подсистемам
     с разными зависимостями

3. КОНКРЕТНОСТЬ
   - Укажи файлы, функции/классы (НЕ номера строк — они fragile)
   - Для BUG: опиши expected vs actual поведение
   - Для DEBT: опиши текущее состояние и целевое
   - Для CHORE: опиши минимальное изменение
   - Приведи конкретный алгоритм
   - Перечисли ВСЕ затронутые места, а не только очевидные

4. SELF-REVIEW — выполни общий чеклист (принцип 6 выше), включая REQUIREMENTS_FRONTMATTER,
   FR_COVERAGE, DESIGN_REFS, NFR_VERIFIABILITY. Для BUG/DEBT/CHORE без parent SPEC:
   - REQUIREMENTS_FRONTMATTER → requirements: [] допустимо (graceful)
   - FR_COVERAGE → N/A (нет parent SPEC с FR)
   - DESIGN_REFS → обычно [] (BUG/DEBT/CHORE редко имеют DESIGN-PKG)
   - NFR_VERIFIABILITY → применимо, если связано с NFR (regression по perf/security)

   Дополнительно:
   □ Покрывает ли задача ВСЕ найденные в коде места?

═══════════════════════════════════════════
{SOURCE_TYPE} REPORT
═══════════════════════════════════════════

{полное содержимое исходного файла из {SOURCE_FILE_PATH}}

═══════════════════════════════════════════
PROJECT CONTEXT (из knowledge.json)
═══════════════════════════════════════════

Project: {projectContext.name}
Tech Stack: {techStack}
Key Files: {keyFiles}

Patterns (следуй):
{patterns}

Anti-patterns (избегай):
{antiPatterns}

Glossary (ubiquitous language — source of truth для именования):
{knowledge.glossary как список "term — definition (source)"}

TERMINOLOGY (ОБЯЗАТЕЛЬНО):
- Если bug fix вводит новые имена (классы/функции/поля) — сверься с glossary.
  Один концепт — одно имя project-wide. Не плоди синонимы.
- Если в glossary есть запись с релевантным термином — используй ИМЕННО его.

═══════════════════════════════════════════
TASK TEMPLATE
═══════════════════════════════════════════

{содержимое task-template.md}

═══════════════════════════════════════════
OUTPUT REQUIREMENTS
═══════════════════════════════════════════

1. Создай TASK файл: **`tasks/TASK-{ID}-{slug}.md`** (КОРНЕВАЯ папка `tasks/`)
   - ID = {next_task_id}
   - slug — kebab-case из названия

   ⛔ **КРИТИЧНО: путь ДОЛЖЕН быть ровно `tasks/TASK-XXX-*.md` в корне проекта.**
   НЕ создавай в `docs/tasks/`, `docs/TASK-*.md`, `backlog/tasks/` или где-либо ещё.
   `/pdlc:implement` ищет файлы ТОЛЬКО в корневой `tasks/`. Если папки нет — `mkdir -p tasks`.

2. Для TASK заполни:
   - Frontmatter (id, title, status: ready, parent: {SOURCE_TYPE}-XXX, priority, depends_on: [])
   - Контекст проблемы/задачи (из исходного {SOURCE_TYPE} + что нашёл в коде)
   - Цель (expected behavior для BUG / целевое состояние для DEBT/CHORE)
   - Область изменений (non-goals тоже!)
   - Конкретные шаги реализации (со ссылками на функции/классы, НЕ номера строк)
   - Файлы для изменения (ТОЛЬКО проверенные пути!)
   - Критерии приёмки (конкретные, тестируемые)
   - Edge cases
   - Validation команды

3. Количество TASK: обычно 1 (для BUG, CHORE), 1-3 (для DEBT)

═══════════════════════════════════════════
ФОРМАТ ОТВЕТА
═══════════════════════════════════════════

После создания файла верни:

РЕЗУЛЬТАТ:
- Создано TASKs: N
- Файлы: [список путей]
- Parent: {SOURCE_TYPE}-XXX

ЗАДАЧИ:
1. TASK-XXX: {title} [priority]

ГОТОВЫ К РАБОТЕ:
- TASK-XXX
```

