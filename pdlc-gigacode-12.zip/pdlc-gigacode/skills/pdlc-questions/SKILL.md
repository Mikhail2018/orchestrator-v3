---
name: pdlc-questions
description: Show and manage open questions across all artifacts. Use when PM mentions "show questions", "open questions", "pending questions", "покажи вопросы", "открытые вопросы".
---

Показывает все открытые вопросы (OQ-*, Q-*) из PRD, SPEC, FEAT и DESIGN артефактов. Позволяет отслеживать и закрывать вопросы.

## Использование

```
/pdlc:questions                 # Все открытые вопросы
/pdlc:questions PRD-001         # Вопросы конкретного артефакта
/pdlc:questions close OQ-01     # Закрыть вопрос (обновить статус в файле)
```

## Алгоритм

### Просмотр вопросов

1. Запустить скрипт диагностики:

```bash
python3 ${PDLC_PLUGIN_ROOT:-$HOME/.gigacode/extensions/pdlc}/scripts/pdlc_doctor.py {project_root} --questions --format=json
```

2. Распарсить JSON.
3. Если указан конкретный артефакт — отфильтровать.
4. Вывести в box-формате.

### Закрытие вопроса (`close`)

1. Запустить скрипт с `--format=json`, найти вопрос по ID.
2. Открыть исходный файл артефакта.
3. Найти строку таблицы с данным ID.
4. Заменить статус на `closed` (или `Закрыт` если статусы на русском).
5. Сохранить файл.
6. Показать обновлённый список.

## Формат вывода

```
═══════════════════════════════════════════
OPEN QUESTIONS
═══════════════════════════════════════════

PRD-001 (PRD)
──────────────────────────────────────────
  OQ-01    open     J. Smith             2026-04-20
           Точный механизм подписки: pub/sub или polling?
  OQ-03    open     A. Johnson           2026-04-25
           Какие данные подпадают под 152-ФЗ?

SPEC-001 (SPEC)
──────────────────────────────────────────
  Q-001    open     Архитектор           2026-04-15
           Оптимальный формат хранения: JSON vs Protobuf?

══════════════════════════════════════════
Total: 5 questions, 3 open
══════════════════════════════════════════
```

### Integration Status (дополнительный блок)

Если в проекте есть SPEC с non-empty `external_systems`, после основного списка
вопросов добавь агрегированный блок:

```
──────────────────────────────────────────
INTEGRATION STATUS
──────────────────────────────────────────
External Systems: N total
  ✓ With contract: K
  ✗ Without contract: M
  ? Missing SLA/timeout in §7.0: L

Recommendation:
  → Закройте OQ/Q по контрактам перед /pdlc:tasks
──────────────────────────────────────────
```

Чтобы получить эту информацию:
1. Прочитай SPEC файлы с non-empty `external_systems`
2. Для каждой external_system проверь:
   - `contract_ref` указан и файл существует → "With contract"
   - `contract_ref` пуст или файл не найден → "Without contract"
3. Проверь §7.0 Integration Matrix: если timeout или NFR ref пусты → "Missing SLA/timeout"

## Откуда берутся вопросы

Скрипт сканирует markdown-таблицы в артефактах и извлекает строки с ID-паттерном `Q-NNN` или `OQ-NNN`.

| Артефакт | Директория | ID-паттерн | Формат таблицы |
|---|---|---|---|
| PRD | `docs/prd/` | OQ-NN | ID, Вопрос, Ответственный, Срок, Статус |
| SPEC | `docs/specs/` | Q-NNN | ID, Question, Owner, Due, Status |
| FEAT | `backlog/features/` | OQ-NN | ID, Вопрос, Ответственный, Срок, Статус |
| DESIGN | `docs/architecture/DESIGN-*/` | Q-NNN | ID, Question, Owner, Due, Status |

### Integration Questions

Помимо явных OQ/Q из таблиц, `/pdlc:questions` проактивно проверяет:
- SPEC с `external_systems` → есть ли §7.0 Integration Matrix?
- Каждая запись `external_systems` → есть ли `contract_ref`?
- §7.0 → каждая строка имеет timeout и NFR ref?

Эти проверки НЕ создают новые вопросы, а подсвечивают пробелы в блоке Integration Status.

## Статусы вопросов

| Статус | Значение |
|---|---|
| `open` / `Открыт` | Вопрос ожидает ответа |
| `in_progress` / `В работе` | Ответственный работает над ответом |
| `waiting_pm` | Ожидает решения PM |
| `blocked` | Заблокирован внешней зависимостью |
| `closed` / `Закрыт` / `resolved` / `Решён` | Вопрос закрыт |

## Важно

- **Источник правды — артефакты.** Вопросы живут в исходных файлах (PRD, SPEC и т.д.), не в отдельной базе
- Чтобы закрыть вопрос — обновляется статус в исходном файле
- Связано с `/pdlc:doctor` (использует тот же скрипт)
- SPEC со статусом `waiting_pm` не может быть принят пока есть открытые вопросы