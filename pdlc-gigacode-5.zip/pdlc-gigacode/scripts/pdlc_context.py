#!/usr/bin/env python3
"""Polisade Orchestrator — Sliced Context Builder.

Pure-read helper that assembles minimal, relevant context for subagent
prompts. Replaces ad-hoc {full SPEC} / {full PRD} / {full knowledge}
substitutions in skill prompt templates with slice-by-slice extraction
based on TASK frontmatter.

Output: JSON on stdout. Warnings/diagnostics: stderr.
Exit codes:
  0 — success (always, even on missing data — fail-soft via warnings[])
  2 — fatal: arguments invalid, project root missing core files

Usage:
  pdlc_context.py for-task          TASK-XXX [--project-root PATH]
  pdlc_context.py for-tasks-source  SOURCE-ID [--project-root PATH]
  pdlc_context.py for-review-pr     [--task TASK-XXX | --pr-num N] [--project-root PATH]
  pdlc_context.py for-review        TASK-XXX [--project-root PATH]

Common options:
  --max-glossary-terms N    cap glossary size (default 30)
  --include-section NAME    force-include section (debug)

Contract version: 1.0
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

CONTEXT_VERSION = "1.0"


# ---------------------------------------------------------------------------
# Utility: frontmatter parsing (no PyYAML — only stdlib).
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---\n(.*)$", re.DOTALL)


def parse_frontmatter(text: str) -> tuple[dict, str]:
    """Parse YAML-ish frontmatter without PyYAML.

    Supports the subset Polisade uses: scalars (strings, ints, bools),
    inline lists `[a, b, c]`, multi-line lists with `- item`, and nested
    mappings (one level: `external_systems:\\n  - name: ...`).

    For anything more complex, return raw string under that key — caller
    can re-parse if needed.
    """
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}, text
    raw, body = m.group(1), m.group(2)

    fm: dict[str, Any] = {}
    lines = raw.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.lstrip().startswith("#"):
            i += 1
            continue
        # Key-value at top level (no leading indent)
        m_kv = re.match(r"^([A-Za-z_][A-Za-z0-9_]*):\s*(.*)$", line)
        if m_kv:
            key, value = m_kv.group(1), m_kv.group(2).strip()
            if value == "":
                # Either nested mapping or multi-line list — peek next
                next_i = i + 1
                collected_list: list[Any] = []
                collected_dict_seq: list[dict] = []
                while next_i < len(lines):
                    nl = lines[next_i]
                    if not nl.startswith(" ") and not nl.startswith("\t"):
                        break
                    stripped = nl.strip()
                    if stripped.startswith("- "):
                        item = stripped[2:].strip()
                        # nested key-value: "- name: foo"
                        kv = re.match(r"^([A-Za-z_][A-Za-z0-9_]*):\s*(.*)$", item)
                        if kv:
                            cur = {kv.group(1): _coerce_scalar(kv.group(2).strip())}
                            # Continuation lines indented deeper
                            j = next_i + 1
                            while j < len(lines):
                                cl = lines[j]
                                if cl.startswith("    "):
                                    cs = cl.strip()
                                    ckv = re.match(r"^([A-Za-z_][A-Za-z0-9_]*):\s*(.*)$", cs)
                                    if ckv:
                                        cur[ckv.group(1)] = _coerce_scalar(ckv.group(2).strip())
                                    j += 1
                                else:
                                    break
                            collected_dict_seq.append(cur)
                            next_i = j
                        else:
                            collected_list.append(_coerce_scalar(item))
                            next_i += 1
                    else:
                        next_i += 1
                if collected_dict_seq:
                    fm[key] = collected_dict_seq
                elif collected_list:
                    fm[key] = collected_list
                else:
                    fm[key] = ""
                i = next_i
                continue
            fm[key] = _coerce_scalar(value)
            i += 1
            continue
        i += 1

    return fm, body


def _coerce_scalar(v: str) -> Any:
    """Coerce a YAML-ish scalar string to Python value."""
    if v == "":
        return ""
    # Quoted string
    if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
        return v[1:-1]
    # Inline list [a, b, c]
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        if not inner:
            return []
        return [_coerce_scalar(x.strip()) for x in inner.split(",")]
    # Boolean
    if v.lower() in ("true", "false"):
        return v.lower() == "true"
    # Null
    if v.lower() in ("null", "~"):
        return None
    # Integer
    if v.lstrip("-").isdigit():
        return int(v)
    # Bare string
    return v


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------


def load_state(root: Path) -> dict:
    p = root / ".state/PROJECT_STATE.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError:
        return {}


def load_knowledge(root: Path) -> dict:
    p = root / ".state/knowledge.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError:
        return {}


# Locations where each artifact type lives.
ARTIFACT_DIRS = {
    "TASK":   ["tasks"],
    "FEAT":   ["backlog/features"],
    "BUG":    ["backlog/bugs"],
    "DEBT":   ["backlog/tech-debt"],
    "CHORE":  ["backlog/chores"],
    "SPIKE":  ["backlog/spikes"],
    "SPEC":   ["docs/specs"],
    "PRD":    ["docs/prd"],
    "PLAN":   ["docs/plans"],
}


def find_artifact_file(root: Path, artifact_id: str) -> Path | None:
    """Locate the markdown file for a given artifact id (e.g. SPEC-002)."""
    if "-" not in artifact_id:
        return None
    typ = artifact_id.split("-", 1)[0]
    dirs = ARTIFACT_DIRS.get(typ, [])
    for d in dirs:
        for p in (root / d).glob(f"{artifact_id}-*.md"):
            return p
    return None


def load_artifact(root: Path, artifact_id: str) -> tuple[dict, str, Path | None]:
    """Return (frontmatter, body, file_path) for the given artifact.

    On miss: ({}, "", None).
    """
    p = find_artifact_file(root, artifact_id)
    if not p or not p.exists():
        return {}, "", None
    fm, body = parse_frontmatter(p.read_text())
    return fm, body, p


# ---------------------------------------------------------------------------
# Section extraction (markdown ## / ### headers + anchors)
# ---------------------------------------------------------------------------


def first_paragraph(body: str) -> str:
    """Return the first non-heading paragraph from a markdown body."""
    paragraphs = [p.strip() for p in body.split("\n\n") if p.strip()]
    for p in paragraphs:
        if p.startswith("#"):
            continue
        return p
    return ""


def extract_section(body: str, heading_text: str) -> str:
    """Extract a markdown section by heading text (case-insensitive prefix match).

    Returns content from heading line up to (but not including) the next heading
    of equal-or-higher level. Empty string if not found.
    """
    lines = body.splitlines()
    target = heading_text.lower().strip()
    start = None
    start_level = None
    for i, line in enumerate(lines):
        m = re.match(r"^(#+)\s+(.+)$", line)
        if m:
            level = len(m.group(1))
            text = m.group(2).strip().lower()
            if start is None and (text == target or text.startswith(target)):
                start = i
                start_level = level
                continue
            if start is not None and level <= start_level:
                return "\n".join(lines[start:i]).strip()
    if start is not None:
        return "\n".join(lines[start:]).strip()
    return ""


def extract_anchor(file_text: str, anchor: str) -> str:
    """Extract the section under a markdown anchor.

    Anchor convention here matches Polisade design_refs format:
    `DESIGN-NNN/file.md#anchor` where `anchor` is the heading slug.
    We accept both raw heading text and dash-separated slug.
    """
    # Normalize: try both "POST /reports/export" and "POST-/reports/export"
    candidates = [anchor, anchor.replace("-", " "), anchor.replace(" ", "-")]
    for cand in candidates:
        section = extract_section(file_text, cand)
        if section:
            return section
    return ""


# ---------------------------------------------------------------------------
# Requirement resolution
# ---------------------------------------------------------------------------


def parse_composite_req(req_id: str, default_doc: str | None) -> tuple[str, str]:
    """Split a requirement id into (doc_id, fr_id).

    Supports composite `SPEC-002.FR-001` and bare `FR-001` (uses default_doc).
    """
    if "." in req_id:
        doc, fr = req_id.split(".", 1)
        return doc, fr
    return default_doc or "", req_id


def extract_requirement(spec_body: str, fr_id: str) -> dict:
    """Extract a single FR/NFR section from SPEC body.

    Looks for `### FR-XXX:` or `### FR-XXX —` style headings.
    Returns {title, ears_statement, gherkin_scenarios, raw_body}.
    """
    # Find heading "### FR-XXX" or "### NFR-XXX"
    pattern = rf"^###\s+{re.escape(fr_id)}\b.*$"
    lines = spec_body.splitlines()
    start = None
    for i, line in enumerate(lines):
        if re.match(pattern, line):
            start = i
            break
    if start is None:
        return {"id": fr_id, "title": "", "ears_statement": "", "gherkin_scenarios": [], "raw_body": ""}

    # Find next heading of equal or higher level (### or ##)
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if re.match(r"^#{1,3}\s+", lines[j]):
            end = j
            break

    section = "\n".join(lines[start:end]).strip()
    title_match = re.match(rf"^###\s+{re.escape(fr_id)}\s*[:—-]?\s*(.+)$", lines[start])
    title = title_match.group(1).strip() if title_match else ""

    # EARS statement: line after **EARS:** marker
    ears_match = re.search(r"\*\*EARS:?\*\*\s*(.+?)(?=\n\n|\n\*\*|\Z)", section, re.DOTALL)
    ears = ears_match.group(1).strip() if ears_match else ""

    # Gherkin scenarios: bullet lines starting with "Given ... When ... Then ..."
    gherkin = []
    for line in section.splitlines():
        if re.match(r"^\s*[-*]\s+Given\b", line, re.IGNORECASE):
            gherkin.append(line.lstrip("- *").strip())

    return {
        "id": fr_id,
        "title": title,
        "ears_statement": ears,
        "gherkin_scenarios": gherkin,
        "raw_body": section,
    }


# ---------------------------------------------------------------------------
# Glossary slicing
# ---------------------------------------------------------------------------


def slice_glossary(
    glossary: list[dict],
    relevance_text: str,
    max_terms: int,
    warnings: list[str],
) -> list[dict]:
    """Filter glossary terms to those mentioned in relevance_text.

    Falls back to first `max_terms` if no matches (better than empty).
    """
    if not glossary:
        return []
    text_lower = relevance_text.lower()
    relevant = []
    for entry in glossary:
        term = entry.get("term", "")
        if term and term.lower() in text_lower:
            relevant.append(entry)
    if not relevant:
        # Fall back to all terms — but cap.
        if len(glossary) > max_terms:
            warnings.append(
                f"No glossary terms matched task content; including first {max_terms} of {len(glossary)} as fallback"
            )
            return glossary[:max_terms]
        return glossary
    if len(relevant) > max_terms:
        warnings.append(
            f"Glossary has {len(relevant)} matched terms; trimmed to top {max_terms} by source order"
        )
        return relevant[:max_terms]
    return relevant


# ---------------------------------------------------------------------------
# SPEC slicing helpers
# ---------------------------------------------------------------------------


def extract_constraints_assumptions(spec_body: str) -> dict:
    """Extract §4 Assumptions / Constraints / Dependencies as bullet lists."""
    sec = extract_section(spec_body, "4. Constraints, Assumptions, Dependencies")
    if not sec:
        sec = extract_section(spec_body, "4. ")
    if not sec:
        return {"constraints": [], "assumptions": [], "dependencies": [], "raw": ""}

    def bullets_under(section_text: str, subheading: str) -> list[str]:
        # Find subheading (### 4.1 Assumptions etc.)
        m = re.search(rf"###\s+\d+\.\d+\s+{re.escape(subheading)}", section_text, re.IGNORECASE)
        if not m:
            return []
        start = m.end()
        # End at next ### or ##
        end_m = re.search(r"\n#{2,3}\s+", section_text[start:])
        end = start + end_m.start() if end_m else len(section_text)
        chunk = section_text[start:end]
        return [
            line.strip().lstrip("-* ").strip()
            for line in chunk.splitlines()
            if line.strip().startswith(("-", "*"))
        ]

    return {
        "assumptions": bullets_under(sec, "Assumptions"),
        "constraints": bullets_under(sec, "Constraints"),
        "dependencies": bullets_under(sec, "Dependencies"),
        "raw": sec,
    }


def extract_out_of_scope(spec_body: str) -> list[str]:
    """Extract Out of scope bullets from §1 Purpose & Scope."""
    sec = extract_section(spec_body, "1. Purpose & Scope")
    if not sec:
        sec = extract_section(spec_body, "1. ")
    if not sec:
        return []
    # Find "Out of scope" line and collect following bullets
    lines = sec.splitlines()
    in_oos = False
    items = []
    for line in lines:
        if "out of scope" in line.lower():
            in_oos = True
            continue
        if in_oos:
            stripped = line.strip()
            if stripped.startswith(("-", "*")):
                items.append(stripped.lstrip("-* ").strip())
            elif stripped == "":
                if items:
                    break
            elif re.match(r"^#+\s+", stripped):
                break
    return items


# ---------------------------------------------------------------------------
# Parent chain resolution
# ---------------------------------------------------------------------------


def resolve_parent_chain(root: Path, start_id: str, warnings: list[str]) -> list[dict]:
    """Walk parent chain upward from start_id. Stop at root or 6 hops."""
    chain = []
    current = start_id
    seen = set()
    for _ in range(6):
        if not current or current in seen:
            break
        seen.add(current)
        fm, body, path = load_artifact(root, current)
        if not fm:
            break
        chain.append({
            "id": current,
            "type": current.split("-", 1)[0],
            "path": str(path.relative_to(root)) if path else None,
            "title": fm.get("title", ""),
            "intent": first_paragraph(body)[:500],
        })
        current = fm.get("parent")
        if not current:
            break
    if len(chain) == 6:
        warnings.append("Parent chain truncated at 6 levels (likely cycle or deep nesting)")
    return chain


def find_spec_in_chain(chain: list[dict]) -> str | None:
    for entry in chain:
        if entry["type"] == "SPEC":
            return entry["id"]
    return None


# ---------------------------------------------------------------------------
# Knowledge slicing
# ---------------------------------------------------------------------------


def slice_knowledge(knowledge: dict, relevance_text: str, max_glossary: int, warnings: list[str]) -> dict:
    """Select relevant subset of knowledge.json for a subagent prompt."""
    return {
        "patterns": knowledge.get("patterns", []),
        "anti_patterns": knowledge.get("antiPatterns", []),
        "decisions": knowledge.get("decisions", []),
        "glossary": slice_glossary(
            knowledge.get("glossary", []),
            relevance_text,
            max_glossary,
            warnings,
        ),
        "key_files": knowledge.get("projectContext", {}).get("keyFiles", []),
        "tech_stack": knowledge.get("projectContext", {}).get("techStack", []),
        "testing": {
            "strategy":           knowledge.get("testing", {}).get("strategy"),
            "test_command":       knowledge.get("testing", {}).get("testCommand"),
            "type_check_command": knowledge.get("testing", {}).get("typeCheckCommand"),
            "lint_command":       knowledge.get("testing", {}).get("lintCommand"),
            "known_flaky_tests":  knowledge.get("testing", {}).get("knownFlakyTests", []),
            "authoring_mode":     knowledge.get("testing", {}).get("authoringMode", "unified"),
        },
        "decomposition": {
            "mode": knowledge.get("decomposition", {}).get("mode", "legacy"),
        },
    }


# ---------------------------------------------------------------------------
# Modes
# ---------------------------------------------------------------------------


@dataclass
class ContextResult:
    mode: str
    payload: dict = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

    def to_json(self) -> str:
        out = {"context_version": CONTEXT_VERSION, "mode": self.mode}
        out.update(self.payload)
        out["warnings"] = self.warnings
        return json.dumps(out, indent=2, ensure_ascii=False)


def build_for_task(root: Path, task_id: str, args) -> ContextResult:
    """Slice context for /pdlc:implement subagent."""
    warnings: list[str] = []

    fm, body, task_path = load_artifact(root, task_id)
    if not task_path:
        return ContextResult(
            mode="for-task",
            payload={"error": f"TASK file not found for {task_id}"},
            warnings=warnings,
        )

    parent = fm.get("parent")
    parent_chain = resolve_parent_chain(root, parent, warnings) if parent else []
    spec_id = find_spec_in_chain(parent_chain)

    # Resolve requirements through SPEC body (if any)
    requirements = fm.get("requirements", []) or []

    # Fallback: if parent chain has no SPEC but requirements use composite
    # SPEC-XXX.FR-NNN ids, infer spec_id from the first such id. This is
    # the common case: TASK from FEAT, where SPEC is a sibling-of-FEAT
    # under common PRD, not an ancestor.
    if not spec_id and requirements:
        for req_id in requirements:
            if "." in req_id:
                doc = req_id.split(".", 1)[0]
                if doc.startswith("SPEC-"):
                    spec_id = doc
                    warnings.append(
                        f"SPEC not in parent chain; inferred {spec_id} from composite requirement {req_id}"
                    )
                    break

    requirements_resolved = []
    if spec_id:
        spec_fm, spec_body, _ = load_artifact(root, spec_id)
        for req_id in requirements:
            doc, fr = parse_composite_req(req_id, spec_id)
            if doc != spec_id:
                # Cross-doc reference — try loading that doc
                _, other_body, _ = load_artifact(root, doc)
                req_data = extract_requirement(other_body, fr)
            else:
                req_data = extract_requirement(spec_body, fr)
            req_data["composite_id"] = req_id
            req_data["doc"] = doc
            requirements_resolved.append(req_data)
    elif requirements:
        warnings.append(
            f"TASK has {len(requirements)} requirements but no SPEC found in parent chain — cannot resolve"
        )

    # Design excerpts
    design_excerpts = []
    for ref in fm.get("design_refs", []) or []:
        if "/" not in ref:
            warnings.append(f"design_ref {ref!r} has no '/' separator; skipped")
            continue
        package_id, rest = ref.split("/", 1)
        if "#" in rest:
            file_part, anchor = rest.split("#", 1)
        else:
            file_part, anchor = rest, ""
        design_file = root / "docs/architecture" / package_id / file_part
        if not design_file.exists():
            warnings.append(f"design_ref file not found: {design_file.relative_to(root)}")
            continue
        file_text = design_file.read_text()
        if anchor:
            content = extract_anchor(file_text, anchor)
            if not content:
                warnings.append(f"anchor {anchor!r} not found in {design_file.name}; including full file")
                content = file_text
        else:
            content = file_text
        design_excerpts.append({
            "ref": ref,
            "file": str(design_file.relative_to(root)),
            "anchor": anchor or None,
            "content": content,
        })

    # Constraints + assumptions + system_boundary from SPEC
    constraints_block = None
    system_boundary = None
    out_of_scope: list[str] = []
    if spec_id:
        spec_fm, spec_body, _ = load_artifact(root, spec_id)
        ca = extract_constraints_assumptions(spec_body)
        if ca["constraints"] or ca["assumptions"] or ca["dependencies"]:
            constraints_block = {
                "constraints": ca["constraints"],
                "assumptions": ca["assumptions"],
                "dependencies": ca["dependencies"],
                "source": f"{spec_id}.§4",
            }
        out_of_scope = extract_out_of_scope(spec_body)
        if spec_fm.get("system_boundary"):
            system_boundary = {
                "boundary": spec_fm.get("system_boundary"),
                "external_systems": spec_fm.get("external_systems", []) or [],
            }

    # Knowledge — relevance text = TASK body + requirement bodies + design excerpts
    relevance_text = body
    for r in requirements_resolved:
        relevance_text += "\n" + r.get("raw_body", "")
    for d in design_excerpts:
        relevance_text += "\n" + d.get("content", "")

    knowledge = load_knowledge(root)
    knowledge_subset = slice_knowledge(
        knowledge, relevance_text, args.max_glossary_terms, warnings
    )

    return ContextResult(
        mode="for-task",
        payload={
            "task": {
                "id": fm.get("id", task_id),
                "title": fm.get("title", ""),
                "status": fm.get("status"),
                "parent": parent,
                "priority": fm.get("priority"),
                "depends_on": fm.get("depends_on", []) or [],
                "requirements": requirements,
                "design_refs": fm.get("design_refs", []) or [],
                "design_waiver": fm.get("design_waiver", False),
                "body_path": str(task_path.relative_to(root)),
                "body": body,
            },
            "parent_chain": parent_chain,
            "spec_id": spec_id,
            "requirements_resolved": requirements_resolved,
            "design_excerpts": design_excerpts,
            "constraints_and_assumptions": constraints_block,
            "out_of_scope": out_of_scope,
            "system_boundary": system_boundary,
            "knowledge": knowledge_subset,
        },
        warnings=warnings,
    )


def build_for_tasks_source(root: Path, source_id: str, args) -> ContextResult:
    """Slice context for /pdlc:tasks subagent (decomposition).

    Unlike for-task: TASK doesn't exist yet, so we include the FULL source
    body (it's needed for decomposition) plus the SPEC body if there's one
    in the chain — but knowledge is sliced by relevance.
    """
    warnings: list[str] = []

    fm, body, source_path = load_artifact(root, source_id)
    if not source_path:
        return ContextResult(
            mode="for-tasks-source",
            payload={"error": f"Source file not found for {source_id}"},
            warnings=warnings,
        )

    parent = fm.get("parent")
    parent_chain = resolve_parent_chain(root, parent, warnings) if parent else []
    spec_id = find_spec_in_chain(parent_chain) if source_id.startswith(("PLAN-", "FEAT-")) else (
        source_id if source_id.startswith("SPEC-") else None
    )

    spec_excerpts = None
    constraints_block = None
    system_boundary = None
    out_of_scope: list[str] = []
    if spec_id:
        spec_fm, spec_body, _ = load_artifact(root, spec_id)
        # All FR/NFR ids from SPEC §5 and §6
        fr_ids = re.findall(r"^###\s+((?:FR|NFR)-\d+)", spec_body, re.MULTILINE)
        spec_excerpts = {
            "id": spec_id,
            "fr_nfr_ids": fr_ids,
            "body": spec_body,
        }
        ca = extract_constraints_assumptions(spec_body)
        if ca["constraints"] or ca["assumptions"] or ca["dependencies"]:
            constraints_block = {
                "constraints": ca["constraints"],
                "assumptions": ca["assumptions"],
                "dependencies": ca["dependencies"],
                "source": f"{spec_id}.§4",
            }
        out_of_scope = extract_out_of_scope(spec_body)
        if spec_fm.get("system_boundary"):
            system_boundary = {
                "boundary": spec_fm.get("system_boundary"),
                "external_systems": spec_fm.get("external_systems", []) or [],
            }

    # Optional: design package if SPEC has one
    design_package = None
    if spec_id:
        # Scan docs/architecture for manifest.yaml with parent: spec_id
        for manifest in (root / "docs/architecture").glob("*/manifest.yaml"):
            text = manifest.read_text()
            if f"parent: {spec_id}" in text:
                pkg_id = manifest.parent.name
                readme = manifest.parent / "README.md"
                api = manifest.parent / "api.md"
                design_package = {
                    "id": pkg_id,
                    "manifest": text,
                    "readme": readme.read_text() if readme.exists() else None,
                    "api_contract": api.read_text() if api.exists() else None,
                }
                break

    knowledge = load_knowledge(root)
    knowledge_subset = slice_knowledge(
        knowledge, body, args.max_glossary_terms, warnings
    )

    # Counters for next_task_id hint (read-only; final write goes through skill)
    counters_path = root / ".state/counters.json"
    next_task_hint = None
    if counters_path.exists():
        try:
            counters = json.loads(counters_path.read_text())
            next_task_hint = (counters.get("TASK", 0) or 0) + 1
        except json.JSONDecodeError:
            pass

    return ContextResult(
        mode="for-tasks-source",
        payload={
            "source": {
                "id": fm.get("id", source_id),
                "type": source_id.split("-", 1)[0],
                "title": fm.get("title", ""),
                "status": fm.get("status"),
                "parent": parent,
                "body_path": str(source_path.relative_to(root)),
                "body": body,
            },
            "parent_chain": parent_chain,
            "spec_id": spec_id,
            "spec_excerpts": spec_excerpts,
            "constraints_and_assumptions": constraints_block,
            "out_of_scope": out_of_scope,
            "system_boundary": system_boundary,
            "design_package": design_package,
            "knowledge": knowledge_subset,
            "next_task_id_hint": next_task_hint,
        },
        warnings=warnings,
    )


def build_for_review_pr(root: Path, task_id: str | None, pr_num: int | None, args) -> ContextResult:
    """Slice context for /pdlc:review-pr subagent.

    Same as for-task but:
      - includes review_focus block (patterns/anti_patterns/glossary as
        explicit checklist material — review-pr currently doesn't see them)
    """
    warnings: list[str] = []

    if not task_id:
        warnings.append("for-review-pr called without --task; review_focus context is minimal")
        return ContextResult(
            mode="for-review-pr",
            payload={"pr_num": pr_num},
            warnings=warnings,
        )

    base = build_for_task(root, task_id, args)
    if "error" in base.payload:
        return ContextResult(mode="for-review-pr", payload=base.payload, warnings=base.warnings)

    knowledge = base.payload.get("knowledge", {})
    review_focus = {
        "patterns_to_check": knowledge.get("patterns", []),
        "anti_patterns_to_flag": knowledge.get("anti_patterns", []),
        "glossary_terms": knowledge.get("glossary", []),
        "decisions_to_respect": knowledge.get("decisions", []),
    }

    payload = dict(base.payload)
    payload["mode"] = "for-review-pr"  # in case caller dispatches by mode in payload
    payload["pr_num"] = pr_num
    payload["review_focus"] = review_focus

    return ContextResult(
        mode="for-review-pr",
        payload=payload,
        warnings=base.warnings + warnings,
    )


def build_for_review(root: Path, task_id: str, args) -> ContextResult:
    """Slice minimal context for /pdlc:review (advisory).

    Drops design_excerpts, knowledge except glossary — this is a TASK
    quality-of-prompt review, not a code review.
    """
    warnings: list[str] = []
    base = build_for_task(root, task_id, args)
    if "error" in base.payload:
        return ContextResult(mode="for-review", payload=base.payload, warnings=base.warnings)

    payload = {
        "task": base.payload["task"],
        "parent_chain": base.payload["parent_chain"],
        "spec_id": base.payload["spec_id"],
        "requirements_resolved": base.payload["requirements_resolved"],
        "out_of_scope": base.payload.get("out_of_scope", []),
        "constraints_and_assumptions": base.payload.get("constraints_and_assumptions"),
        "glossary": base.payload.get("knowledge", {}).get("glossary", []),
    }
    return ContextResult(mode="for-review", payload=payload, warnings=base.warnings)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pdlc_context.py",
        description="Slice minimal context for Polisade subagent prompts.",
    )
    p.add_argument("--project-root", default=".", help="Project root (default: cwd)")
    p.add_argument("--max-glossary-terms", type=int, default=30, help="Cap on glossary terms in output")
    p.add_argument("--output", default=None, help=(
        "Write JSON to this file instead of stdout. Convention for skills: "
        "'.pdlc/cache/json_outputs/context-<mode>-<id>.json' "
        "(directory auto-created, gitignored). When --output is used, stdout "
        "prints only the resolved file path so the skill can pass it to the "
        "subagent prompt."
    ))
    sub = p.add_subparsers(dest="mode", required=True)

    s1 = sub.add_parser("for-task", help="Context for /pdlc:implement")
    s1.add_argument("task_id")

    s2 = sub.add_parser("for-tasks-source", help="Context for /pdlc:tasks")
    s2.add_argument("source_id")

    s3 = sub.add_parser("for-review-pr", help="Context for /pdlc:review-pr")
    s3.add_argument("--task", dest="task_id", default=None)
    s3.add_argument("--pr-num", type=int, default=None)

    s4 = sub.add_parser("for-review", help="Context for /pdlc:review")
    s4.add_argument("task_id")

    return p


def main(argv: list[str] | None = None) -> int:
    parser = make_parser()
    args = parser.parse_args(argv)
    root = Path(args.project_root).resolve()

    if not root.exists():
        print(f"error: project root does not exist: {root}", file=sys.stderr)
        return 2

    if args.mode == "for-task":
        result = build_for_task(root, args.task_id, args)
    elif args.mode == "for-tasks-source":
        result = build_for_tasks_source(root, args.source_id, args)
    elif args.mode == "for-review-pr":
        result = build_for_review_pr(root, args.task_id, args.pr_num, args)
    elif args.mode == "for-review":
        result = build_for_review(root, args.task_id, args)
    else:
        parser.error(f"unknown mode: {args.mode}")
        return 2

    json_text = result.to_json()

    if args.output:
        out_path = Path(args.output)
        if not out_path.is_absolute():
            out_path = root / out_path
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json_text)
        # stdout prints the resolved path so the skill can pass it on
        print(str(out_path))
    else:
        print(json_text)

    if result.warnings:
        for w in result.warnings:
            print(f"warn: {w}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
