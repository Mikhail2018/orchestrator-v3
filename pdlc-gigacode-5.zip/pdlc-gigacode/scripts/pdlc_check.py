#!/usr/bin/env python3
"""Polisade Orchestrator — Deterministic pre-commit checks.

Replaces the ritual self-review checklist (where subagent ticks ✓ without
actually checking) with verifiable checks that run on the staged diff.

Checks performed:
  1. Hardcoded secrets — regex over diff (sk-*, ghp_*, password=, ...)
  2. Anti-patterns — for each antiPattern in knowledge.json that has a
     `regex` or `code_pattern` field, search in added lines of diff.
  3. AC coverage — heuristic: for each AC in TASK body, check that at least
     one file mentioned in TASK 'Files to Change' section is touched in diff.
  4. TDD ordering — if knowledge.testing.strategy == "tdd-first", verify
     that the current branch has a commit `[TASK-XXX] Add failing tests`
     BEFORE `[TASK-XXX] Implement` (or that diff contains test files).

CLI:
  pdlc_check.py pre-commit TASK-XXX [--project-root PATH]
                                    [--diff-base BRANCH]
                                    [--worktree PATH]
                                    [--output PATH]

Output JSON: {
  "task_id": "...",
  "checks": [
    {"name": "hardcoded_secrets", "passed": bool, "findings": [...]},
    {"name": "anti_patterns",     "passed": bool, "findings": [...]},
    {"name": "ac_coverage",       "passed": bool, "findings": [...]},
    {"name": "tdd_ordering",      "passed": bool, "findings": [...]}
  ],
  "passed": bool,
  "summary": "X/Y checks passed"
}

Exit codes:
  0 — all checks passed
  1 — at least one check failed
  2 — fatal: invalid arguments, missing TASK, etc.

Pure-read; never modifies repo state.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

CHECK_VERSION = "1.0"


# ---------------------------------------------------------------------------
# Helpers (frontmatter, knowledge load, diff)
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---\n(.*)$", re.DOTALL)


def parse_frontmatter(text: str) -> tuple[dict, str]:
    """Minimal YAML-ish frontmatter parser (same approach as pdlc_context.py)."""
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}, text
    raw, body = m.group(1), m.group(2)
    fm: dict[str, Any] = {}
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        kv = re.match(r"^([A-Za-z_][A-Za-z0-9_]*):\s*(.*)$", line)
        if kv:
            key, value = kv.group(1), kv.group(2).strip()
            if value.startswith("[") and value.endswith("]"):
                inner = value[1:-1].strip()
                fm[key] = [x.strip() for x in inner.split(",")] if inner else []
            elif value in ("true", "false"):
                fm[key] = value == "true"
            elif value in ("", "null", "~"):
                fm[key] = None
            else:
                fm[key] = value.strip('"').strip("'")
    return fm, body


def find_task_file(root: Path, task_id: str) -> Path | None:
    for p in (root / "tasks").glob(f"{task_id}-*.md"):
        return p
    return None


def load_knowledge(root: Path) -> dict:
    p = root / ".state/knowledge.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError:
        return {}


def get_diff(workdir: Path, base: str | None) -> str:
    """Return staged + unstaged diff for the working tree.

    If `base` is provided, returns `git diff <base>...HEAD` plus working
    tree changes. Otherwise — `git diff HEAD` (everything not yet committed).
    """
    cwd = str(workdir)
    if base:
        try:
            committed = subprocess.run(
                ["git", "diff", f"{base}...HEAD"],
                cwd=cwd, capture_output=True, text=True, check=True
            ).stdout
        except subprocess.CalledProcessError:
            committed = ""
    else:
        committed = ""

    try:
        staged = subprocess.run(
            ["git", "diff", "--cached"],
            cwd=cwd, capture_output=True, text=True, check=True
        ).stdout
    except subprocess.CalledProcessError:
        staged = ""

    try:
        unstaged = subprocess.run(
            ["git", "diff"],
            cwd=cwd, capture_output=True, text=True, check=True
        ).stdout
    except subprocess.CalledProcessError:
        unstaged = ""

    return committed + "\n" + staged + "\n" + unstaged


def get_added_lines(diff: str) -> list[str]:
    """Extract only lines starting with '+' (additions), excluding diff metadata."""
    out = []
    for line in diff.splitlines():
        if line.startswith("+++"):
            continue
        if line.startswith("+"):
            out.append(line[1:])
    return out


def get_changed_files(diff: str) -> set[str]:
    """Extract file paths from `diff --git a/<path> b/<path>` lines."""
    files = set()
    for line in diff.splitlines():
        m = re.match(r"^diff --git a/(\S+) b/(\S+)$", line)
        if m:
            files.add(m.group(2))
    return files


# ---------------------------------------------------------------------------
# Check: hardcoded secrets
# ---------------------------------------------------------------------------

# Common secret patterns. Each entry: (label, regex, severity)
SECRET_PATTERNS = [
    ("OpenAI API key", re.compile(r"sk-[A-Za-z0-9]{20,}"), "critical"),
    ("GitHub PAT (classic)", re.compile(r"ghp_[A-Za-z0-9]{30,}"), "critical"),
    ("GitHub PAT (fine-grained)", re.compile(r"github_pat_[A-Za-z0-9_]{50,}"), "critical"),
    ("AWS access key id", re.compile(r"AKIA[0-9A-Z]{16}"), "critical"),
    ("AWS secret (heuristic)", re.compile(r"aws_secret_access_key\s*=\s*['\"][A-Za-z0-9/+=]{40}['\"]"), "critical"),
    ("Slack token", re.compile(r"xox[baprs]-[A-Za-z0-9-]{10,}"), "critical"),
    ("Generic password assignment",
     re.compile(r"(?i)(password|passwd|pwd)\s*[=:]\s*['\"](?!.*\$\{)(?!.*<placeholder>)(?!.*\.\.\.)[\S]{4,}['\"]"), "high"),
    ("Generic API key assignment",
     re.compile(r"(?i)(api[_-]?key|apikey|secret[_-]?key)\s*[=:]\s*['\"](?!\$\{)(?!<)(?!\.\.\.)[A-Za-z0-9_\-]{12,}['\"]"), "high"),
    ("JWT (heuristic)", re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"), "high"),
    ("Private key header", re.compile(r"-----BEGIN (RSA|OPENSSH|EC|DSA|PGP) PRIVATE KEY-----"), "critical"),
]


def check_hardcoded_secrets(added_lines: list[str]) -> dict:
    findings = []
    for line_idx, line in enumerate(added_lines):
        for label, pat, severity in SECRET_PATTERNS:
            m = pat.search(line)
            if m:
                # Skip lines that look like obvious placeholders/tests
                stripped = line.strip()
                if any(marker in stripped.lower() for marker in [
                    "example", "placeholder", "your-", "<your", "fake",
                    "dummy", "test_", "mock_", "// nosec", "# nosec",
                ]):
                    continue
                findings.append({
                    "label": label,
                    "severity": severity,
                    "match_excerpt": m.group(0)[:50],
                    "line_excerpt": stripped[:100],
                })
    return {
        "name": "hardcoded_secrets",
        "passed": len(findings) == 0,
        "findings": findings,
    }


# ---------------------------------------------------------------------------
# Check: anti-patterns from knowledge.json
# ---------------------------------------------------------------------------


def check_anti_patterns(added_lines: list[str], knowledge: dict) -> dict:
    """Search added lines for anti-patterns that have a `regex` or `code_pattern`.

    knowledge.antiPatterns is a list of {name, description, regex?, code_pattern?}.
    Patterns without machine-readable matchers are SKIPPED (cannot be checked
    deterministically — that's why we have human review for those).
    """
    findings = []
    skipped = 0
    anti_patterns = knowledge.get("antiPatterns", []) or []
    for ap in anti_patterns:
        name = ap.get("name", "<unnamed>")
        regex_str = ap.get("regex") or ap.get("code_pattern")
        if not regex_str:
            skipped += 1
            continue
        try:
            pat = re.compile(regex_str)
        except re.error as e:
            findings.append({
                "label": name,
                "error": f"invalid regex: {e}",
                "match_excerpt": "",
                "line_excerpt": "",
            })
            continue
        for line in added_lines:
            m = pat.search(line)
            if m:
                findings.append({
                    "label": name,
                    "match_excerpt": m.group(0)[:50],
                    "line_excerpt": line.strip()[:100],
                })
    return {
        "name": "anti_patterns",
        "passed": len(findings) == 0,
        "findings": findings,
        "skipped_no_regex": skipped,
    }


# ---------------------------------------------------------------------------
# Check: AC coverage (heuristic)
# ---------------------------------------------------------------------------

_AC_LINE_RE = re.compile(r"^[\s\-*]*\[\s*[xX ]?\s*\]\s*(AC[-\s]?\d+)[:\s—-]+(.+)$", re.MULTILINE)
_FILES_TO_CHANGE_HEADER_RE = re.compile(r"^##+\s+(?:Files to Change|Файлы для изменения|Затронутые файлы)\s*$", re.MULTILINE)


def extract_ac_list(task_body: str) -> list[dict]:
    """Find Acceptance Criteria items in TASK body. Returns list of {id, text}."""
    out = []
    # Locate "## Acceptance Criteria" or "## Acceptance" section
    headers = ["## Acceptance Criteria", "## Acceptance", "## Критерии приёмки", "## Acceptance criteria"]
    section_text = ""
    for header in headers:
        idx = task_body.find(header)
        if idx != -1:
            # Take from after header up to next "## "
            chunk = task_body[idx + len(header):]
            next_h = re.search(r"\n##\s+", chunk)
            section_text = chunk[:next_h.start()] if next_h else chunk
            break
    if not section_text:
        return out
    for m in _AC_LINE_RE.finditer(section_text):
        out.append({"id": m.group(1).strip(), "text": m.group(2).strip()[:200]})
    return out


def extract_files_to_change(task_body: str) -> list[str]:
    """Find files mentioned in 'Files to Change' section of TASK body."""
    m = _FILES_TO_CHANGE_HEADER_RE.search(task_body)
    if not m:
        return []
    chunk = task_body[m.end():]
    next_h = re.search(r"\n##\s+", chunk)
    section = chunk[:next_h.start()] if next_h else chunk
    files = []
    # Match lines like "- `path/to/file.ext` — comment" or "- path/to/file.ext"
    for line in section.splitlines():
        for fm in re.finditer(r"`([^`]+\.\w+)`|(?:^|\s)([./\w-]+\.\w+)(?:\s|$)", line):
            f = fm.group(1) or fm.group(2)
            if f and "/" in f or "." in f:
                files.append(f)
    return files


def check_ac_coverage(task_body: str, changed_files: set[str]) -> dict:
    """Heuristic: for each AC, check that at least one file from 'Files to
    Change' is in the diff. Best-effort — if no 'Files to Change' section
    exists in TASK, the check is marked as `skipped`.
    """
    acs = extract_ac_list(task_body)
    files_declared = extract_files_to_change(task_body)

    if not acs:
        return {
            "name": "ac_coverage",
            "passed": True,
            "findings": [],
            "note": "No AC found in TASK body — check skipped",
        }
    if not files_declared:
        return {
            "name": "ac_coverage",
            "passed": True,
            "findings": [],
            "note": "No 'Files to Change' section in TASK — coverage cannot be machine-checked",
            "ac_count": len(acs),
        }

    # For each declared file, was it changed?
    findings = []
    declared_normalized = {f.lstrip("./") for f in files_declared}
    changed_normalized = {f.lstrip("./") for f in changed_files}
    not_touched = declared_normalized - changed_normalized

    if not_touched:
        findings.append({
            "label": "Files declared in TASK but not touched in diff",
            "files": sorted(not_touched),
        })

    # If declared files are touched but ACs are not actually verifiable here —
    # at least confirm we touched what TASK said we'd touch.
    return {
        "name": "ac_coverage",
        "passed": len(findings) == 0,
        "findings": findings,
        "ac_count": len(acs),
        "files_declared": sorted(declared_normalized),
        "files_touched": sorted(declared_normalized & changed_normalized),
    }


# ---------------------------------------------------------------------------
# Checks: tasks-graph (DAG validation, requirement refs, ownership, phases)
# ---------------------------------------------------------------------------


def load_all_tasks(root: Path) -> dict[str, dict]:
    """Load all TASK frontmatters keyed by task_id. Body discarded."""
    tasks: dict[str, dict] = {}
    tasks_dir = root / "tasks"
    if not tasks_dir.is_dir():
        return tasks
    for p in tasks_dir.glob("TASK-*.md"):
        try:
            text = p.read_text()
        except OSError:
            continue
        fm, _ = parse_frontmatter(text)
        if "id" in fm:
            tasks[fm["id"]] = fm
        else:
            # Fallback: derive from filename
            stem_parts = p.stem.split("-", 2)
            if len(stem_parts) >= 2:
                derived_id = f"{stem_parts[0]}-{stem_parts[1]}"
                tasks[derived_id] = fm
    return tasks


def check_dag_no_cycles(tasks: dict[str, dict]) -> dict:
    """Detect cycles in TASK.depends_on graph via DFS-based topo sort."""
    if not tasks:
        return {"name": "dag_no_cycles", "passed": True, "findings": [],
                "note": "No tasks found"}

    # Build adjacency: t -> [its dependencies]
    adj: dict[str, list[str]] = {}
    for tid, fm in tasks.items():
        deps = fm.get("depends_on") or []
        if not isinstance(deps, list):
            deps = []
        adj[tid] = [d for d in deps if d]

    # Kahn-style: but to detect cycles we use white/gray/black DFS.
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {tid: WHITE for tid in adj}
    cycles: list[list[str]] = []
    stack: list[str] = []

    def visit(node: str) -> None:
        if color.get(node, WHITE) == GRAY:
            # Cycle detected — extract from stack
            try:
                idx = stack.index(node)
                cycles.append(stack[idx:] + [node])
            except ValueError:
                cycles.append([node])
            return
        if color.get(node, WHITE) == BLACK:
            return
        color[node] = GRAY
        stack.append(node)
        for nxt in adj.get(node, []):
            if nxt in adj:  # only walk into tasks we know about
                visit(nxt)
        stack.pop()
        color[node] = BLACK

    for tid in list(adj.keys()):
        if color[tid] == WHITE:
            visit(tid)

    findings = [{"label": "Cycle detected", "chain": " → ".join(c)} for c in cycles]
    return {
        "name": "dag_no_cycles",
        "passed": len(findings) == 0,
        "findings": findings,
        "tasks_checked": len(tasks),
    }


def check_deps_exist(tasks: dict[str, dict]) -> dict:
    """Every depends_on entry must point to a task we know about."""
    findings = []
    known = set(tasks.keys())
    for tid, fm in tasks.items():
        deps = fm.get("depends_on") or []
        if not isinstance(deps, list):
            continue
        for d in deps:
            if d and d not in known:
                findings.append({"label": "Missing dependency", "task": tid, "missing": d})
    return {
        "name": "deps_exist",
        "passed": len(findings) == 0,
        "findings": findings,
        "tasks_checked": len(tasks),
    }


def _load_spec_fr_nfr_ids(root: Path) -> dict[str, set[str]]:
    """Scan docs/specs/*.md and return {SPEC-XXX: {FR-001, NFR-002, ...}}."""
    out: dict[str, set[str]] = {}
    specs_dir = root / "docs" / "specs"
    if not specs_dir.is_dir():
        return out
    for sp in specs_dir.glob("SPEC-*.md"):
        try:
            text = sp.read_text()
        except OSError:
            continue
        # Extract SPEC-XXX from filename (SPEC-002-something.md → SPEC-002)
        parts = sp.stem.split("-", 2)
        if len(parts) >= 2:
            spec_id = f"{parts[0]}-{parts[1]}"
            ids = set(re.findall(r"^###\s+((?:FR|NFR)-\d+)", text, re.MULTILINE))
            out[spec_id] = ids
    return out


def check_requirements_exist(tasks: dict[str, dict], root: Path) -> dict:
    """Composite TASK.requirements (SPEC-XXX.FR-NNN) must reference real FRs."""
    spec_ids = _load_spec_fr_nfr_ids(root)
    findings = []
    for tid, fm in tasks.items():
        reqs = fm.get("requirements") or []
        if not isinstance(reqs, list):
            continue
        for req in reqs:
            if not isinstance(req, str) or "." not in req:
                continue  # Non-composite — can't validate, skip
            doc, fr = req.split(".", 1)
            if doc not in spec_ids:
                findings.append({
                    "label": "Requirement references unknown SPEC",
                    "task": tid, "ref": req, "missing": doc,
                })
            elif fr not in spec_ids[doc]:
                findings.append({
                    "label": "Requirement not found in SPEC",
                    "task": tid, "ref": req,
                    "available": sorted(spec_ids[doc])[:5],
                })
    return {
        "name": "requirements_exist",
        "passed": len(findings) == 0,
        "findings": findings,
        "specs_scanned": len(spec_ids),
    }


def check_single_fr_owner(tasks: dict[str, dict]) -> dict:
    """A single FR/NFR should have one primary owner among tasks.

    Multiple TASKs claiming the same FR via `requirements` is a strong sign
    of either duplication or unclear ownership. Helper TASKs should depend
    on the primary owner via `depends_on`, not duplicate `requirements`.
    """
    owners: dict[str, list[str]] = {}
    for tid, fm in tasks.items():
        for req in fm.get("requirements") or []:
            if isinstance(req, str) and "." in req:
                owners.setdefault(req, []).append(tid)
    findings = []
    for req, ts in owners.items():
        if len(ts) > 1:
            findings.append({
                "label": "Multiple primary owners for one requirement",
                "ref": req, "owners": ts,
            })
    return {
        "name": "single_fr_owner",
        "passed": len(findings) == 0,
        "findings": findings,
        "requirements_with_owners": len(owners),
    }


def check_priority_phase_consistency(tasks: dict[str, dict]) -> dict:
    """If TASK has both `priority` (P0/P1/P2) and `phase` (Setup/Core/Tests/Polish),
    they should follow the convention: Setup→P0, Core→P1, Tests/Polish→P2.

    `priority_override: <reason>` exempts a task from this check.
    """
    expected = {
        "setup":  "P0",
        "core":   "P1",
        "tests":  "P2",
        "polish": "P2",
    }
    findings = []
    for tid, fm in tasks.items():
        if fm.get("priority_override"):
            continue
        prio = (fm.get("priority") or "").upper()
        phase = (fm.get("phase") or "").lower().strip()
        if not phase or not prio:
            continue
        # Phase may be "Phase 1: Setup" or just "Setup"
        for key, expected_prio in expected.items():
            if key in phase:
                if prio != expected_prio:
                    findings.append({
                        "label": "Priority does not match phase",
                        "task": tid, "phase": fm.get("phase"),
                        "priority": prio, "expected": expected_prio,
                    })
                break
    return {
        "name": "priority_phase_consistency",
        "passed": len(findings) == 0,
        "findings": findings,
        "tasks_checked": len(tasks),
    }


# ---------------------------------------------------------------------------
# Check: horizontal slicing detector (OPS-039)
# ---------------------------------------------------------------------------

# Layer keywords — title-based heuristic.
# Each entry: (layer_id, regex pattern). Order matters: more specific first.
_LAYER_PATTERNS = [
    ("setup",       re.compile(r"\b(scaffold|bootstrap|boilerplate|setup\s+(?:project|module|directory))\b", re.IGNORECASE)),
    ("data",        re.compile(r"\b(model|entity|schema|dao|repository|migration|table)\b", re.IGNORECASE)),
    ("service",     re.compile(r"\b(service|business\s+logic|domain|usecase|use[-_\s]?case)\b", re.IGNORECASE)),
    ("api",         re.compile(r"\b(controller|route|endpoint|handler|api(?:\s+layer)?)\b", re.IGNORECASE)),
    ("ui",          re.compile(r"\b(view|ui|component|page|template|frontend)\b", re.IGNORECASE)),
    ("tests",       re.compile(r"\b(tests?|specs?|test\s+suite|unit\s+tests?|integration\s+tests?)\b", re.IGNORECASE)),
    ("integration", re.compile(r"\b(integrate|integration|wire(?:\s+up)?|setup\s+dependencies|connect)\b", re.IGNORECASE)),
    ("sql",         re.compile(r"\b(sql\s+logic|sql\s+(?:query|queries)|implement\s+sql)\b", re.IGNORECASE)),
]


def _detect_layer(title: str) -> str | None:
    """Return layer id if title matches a layer keyword, else None."""
    if not title:
        return None
    for layer_id, pat in _LAYER_PATTERNS:
        if pat.search(title):
            return layer_id
    return None


def check_horizontal_slicing(tasks: dict[str, dict], knowledge: dict) -> dict:
    """OPS-039: detect horizontal decomposition (one feature split across layers).

    Heuristic:
    - Group tasks by `parent`.
    - Within each parent, classify each task by its layer (from title).
    - If ≥2 different layers in the same parent group, that's horizontal.
    - Skip the check entirely if decomposition.mode == "strict" (the
      strict prompt already forbids this; no need to warn).
    - Skip individual parent groups if tasks have different `requirements`
      (different FR/NFR = vertical slice across the same surface area, OK).
    """
    mode = ((knowledge.get("decomposition") or {}).get("mode") or "legacy").lower()
    if mode == "strict":
        return {
            "name": "horizontal_slicing",
            "passed": True,
            "findings": [],
            "note": "decomposition.mode='strict' — prompt prevents this; check skipped",
        }

    if not tasks:
        return {"name": "horizontal_slicing", "passed": True, "findings": [],
                "note": "No tasks found"}

    # Group by parent
    by_parent: dict[str, list[tuple[str, dict]]] = {}
    for tid, fm in tasks.items():
        parent = fm.get("parent")
        if parent:
            by_parent.setdefault(parent, []).append((tid, fm))

    findings = []
    for parent, group in by_parent.items():
        if len(group) < 2:
            continue

        # Build layer map for this group
        layer_map: dict[str, list[str]] = {}  # layer_id -> [task_ids]
        unclassified = []
        for tid, fm in group:
            layer = _detect_layer(fm.get("title", ""))
            if layer:
                layer_map.setdefault(layer, []).append(tid)
            else:
                unclassified.append(tid)

        if len(layer_map) < 2:
            # Not enough distinct layers detected — could be vertical or
            # just unclassifiable. Skip.
            continue

        # Check whether tasks have distinct requirements (= vertical slice)
        # If every task has its own non-empty requirements set that doesn't
        # overlap with others, this is likely vertical.
        all_reqs = []
        for tid, fm in group:
            reqs = fm.get("requirements") or []
            if isinstance(reqs, list) and reqs:
                all_reqs.append((tid, set(r for r in reqs if isinstance(r, str))))
        # Vertical signal: each task has unique non-empty req set.
        if all_reqs and len(all_reqs) == len(group):
            uniq = {frozenset(r) for _, r in all_reqs}
            if len(uniq) == len(all_reqs) and all(r for _, r in all_reqs):
                continue  # vertical, skip

        findings.append({
            "label": "Horizontal decomposition detected",
            "parent": parent,
            "task_count": len(group),
            "layers": {layer: tids for layer, tids in layer_map.items()},
            "unclassified_tasks": unclassified,
            "advice": (
                "Tasks split across layers (scaffold/data/service/api/tests/integration). "
                "If FEAT is a single end-to-end feature, prefer vertical slicing — "
                "one TASK closes one user-facing capability across all layers. "
                "If FEAT is a data-mart / multi-output pipeline (each output is independent), "
                "horizontal split may be appropriate. PM decides. To enforce vertical: "
                "set knowledge.decomposition.mode = 'strict'."
            ),
        })

    return {
        "name": "horizontal_slicing",
        # Always passed — this is advisory only, NOT a blocker.
        "passed": True,
        "severity": "warn" if findings else "info",
        "findings": findings,
        "parents_checked": len(by_parent),
    }


# ---------------------------------------------------------------------------
# Check: TDD ordering
# ---------------------------------------------------------------------------


def check_tdd_ordering(workdir: Path, task_id: str, knowledge: dict, base: str | None) -> dict:
    """If knowledge.testing.strategy == 'tdd-first', verify that on the
    current branch there's a commit '[TASK-XXX] Add failing tests' BEFORE
    a commit '[TASK-XXX] Implement'.

    If only one commit so far (still working) — pass with note.
    """
    strategy = (knowledge.get("testing") or {}).get("strategy")
    if strategy != "tdd-first":
        return {
            "name": "tdd_ordering",
            "passed": True,
            "findings": [],
            "note": f"strategy={strategy!r}, TDD ordering not required",
        }

    cwd = str(workdir)
    log_range = f"{base}..HEAD" if base else "HEAD~10..HEAD"
    try:
        log_out = subprocess.run(
            ["git", "log", "--format=%s", log_range],
            cwd=cwd, capture_output=True, text=True, check=True
        ).stdout
    except subprocess.CalledProcessError:
        return {
            "name": "tdd_ordering",
            "passed": True,
            "findings": [],
            "note": "git log failed — branch likely fresh",
        }

    commits = [line for line in log_out.splitlines() if task_id in line]
    if not commits:
        return {
            "name": "tdd_ordering",
            "passed": True,
            "findings": [],
            "note": f"No commits found for {task_id} yet (still in progress)",
        }

    # `git log` returns newest first; reverse for chronological order
    commits = list(reversed(commits))
    test_idx = None
    impl_idx = None
    for i, msg in enumerate(commits):
        m_lower = msg.lower()
        if test_idx is None and ("add failing test" in m_lower or "failing tests" in m_lower or "tests:" in m_lower):
            test_idx = i
        if impl_idx is None and ("implement" in m_lower or "implementation" in m_lower):
            impl_idx = i

    findings = []
    if test_idx is None and impl_idx is not None:
        findings.append({
            "label": "TDD violation",
            "issue": f"Found implement commit but no preceding test commit for {task_id}",
            "commits_seen": commits,
        })
    elif test_idx is not None and impl_idx is not None and test_idx > impl_idx:
        findings.append({
            "label": "TDD violation",
            "issue": "Tests committed AFTER implementation — TDD requires tests-first",
            "commits_seen": commits,
        })
    return {
        "name": "tdd_ordering",
        "passed": len(findings) == 0,
        "findings": findings,
        "commits_seen": commits,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

@dataclass
class Result:
    mode: str
    task_id: str | None = None
    checks: list[dict] = field(default_factory=list)

    def to_json(self) -> str:
        passed = all(c["passed"] for c in self.checks)
        passed_count = sum(1 for c in self.checks if c["passed"])
        out = {
            "check_version": CHECK_VERSION,
            "mode": self.mode,
            "checks": self.checks,
            "passed": passed,
            "summary": f"{passed_count}/{len(self.checks)} checks passed",
        }
        if self.task_id:
            out["task_id"] = self.task_id
        return json.dumps(out, indent=2, ensure_ascii=False)


def make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pdlc_check.py",
        description="Deterministic pre-commit and tasks-graph checks for Polisade.",
    )
    p.add_argument("--project-root", default=".", help="Project root (default: cwd)")
    p.add_argument("--worktree", default=None, help="Worktree path (default: project root)")
    p.add_argument("--diff-base", default=None, help="Base ref for diff (e.g. main); default: working tree only")
    p.add_argument("--output", default=None, help="Write JSON to this file instead of stdout")
    p.add_argument("--summary", action="store_true",
                   help=(
                       "Print human-readable summary to stdout instead of full JSON. "
                       "Useful when running interactively. JSON-to-file via --output "
                       "still works alongside --summary."
                   ))
    sub = p.add_subparsers(dest="mode", required=True)

    s1 = sub.add_parser("pre-commit", help="Run all pre-commit checks for one TASK")
    s1.add_argument("task_id")

    s2 = sub.add_parser("tasks-graph", help=(
        "Validate the graph of all TASKs: DAG cycles, missing deps, "
        "requirement refs against SPECs, single FR ownership, "
        "priority/phase consistency."
    ))
    return p


def format_summary(result: Result) -> str:
    """Human-readable one-line-per-check summary of a Result."""
    lines = []
    mode_label = result.mode
    task_label = f" {result.task_id}" if result.task_id else ""
    lines.append(f"[pdlc_check.py {mode_label}{task_label}]")

    passed_count = 0
    for c in result.checks:
        name = c["name"]
        passed = c["passed"]
        symbol = "✓" if passed else "✗"
        if passed:
            passed_count += 1

        # Build the right-side detail
        finding_count = len(c.get("findings", []))
        if finding_count == 0:
            detail = "0 findings"
            if "note" in c:
                detail = f"note: {c['note']}"
        else:
            detail = f"{finding_count} finding(s)"

        # Severity hint for advisory/warn checks
        sev = c.get("severity")
        if sev == "warn" and passed:
            symbol = "⚠"
            detail = f"{detail} (advisory)"

        lines.append(f"  {symbol} {name:30} {detail}")

        # Inline first 2 findings if any
        for f in c.get("findings", [])[:2]:
            label = f.get("label", "?")
            extra = ""
            if "task" in f:
                extra += f" task={f['task']}"
            if "ref" in f:
                extra += f" ref={f['ref']}"
            if "chain" in f:
                extra += f" chain={f['chain']}"
            if "match_excerpt" in f:
                extra += f" match={f['match_excerpt']!r}"
            lines.append(f"      → {label}{extra}")
        if finding_count > 2:
            lines.append(f"      → ... and {finding_count - 2} more (use --output for full)")

    total = len(result.checks)
    overall_passed = passed_count == total
    exit_hint = "0" if overall_passed else "1"
    lines.append(f"[{passed_count}/{total} passed; exit {exit_hint}]")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = make_parser()
    args = parser.parse_args(argv)

    root = Path(args.project_root).resolve()
    workdir = Path(args.worktree).resolve() if args.worktree else root

    if not root.exists():
        print(f"error: project root does not exist: {root}", file=sys.stderr)
        return 2
    if not workdir.exists():
        print(f"error: worktree does not exist: {workdir}", file=sys.stderr)
        return 2

    if args.mode == "pre-commit":
        task_path = find_task_file(root, args.task_id)
        if not task_path:
            print(f"error: TASK file not found for {args.task_id}", file=sys.stderr)
            return 2

        fm, body = parse_frontmatter(task_path.read_text())
        knowledge = load_knowledge(root)
        diff = get_diff(workdir, args.diff_base)
        added_lines = get_added_lines(diff)
        changed_files = get_changed_files(diff)

        result = Result(mode="pre-commit", task_id=args.task_id)
        result.checks.append(check_hardcoded_secrets(added_lines))
        result.checks.append(check_anti_patterns(added_lines, knowledge))
        result.checks.append(check_ac_coverage(body, changed_files))
        result.checks.append(check_tdd_ordering(workdir, args.task_id, knowledge, args.diff_base))
    elif args.mode == "tasks-graph":
        tasks = load_all_tasks(root)
        knowledge = load_knowledge(root)
        result = Result(mode="tasks-graph")
        result.checks.append(check_dag_no_cycles(tasks))
        result.checks.append(check_deps_exist(tasks))
        result.checks.append(check_requirements_exist(tasks, root))
        result.checks.append(check_single_fr_owner(tasks))
        result.checks.append(check_priority_phase_consistency(tasks))
        result.checks.append(check_horizontal_slicing(tasks, knowledge))
    else:
        parser.error(f"unknown mode: {args.mode}")
        return 2

    json_text = result.to_json()

    # --output: write JSON to file (preserves machine-readable form)
    if args.output:
        out_path = Path(args.output)
        if not out_path.is_absolute():
            out_path = root / out_path
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json_text)

    # stdout: --summary → human-readable; otherwise JSON (legacy default)
    if args.summary:
        print(format_summary(result))
        # If we wrote JSON to a file, print the path on a final line for skills to capture
        if args.output:
            print(f"# JSON: {out_path}")
    else:
        if args.output:
            # No --summary: print path so the calling skill can grab it
            print(str(out_path))
        else:
            print(json_text)

    all_passed = all(c["passed"] for c in result.checks)
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
