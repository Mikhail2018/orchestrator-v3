---
description: "[DEPRECATED] Renamed to /pdlc:review (OPS-017). Alias kept for one release."
---

> **DEPRECATED**

<!-- argument hint: [TASK-XXX] [self] -->

> **DEPRECATED (OPS-017, 2026-04-18):** Команда переименована в `/pdlc:review`.
> Алиас удалится в 3.0. Все аргументы и поведение идентичны.

## Алгоритм

Перенаправить вызов на `/pdlc:review` с теми же аргументами и STOP.