---
description: "[DEPRECATED] Renamed to /pdlc:review-pr (OPS-017). Alias kept for one release."
---

> **DEPRECATED**

<!-- argument hint: [PR# or TASK-XXX] [self] -->

> **DEPRECATED (OPS-017, 2026-04-18):** Команда переименована в `/pdlc:review-pr`.
> Алиас удалится в 3.0. Все аргументы и поведение идентичны.

## Алгоритм

Перенаправить вызов на `/pdlc:review-pr` с теми же аргументами и STOP.