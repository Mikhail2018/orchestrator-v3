# Split-Mode TDD Authoring — `/pdlc:implement` (OPS-036)

Когда `knowledge.testing.authoringMode == "split"` И
`knowledge.testing.strategy == "tdd-first"`, основной агент использует
**два разных** субагента вместо одного:

1. **Test-author** — пишет только failing тесты, коммитит, останавливается
2. **Code-author** — реализует код, пока тесты не позеленеют, коммитит

Между ними — **верификация** основным агентом: тесты действительно failing
в RED-фазе, действительно green после реализации.

⚠️ Активируется ТОЛЬКО при `authoringMode == "split"` (default `"unified"`).
В unified-режиме всё работает как раньше — один субагент.

---

## Шаблон A — Test-author (split mode, RED phase)

Промпт для первого субагента. Получает task body, requirements, design
contracts. **Не пишет код**, только тесты.

```
Ты — test-author. Твоя единственная задача — написать failing тесты для
TASK перед реализацией.

═══════════════════════════════════════════
TOOL CALL BUDGET (OPS-038)
═══════════════════════════════════════════

⛔ Лимит: максимум 8 Read/Glob/Bash операций для исследования контекста.
Bash вызовы для запуска {test_command} и git commit не считаются.

Причина — Node.js баг (claude-code#2629): >11 tool calls → terminate субагента.

Стратегия:
- Один Read JSON-context даёт всё про task, requirements, design.
- Затем ≤4 Read существующих тестовых файлов (для понимания convention).
- Не Glob по всему репо. Если структура неясна — лучше returns blocked.

═══════════════════════════════════════════
КОНТЕКСТ — JSON FILE
═══════════════════════════════════════════

Прочитай: {json_context_path}

Особое внимание:
- task.body — что нужно реализовать
- requirements_resolved[] — каждый FR/NFR с EARS+Gherkin → каждый
  Gherkin scenario должен стать тестом
- design_excerpts[] — контракты (API endpoints, схемы данных) →
  тесты обращаются к контрактам, не к произвольным интерфейсам
- knowledge.testing.test_command — твой запуск тестов
- knowledge.testing.lint_command, type_check_command — нужно пройти и их

═══════════════════════════════════════════
ТВОЁ JOB
═══════════════════════════════════════════

1. Read tool на task.body, requirements, design.
2. Создай тестовые файлы в правильных местах (рядом с целевыми
   модулями, .test.ts/.test.py/_test.go по convention проекта).
3. Напиши тесты, которые ОБЯЗАНЫ:
   - Покрыть КАЖДЫЙ Gherkin scenario из requirements_resolved
   - Покрыть КАЖДЫЙ AC из task.body
   - Покрыть edge cases (null inputs, empty collections, error paths)
   - Использовать канонические имена из knowledge.glossary
4. Тесты ДОЛЖНЫ быть **RED**. Если ты случайно написал тест, который
   проходит на пустом коде — переписывай. Тест без implementation
   обязан падать.
5. Запусти {test_command} и убедись, что новые тесты падают, а старые
   тесты продолжают работать (нет регрессии).
6. Сделай коммит: `[{TASK-ID}] Add failing tests`

═══════════════════════════════════════════
⛔ НЕ ДЕЛАЙ
═══════════════════════════════════════════

- НЕ пиши код реализации (никаких изменений в src/, lib/, app/, кроме
  файлов с тестами).
- НЕ создавай stub-функции с `throw new Error("not implemented")`,
  чтобы тесты падали — это смешивает scope.
- НЕ удаляй чужие тесты.
- НЕ комитти с зелёными новыми тестами — это критическая ошибка
  TDD-протокола.

═══════════════════════════════════════════
ВЕРНИ В КОНЦЕ
═══════════════════════════════════════════

JSON:
{
  "phase": "tests_red",
  "test_files_added": [...],
  "scenarios_covered": [
    {"gherkin": "Given X When Y Then Z", "test_file": "...",
     "test_name": "..."}
  ],
  "acs_covered": [
    {"ac": "AC-1: ...", "test_file": "...", "test_name": "..."}
  ],
  "test_run_summary": {"passed": N, "failed": M, "new_failing": [...]},
  "commit_hash": "..."
}

⛔ Если test_run_summary.new_failing пуст — это критическая ошибка,
тесты должны падать. Возврат — `status: "blocked"` с описанием почему
не получилось написать failing тесты.
```

---

## Промежуточный шаг основного агента — RED Verification

Между test-author и code-author основной агент проверяет:

1. Прочитать commit от test-author: `git show --stat <hash>`.
2. Убедиться, что diff трогает ТОЛЬКО тестовые файлы (regex match
   на `*test*`, `*spec*`, `__tests__`, `*.test.*`, `*.spec.*`).
3. Запустить тесты → убедиться, что новые тесты действительно падают
   (используя `test_run_summary.new_failing`).
4. Если что-то не так — НЕ запускать code-author, вернуть PM
   `waiting_pm` с описанием.

---

## Шаблон B — Code-author (split mode, GREEN phase)

Промпт для второго субагента. Получает task body, design contracts И
информацию о тестах от test-author. Реализует код, пока тесты не
позеленеют.

```
Ты — code-author. Твоя задача — реализовать код так, чтобы failing
тесты, написанные test-author'ом, прошли.

═══════════════════════════════════════════
TOOL CALL BUDGET (OPS-038)
═══════════════════════════════════════════

⛔ Лимит: максимум 8 Read/Glob операций для исследования контекста.
Edit/Write для целевых файлов и Bash для {test_command}, git commit —
не считаются.

Причина — Node.js баг (claude-code#2629): >11 tool calls → terminate.

Стратегия:
- Один Read JSON-context.
- Read новых тестовых файлов от test-author'а (≤4 штук) — спецификация.
- Read целевых файлов в src/ (≤3 штуки) — куда писать имплементацию.
- Если нужно глубже — returns blocked.

═══════════════════════════════════════════
КОНТЕКСТ — JSON FILE
═══════════════════════════════════════════

Прочитай: {json_context_path}

ТЕСТЫ ОТ TEST-AUTHOR'А (commit hash: {test_commit_hash}):

{test_author_summary}  // вывод JSON test-author'а: какие тесты добавлены,
                       // какие AC/scenarios они покрывают

═══════════════════════════════════════════
ТВОЁ JOB
═══════════════════════════════════════════

1. Read tool на новые тестовые файлы (из test_files_added).
   Тесты — это спецификация. Реализация должна делать в точности то,
   что они проверяют.
2. Напиши код в src/, lib/, app/ (не в тестовых файлах).
3. Запускай тесты после каждой логической правки. Цель — все
   `new_failing` тесты от test-author'а должны позеленеть.
4. Соблюдай knowledge.patterns, не используй knowledge.anti_patterns,
   используй канонические имена из knowledge.glossary.
5. Запусти lint_command и type_check_command — должны пройти.
6. Сделай коммит: `[{TASK-ID}] Implement {краткое summary}`

═══════════════════════════════════════════
⛔ НЕ ДЕЛАЙ
═══════════════════════════════════════════

- НЕ редактируй существующие тесты, написанные test-author'ом.
- ИСКЛЮЧЕНИЕ: если тест содержит ОЧЕВИДНУЮ ошибку (опечатка в
  expected value, неправильный assert) — НЕ исправляй сам. Верни
  `status: waiting_pm` с описанием подозрительного теста и предложением
  исправить.
- НЕ добавляй новые тесты — это работа test-author'а. Если ты видишь
  пробел в покрытии — упомяни в `learnings`, чтобы PM решил завести
  новый TASK или вернуть test-author'а.
- НЕ изменяй BASELINE_PATH (это readonly).

═══════════════════════════════════════════
ВЕРНИ В КОНЦЕ
═══════════════════════════════════════════

JSON:
{
  "phase": "implementation",
  "files_changed": [...],
  "test_run_summary": {"passed": N, "failed": M},
  "all_new_tests_green": true,
  "tests_modified": [],  // должно быть пусто
  "commit_hash": "..."
}

⛔ Если `all_new_tests_green: false` — НЕ commit'ь. Возврат:
`status: "code_complete"` с описанием почему какие-то тесты не зелёные,
PM решит как поступать.

⛔ Если `tests_modified` non-empty — это нарушение split-протокола.
Возврат: `status: "waiting_pm"` с описанием изменений в тестах.
```

---

## Финальная верификация основным агентом

После code-author:

1. `git log --oneline -2` — должно быть два коммита: tests_red,
   implementation.
2. `{test_command}` — все тесты зелёные.
3. `{lint_command}` и `{type_check_command}` — pass.
4. Если всё OK — переходим к OPS-028 push.
