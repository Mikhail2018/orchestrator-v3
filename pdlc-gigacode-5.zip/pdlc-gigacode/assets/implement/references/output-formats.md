# Output Formats — `/pdlc:implement`

Этот файл — справочник форматов вывода для основного агента в разных
точках жизненного цикла `/pdlc:implement`. SKILL.md алгоритм ссылается
на конкретные блоки здесь по названию шага.

### Начало работы (M/L-задача)
```
═══════════════════════════════════════════
РЕАЛИЗАЦИЯ: TASK-001
═══════════════════════════════════════════

Задача: Create user API endpoint
Родитель: FEAT-001
Статус: in_progress
Ветка: feat/FEAT-001-user-auth
Worktree: .worktrees/feat__FEAT-001-user-auth/  # если workspaceMode: "worktree"

Контекст из knowledge.json:
• Patterns: Repository pattern, Error as value
• Anti-patterns: no any in TS
• Decisions: PostgreSQL (ADR-001)

Запускаю субагент...
```

### Начало работы (S-задача)
```
═══════════════════════════════════════════
РЕАЛИЗАЦИЯ: TASK-042 (S-задача, напрямую)
═══════════════════════════════════════════

Задача: Update prompt template wording
Родитель: FEAT-005
Размер: S (2 AC, 1 файл)

Реализую напрямую (без субагента)...
```

### При завершении реализации (переход к тестированию)
```
═══════════════════════════════════════════
РЕАЛИЗАЦИЯ ЗАВЕРШЕНА
═══════════════════════════════════════════

ID: TASK-001
Родитель: FEAT-001
Ветка: feat/FEAT-001-user-auth

Изменения:
• src/api/users.ts — создан endpoint
• tests/api/users.test.ts — добавлены тесты

Коммит: abc123
Сообщение: "[TASK-001] Add user API endpoint"

───────────────────────────────────────────
ЗАПУСК REGRESSION TESTS...
───────────────────────────────────────────
```

### При прохождении regression (создание PR)
```
───────────────────────────────────────────
✓ REGRESSION TESTS PASSED
───────────────────────────────────────────
Всего: 142 тестов
Прошло: 140 | Известные падения: 2 | Новые падения: 0
Время: 8.5s

Известные падения (из knownFlakyTests):
  • test_external_api_timeout — flaky network mock (2026-01-15)
  • test_race_condition — timing-dependent (2026-02-01)

Type check: ✓ mypy src/ --strict (0 ошибок)
Lint: ✓ ruff check src/ (0 замечаний)

───────────────────────────────────────────
СОЗДАНИЕ PR...
───────────────────────────────────────────
PR #45: [TASK-001] Add user API endpoint
URL: https://github.com/org/repo/pull/45
Статус TASK: review

Ожидание code review...
```

### При успешном review (score >= 8)
```
═══════════════════════════════════════════
✓ REVIEW ПРОЙДЕН — PR ГОТОВ К MERGE
═══════════════════════════════════════════

ID: TASK-001
Тип: Feature task
Родитель: FEAT-001
Статус: review
Review score: 9/10

PR #45: ready to merge
URL: https://github.com/org/repo/pull/45

Learnings добавлены в knowledge.json:
• "Используется custom ApiError class"

Worktree: .worktrees/feat__FEAT-001-user-auth/ (сохранён для правок по ревью)

═══════════════════════════════════════════
/pdlc:implement завершён

Следующие действия:
   → PM мержит PR: /pdlc:pr merge N --squash --delete-branch
   → /pdlc:continue — продолжить автономную работу
   → /pdlc:state — посмотреть статус проекта
═══════════════════════════════════════════
```

(Блок "Worktree" и "Cleanup" — только при workspaceMode: "worktree")

### При падении тестов (автоисправление)
```
───────────────────────────────────────────
✗ REGRESSION TESTS: НОВЫЕ ПАДЕНИЯ
───────────────────────────────────────────
Всего упало: 4 теста

Известные (knownFlakyTests) — ИГНОРИРУЕМ:
  • test_external_api_timeout — flaky network mock
  • test_race_condition — timing-dependent

⚠️ Новые падения — ИСПРАВЛЯЕМ:
  1. test_user_validation — AssertionError
  2. test_auth_middleware — TypeError

Анализирую и исправляю новые падения...

[...исправление...]

Коммит: def456 "[TASK-001] Fix regression test failures"

───────────────────────────────────────────
ПОВТОРНЫЙ ЗАПУСК TESTS...
───────────────────────────────────────────
```

### При review замечаниях (автоисправление)
```
───────────────────────────────────────────
⚠️ CHANGES REQUESTED
───────────────────────────────────────────
PR #45 требует исправлений:

• src/api/users.ts:45 — добавить валидацию email
• tests/api/users.test.ts — покрыть edge case

Исправляю...

[...исправление...]

Коммит: ghi789 "[TASK-001] Address review comments"
Тесты: ✓ passed

Push и обновление PR...
Ожидание повторного review...
```

### При блокировке (waiting_pm)

⚠️ Правило: prompt-блок — последний в turn'е. Никакого вывода после него.

Если субагент вернул структурированные `questions` (см.
`subagent-prompt-template.md` секция «ФОРМАТ questions»), основной
агент рендерит их с options и tradeoffs:

```
═══════════════════════════════════════════
TASK-001 → waiting_pm
═══════════════════════════════════════════

Реализация остановилась — нужно {N} решений PM.

Вопрос 1/N: Какой payment provider использовать?

  Контекст: при попытке имплементировать `processPayment()` обнаружил
  что в knowledge.json нет упоминания провайдера, в SPEC только NFR
  (latency < 500ms), в design — generic Provider interface.

  Варианты:
    A) Stripe API
       Tradeoffs: дороже, но проще интеграция; нужен API ключ
       Implies:   TASK +1 день, зависимость от Stripe SDK
    B) PayPal API
       Tradeoffs: дешевле, но больше boilerplate
       Implies:   TASK в скоупе, нужен merchant account

  Рекомендация субагента: A

═══════════════════════════════════════════

►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
►  ОТВЕТЬТЕ ЧЕРЕЗ /pdlc:unblock
►►►━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

→ запустите: /pdlc:unblock
```

Для legacy-формата (когда `questions` пришёл строками, не объектами) —
выводи как есть, без options блока.

### При технической блокировке (blocked)
```
═══════════════════════════════════════════
ЗАБЛОКИРОВАНО
═══════════════════════════════════════════

ID: TASK-001
Статус: blocked

Причина: Не установлена зависимость xyz
Попытки решения:
• npm install xyz — ошибка версии
• Альтернативная библиотека — не подходит

→ Требуется ручное вмешательство
═══════════════════════════════════════════
```
