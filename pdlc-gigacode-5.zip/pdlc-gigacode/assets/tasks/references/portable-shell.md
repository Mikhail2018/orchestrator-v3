# Portable Shell Rules (OPS-037)

Скиллы запускаются разными CLI на разных платформах:
- **Claude Code** на macOS / Linux (bash, zsh)
- **Claude Code на Windows** (Git Bash или WSL — POSIX shell)
- **Codex CLI** на macOS / Linux
- **Qwen / GigaCode** на любой платформе

Когда основной агент или субагент пишет shell-команды, они должны
работать на **всех** этих средах. Иначе — обрыв workflow на платформе,
где агент сгенерировал platform-specific syntax.

## ⛔ ЗАПРЕЩЕННЫЕ конструкции

### `2>nul`, `2>NUL` — Windows cmd-only

Эти редиректы работают только в `cmd.exe`. В Git Bash / WSL / POSIX
shell `nul` интерпретируется как файл с именем `nul` относительно
cwd, и команда падает с exit code 1 (если попытка создать файл `nul`
не удалась) или загрязняет файловую систему.

**Не делай:**
```bash
mkdir tasks 2>nul
del file 2>nul
```

**Делай:**
```bash
mkdir -p tasks                     # -p: тихо игнорирует "уже существует"
rm -f file                         # -f: тихо игнорирует "не найден"
```

### `cmd /c`, `cmd.exe`, `powershell -c`

Запуск команд через Windows-специфичные оболочки. Не работает на
macOS/Linux.

**Не делай:**
```bash
cmd /c "dir > out.txt"
powershell -c "Get-Content file"
```

**Делай:**
```bash
ls > out.txt
cat file
```

### Backslash пути в командах

Пути в bash/POSIX используют `/`, не `\`. Backslash `\` в bash
интерпретируется как escape character.

**Не делай:**
```bash
cd C:\Users\me\project
mkdir docs\architecture
```

**Делай:**
```bash
cd "C:/Users/me/project"           # forward slashes работают на Windows тоже
mkdir -p "docs/architecture"
```

### `set VAR=value` (Windows cmd)

В bash используется `VAR=value` без `set`.

**Не делай:**
```bash
set TASK_ID=TASK-001
```

**Делай:**
```bash
TASK_ID="TASK-001"
export TASK_ID="TASK-001"          # если нужно для дочерних процессов
```

### `&&` цепочки без проверки

Хотя `&&` работает везде, длинные цепочки усложняют отладку. На
ошибке в середине ничего не указывает, что именно упало.

**Не делай:**
```bash
mkdir -p tasks && cd tasks && touch TASK-001.md && git add TASK-001.md
```

**Делай:**
```bash
mkdir -p tasks
cd tasks
touch TASK-001.md
git add TASK-001.md
```

Каждая команда — отдельная, агент видит точку отказа.

## ✅ РАЗРЕШЕННЫЕ конструкции (POSIX)

### Создание директории идемпотентно
```bash
mkdir -p path/to/dir               # тихо OK если существует
```

### Удаление файла идемпотентно
```bash
rm -f file                         # тихо OK если не существует
rm -rf dir                         # для директорий
```

### Подавление stderr
```bash
command 2>/dev/null                # POSIX null device
command > /dev/null 2>&1           # подавить и stdout и stderr
```

### Условное выполнение
```bash
if [ -d "tasks" ]; then echo exists; fi
if [ -f "TASK-001.md" ]; then ...; fi
[ -d "path" ] || mkdir -p "path"   # альтернативный синтаксис
```

### Захват вывода в переменную
```bash
RESULT=$(command)
LINES=$(wc -l < file)
```

### Цитирование путей с пробелами
```bash
cd "$HOME/Documents/My Project"    # ВСЕГДА в кавычках
ls "${PDLC_WORK_DIR:-.}"           # default через ${VAR:-default}
```

### Tools вместо shell для файловых операций

Часто **не нужно** писать shell вообще. Большинство файловых операций
доступны через tools агента:

| Что | Shell (нежелательно) | Tool (предпочтительно) |
|---|---|---|
| Создать файл | `echo ... > file.md` | `Write` tool |
| Прочитать файл | `cat file.md` | `Read` tool |
| Найти файлы | `find . -name '*.md'` | `Glob` tool |
| Поиск по содержимому | `grep -rn 'FR-001' .` | `Grep` tool |
| Изменить файл | `sed -i ...` | `Edit` / `str_replace` tool |

Tools работают cross-platform. Shell — только когда tools недоступен
(git, тестовые команды, build commands).

## Что делать, если PM-проект на Windows и нужен Windows-syntax

Если PM-проект на Windows и есть Windows-only тулинг (например,
PowerShell-скрипты сборки), правильное решение:

1. **НЕ зашивать Windows-syntax в скиллы плагина.** Скиллы остаются
   POSIX.
2. **Зашить platform detection в проекте, не в плагине.** В
   `knowledge.json:testing.testCommand` PM указывает команду, которая
   уже учитывает платформу: например, `pwsh -c "..."` или
   `npm run test:windows`. Плагин просто запускает то, что указано.
3. **Если действительно нужна shell-логика, специфичная для Windows** —
   PM пишет её в bash скрипте `.pdlc/hooks/`, который вызывает PowerShell
   изнутри. Плагин zaпускает bash-скрипт, не PowerShell напрямую.

## Контекст: почему этот файл появился

Real-world incident (2026-04-29): subagent в `/pdlc:tasks` для FEAT-001
завершился сбоем (`terminated`, MaxListeners). Основной агент,
импровизируя без четкого протокола обработки сбоев, написал команду:
```
mkdir "C:\Users\21271087\IdeaProjects\promissory\tasks" 2>nul
```
Команда упала с exit code 1. Это привело к double failure: и subagent
не отработал, и manual recovery попытка тоже.

Правильный путь — после первого сбоя субагента вернуть `waiting_pm`,
не импровизировать с shell. См. `tasks/SKILL.md` § 4.4 (OPS-037).
