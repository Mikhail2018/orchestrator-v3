# Reviewer Prompt — `/pdlc:review-pr`

Полный шаблон промпта для reviewer-субагента. SKILL.md `### 2. Запустить
Review субагент` ссылается сюда.

Здесь живёт:
- Pre-fetch последовательность (`pr-diff` + `pr-view` через `pdlc_vcs.py`)
- Codex-режим (codex exec) и self-режим (heredoc)
- Полный текст промпта ревьюера со всеми критериями
- Шаг публикации ответа как комментария к PR (`pr-comment`)

---

## Field mapping: pdlc_context.py JSON → переменные шаблона

OPS-029 / Пакет 1: основной агент перед запуском субагента вызывает
`pdlc_context.py for-review-pr --task TASK-XXX --pr-num N`. Из JSON формирует
переменные для heredoc промпта:

| Переменная heredoc | Источник из JSON |
|---|---|
| `${TASK_ID}` | `task.id` |
| `${PR_NUM}` | `pr_num` (из аргумента) |
| `${PR_DIFF}` | результат `pdlc_vcs.py pr-diff` (не из JSON, отдельный fetch) |
| `${PR_DESC}` | результат `pdlc_vcs.py pr-view` (не из JSON, отдельный fetch) |
| `${REVIEW_FOCUS}` | сериализация `review_focus` блока: `patterns_to_check`, `anti_patterns_to_flag`, `glossary_terms`, `decisions_to_respect`. Формат — bullet-list для удобства чтения ревьюером. Если все четыре пусты — пустая строка. |
| `${REQUIREMENTS_RESOLVED}` | `requirements_resolved[]` — для усиления Acceptance criteria axis |
| `${DESIGN_EXCERPTS}` | `design_excerpts[].content` — конкретные секции контрактов |
| `${CONSTRAINTS}` | `constraints_and_assumptions.constraints` — для Constraints compliance axis |
| `${SYSTEM_BOUNDARY}` | `system_boundary` — для System boundary compliance axis |
| `${OUT_OF_SCOPE}` | `out_of_scope[]` — flag PR, который реализует out-of-scope items |

⚠️ **Главное изменение OPS-029 для ревью**: переменная `${REVIEW_FOCUS}`
впервые попадает в промпт ревьюера. До этого ревьюер не видел
patterns/antiPatterns/glossary проекта, и критерий «Качество: паттерны»
оценивался произвольно. Теперь у ревьюера есть явный чек-лист.

`warnings[]` НЕ инжектируются в промпт — выводятся PM как diagnostics.

---

## Шаблон A — РЕКОМЕНДУЕМЫЙ (через cached JSON-context)

OPS-029 path. Основной агент:
1. Запускает `pdlc_context.py for-review-pr --task TASK-XXX --pr-num N --output .pdlc/cache/json_outputs/context-review-<task>.json`
2. Stdout даёт путь к JSON.
3. Pre-fetch'ит diff и PR description через `pdlc_vcs.py` (см. ниже).
4. Передаёт в промпт ревьюера: `${JSON_CONTEXT_PATH}`, `${PR_DIFF}`, `${PR_DESC}`.

**Шаг 1: Pre-fetch diff и PR description:**

```bash
TASK_ID="{TASK-XXX}"
PR_NUM="{N}"

PR_DIFF=$(python3 {plugin_root}/scripts/pdlc_vcs.py pr-diff "${PR_NUM}" --project-root "${PDLC_WORK_DIR:-.}")
PR_DESC=$(python3 {plugin_root}/scripts/pdlc_vcs.py pr-view "${PR_NUM}" --fields title,body,files --format json --project-root "${PDLC_WORK_DIR:-.}")
```

**Шаг 2: Промпт ревьюера (компактный, ~40 строк vs ~80 в legacy):**

```
Ты — независимый ревьюер кода. Проведи quality review PR #${PR_NUM} на соответствие задаче ${TASK_ID}.

═══════════════════════════════════════════
TOOL CALL BUDGET (OPS-038)
═══════════════════════════════════════════

⛔ Лимит: максимум 8 Read/Glob/Bash операций.

Причина — известный Node.js баг (claude-code#2629). На каждом tool call
накапливается abort-listener; >11 → warning, > → terminate.

Стратегия для review:
- ${PR_DIFF} и ${PR_DESC} уже встроены в промпт — НЕ вызывай pr-diff/pr-view ещё раз.
- ${JSON_CONTEXT_PATH} — один Read даёт всё что нужно про task и review_focus.
- Если нужно посмотреть конкретный файл целиком (контекст вокруг изменения) —
  ≤4 Read. Не Glob.

═══════════════════════════════════════════
КОНТЕКСТ — JSON FILE
═══════════════════════════════════════════

Прочитай: ${JSON_CONTEXT_PATH}

JSON содержит: task, parent_chain, requirements_resolved, design_excerpts,
constraints_and_assumptions, system_boundary, out_of_scope,
review_focus.{patterns_to_check, anti_patterns_to_flag, glossary_terms,
decisions_to_respect}.

═══════════════════════════════════════════
PR DIFF
═══════════════════════════════════════════

${PR_DIFF}

═══════════════════════════════════════════
PR DESCRIPTION
═══════════════════════════════════════════

${PR_DESC}

═══════════════════════════════════════════
АЛГОРИТМ
═══════════════════════════════════════════

1. Прочитай JSON-context (выше).
2. Сравни PR diff с `requirements_resolved[]` — закрыты ли все AC.
3. Если `design_excerpts[]` non-empty — сравни PR с контрактами;
   если drift (новые endpoints/entities не из design) — flag как нарушение
   ИЛИ проверь что design-артефакт ОБНОВЛЁН в этом же PR.
4. Проверь `constraints_and_assumptions.constraints` — не нарушает ли PR.
5. Проверь `system_boundary` — не лезет ли PR во внешние системы.
6. Проверь `out_of_scope[]` — не реализует ли PR что-то из этого списка.
7. Используй `review_focus` как ОБЯЗАТЕЛЬНЫЙ checklist:
   - patterns_to_check — обязательные паттерны (Repository pattern, etc.)
   - anti_patterns_to_flag — запрещённые конструкции
   - glossary_terms — канонические имена; flag synonyms_to_avoid
   - decisions_to_respect — ADR'ы проекта

Если REVIEW_FOCUS пустой — это OK, продолжай без чек-листа.

═══════════════════════════════════════════
ШКАЛА ОЦЕНКИ (применяй ко всем осям)
═══════════════════════════════════════════

10 — образцовое решение, использовал бы как пример для команды
9 — отличное решение, ничего бы не менял
8 — хорошее решение, есть мелкие nice-to-have, но они НЕ блокируют merge
7 — приемлемое, есть улучшения которые лучше сделать сейчас, чем потом
6 — есть конкретные проблемы средней важности, нужны правки
5 — заметные пробелы, нужна доработка перед merge
≤4 — серьёзные проблемы (баги, нарушение требований, отсутствие тестов)

ПРАВИЛО: используй конкретные числа на основании конкретных наблюдений.
НЕ ставь 8 «потому что вроде ОК» — назови что именно ОК. НЕ ставь 7
«потому что есть замечания» — назови КАКИЕ.

═══════════════════════════════════════════
ОЦЕНКИ (1-10) с обоснованиями ниже
═══════════════════════════════════════════

ПРИВЯЗКА К ОСЯМ — что именно оценивает каждая ось:

- Acceptance criteria: закрыт ли каждый AC из task.body? Привязка
  AC → file:line есть? Если AC=3 и закрыто 3 — 9-10. Если 2/3 — 6-7.
  Если 1/3 или AC сформулированы расплывчато — ≤5.

- Полнота: реализованы ли ВСЕ requirements_resolved? Edge cases
  покрыты (null, пустые, ошибки)? Если ВСЕ FR/NFR + edge cases — 9-10.
  Если 1 из NFR пропущен (например, latency не измерена) — 7.
  Если только happy path — ≤5.

- Качество: читаемость, именование, отсутствие дублирования, разумная
  длина функций. 8+ если код такого качества, что новичку понятно.
  Если есть копипаста, длинные функции, нечитаемые имена — ≤6.

- Тесты: новый код покрыт? Добавлены тесты на edge cases? Old тесты
  не сломаны? Если coverage близок к 100% И edge cases — 9-10. Только
  happy path тесты — 6. Тестов нет, но код работает — ≤4.

- Безопасность: hardcoded secrets / SQL injection / XSS / unsafe deser /
  отсутствие validation на boundary — каждое = -3 балла от 10.

- Constraints compliance: НЕ нарушает constraints из SPEC §4? PASS=10.
  N/A если в SPEC нет constraints. Каждое нарушение = -4.

- System boundary: код находится строго внутри system_boundary, внешние
  системы доступны только через адаптеры? PASS=10. N/A если нет
  external_systems. Drift = ≤5.

- Design conformance: реализация совпадает с design_excerpts? Если ДА —
  9-10. Если есть drift но design АРТЕФАКТ обновлён в этом же PR — 8.
  Drift БЕЗ обновления design — ≤5. N/A если design_refs пуст или
  design_waiver: true.

- Patterns & Glossary: использует patterns_to_check, не использует
  anti_patterns_to_flag, использует канонические имена из
  glossary_terms (а не synonyms_to_avoid)? PASS=9-10. Один синоним
  типа UserSession вместо Session — -2. Использование anti_pattern с
  regex — -3. N/A если REVIEW_FOCUS пуст.

ВЫВОД (формат):

- Acceptance criteria: X/10 — {что закрыто, что нет, привязка file:line}
- Полнота: X/10 — {какие FR/NFR покрыты, что edge cases пропущены}
- Качество: X/10 — {конкретные примеры file:line}
- Тесты: X/10 — {coverage, edge cases — конкретно}
- Безопасность: X/10 — {что проверено, найденные проблемы}
- Constraints compliance: X/10 — {какие constraints проверены, или N/A}
- System boundary: X/10 — {соблюдена ли граница, или N/A}
- Design conformance: X/10 — {соответствует ли design_excerpts, или N/A}
- Patterns & Glossary: X/10 — {patterns/glossary compliance, или N/A}
- ИТОГО: X/10 (среднее по непустым осям, округление вниз)

КРИТИЧНЫЕ ПРОБЛЕМЫ (блокеры): file:line — проблема — как исправить
УЛУЧШЕНИЯ (конкретные): file:line — что изменить — как изменить

ВЕРДИКТ: PASS (ИТОГО >= 8 И нет блокеров) | IMPROVE (ИТОГО < 8 ИЛИ есть блокеры)
```

**Шаг 3: Опубликовать ответ как комментарий к PR** — через
`pdlc_vcs.py pr-comment ${PR_NUM} <text>`. См. legacy template для деталей.

---

## Шаблон B — LEGACY fallback (inline всё в промпт)

⚠️ Используется ТОЛЬКО когда `pdlc_context.py` недоступен. Полный
оригинальный промпт ревьюера со всеми инлайн-секциями:

---

### 2. Запустить Review субагент

```
Task tool:
  subagent_type: "general-purpose"
  description: "Review PR #N for TASK-XXX"
  prompt: [см. ниже]
```

Субагент выполняет через Bash (timeout: 300000ms) из корня текущего проекта:

**Шаг 1: Pre-fetch diff и PR description (субагент, до вызова ревьюера):**

```bash
TASK_ID="{TASK-XXX}"
PR_NUM="{N}"

PR_DIFF=$(python3 {plugin_root}/scripts/pdlc_vcs.py pr-diff "${PR_NUM}" --project-root "${PDLC_WORK_DIR:-.}")
PR_DESC=$(python3 {plugin_root}/scripts/pdlc_vcs.py pr-view "${PR_NUM}" --fields title,body,files --format json --project-root "${PDLC_WORK_DIR:-.}")
```

**Шаг 2: Передать данные в промпт ревьюера:**

**Режим `self`** — заменить `codex exec ...` на CLI текущего агента:

| Агент | Команда |
|---|---|
| Claude Code | `cat <<PROMPT \| claude -p` (heredoc без кавычек — переменные раскрываются) |
| Codex CLI | `codex exec --full-auto -m gpt-5.3-codex -c model_reasoning_effort='"high"' "PROMPT"` |
| Qwen CLI | `cat <<PROMPT \| gigacode --allowed-tools=run_shell_command -p` (heredoc без кавычек) |
| GigaCode | `cat <<PROMPT \| gigacode --allowed-tools=run_shell_command -p` (heredoc без кавычек) |

Агент определяет свой CLI по системному контексту. Heredoc **без кавычек** (`<<PROMPT`, не `<<'PROMPT'`), чтобы `${PR_DIFF}`, `${PR_DESC}`, `${TASK_ID}` раскрылись.

> **OPS-022:** argv для self-CLI берётся из `cli-capabilities.yaml:targets.<cli>.non_interactive_args` и проверяется linter-ом (`pdlc_lint_skills.py::check_self_reviewer_tables`) на строгое равенство с ячейкой таблицы.

**Режим Codex (по умолчанию):**

```bash
cd {worktree_path_or_project_root} && codex exec \
  --full-auto \
  -m gpt-5.3-codex \
  -c model_reasoning_effort='"high"' \
"
Ты — независимый ревьюер кода. Проведи quality review Pull Request #${PR_NUM} на соответствие требованиям задачи ${TASK_ID}.

PR DESCRIPTION:
${PR_DESC}

PR DIFF:
${PR_DIFF}

REVIEW FOCUS (из knowledge.json и design_refs — собрано pdlc_context.py for-review-pr):
${REVIEW_FOCUS}

REVIEW FOCUS — это явный чек-лист для тебя:
- patterns_to_check: обязательные паттерны проекта (Repository pattern, Error as value, etc.) — flag PR, который их нарушает
- anti_patterns_to_flag: запрещённые конструкции — flag PR, который их использует
- glossary_terms: канонические имена сущностей — flag PR, который изобретает синонимы (UserSession вместо Session, etc.) или использует имена из synonyms_to_avoid
- decisions_to_respect: ADR'ы проекта — flag PR, который противоречит зафиксированным решениям

Если REVIEW_FOCUS пустой — это OK, продолжай без этого чек-листа.

Алгоритм:
1) Diff и описание PR уже предоставлены выше — используй их
2) Найди файл задачи ${TASK_ID} в репозитории (tasks/)
3) Прочитай задачу целиком (включая metadata/frontmatter)
3.5) Если TASK.design_refs non-empty И TASK.design_waiver != true:
   - Прочитай КАЖДЫЙ файл из design_refs (конкретные файлы:
     api.md, data-model.md, sequences.md, state-machines.md, etc.)
   - Сравни PR diff против design-контрактов:
     • API endpoints: paths, methods, request/response schemas, status codes
     • Data model: entities, fields, types, relationships
     • Sequences: порядок вызовов, error paths
     • States: состояния, переходы
   - Если PR добавляет/меняет endpoint/entity/flow, отсутствующий в design:
     проверь что design-артефакт ОБНОВЛЁН в этом же PR
4) Определи родительскую задачу и восстанови intent
5) Используй AGENTS.md как системные гайдлайны проекта
6) Проверь каждый изменённый файл на качество кода
7) Прочитай тесты — оцени покрытие новой функциональности

Критерии оценки (1-10):
- Acceptance criteria: все ли требования из TASK выполнены
- Полнота: нет ли пропущенных частей задачи
- Качество: паттерны, error handling, naming, архитектура
- Тесты: покрытие, edge cases, корректность assertions
- Безопасность: нет hardcode, injection, секретов в коде
- Constraints compliance: если parent SPEC имеет секцию 4 (Constraints C-N),
  проверь что PR не нарушает ни одного constraint (например, если C-1
  фиксирует PostgreSQL — код не использует другую СУБД; если C-2 — GDPR —
  данные EU users не утекают за пределы EU-region)
- System boundary compliance: если parent SPEC имеет `system_boundary` и
  `external_systems` в frontmatter — проверь что PR НЕ содержит:
  (1) production-кода внешних систем (только клиенты/адаптеры на нашей стороне),
  (2) модификаций consumed-контрактов (`docs/contracts/consumed/`),
  (3) реализации логики внешних систем вместо интеграционных адаптеров
- Design conformance: если TASK.design_refs non-empty И TASK.design_waiver != true —
  проверь что реализация соответствует контрактам из design_refs (шаг 3.5);
  если PR содержит drift (новые endpoints/entities/flows не из design) —
  проверь что design-артефакты ОБНОВЛЕНЫ в этом же PR;
  N/A если design_refs пуст или design_waiver: true
- Patterns & Glossary compliance: если REVIEW_FOCUS не пустой —
  проверь соответствие patterns_to_check (используются ли требуемые паттерны),
  anti_patterns_to_flag (нет ли запрещённых конструкций),
  glossary_terms (используются ли канонические имена, нет ли синонимов из synonyms_to_avoid),
  decisions_to_respect (нет ли противоречий ADR'ам);
  N/A если REVIEW_FOCUS пуст

Формат ответа:
ОЦЕНКИ:
- Acceptance criteria: X/10 — {обоснование}
- Полнота: X/10 — {обоснование}
- Качество: X/10 — {обоснование}
- Тесты: X/10 — {обоснование}
- Безопасность: X/10 — {обоснование}
- Constraints compliance: X/10 — {обоснование, или N/A если нет constraints в SPEC}
- System boundary: X/10 — {обоснование, или N/A если нет external_systems в SPEC}
- Design conformance: X/10 — {обоснование, или N/A если нет design_refs или design_waiver}
- Patterns & Glossary: X/10 — {обоснование, или N/A если REVIEW_FOCUS пуст}
- ИТОГО: X/10

КРИТИЧНЫЕ ПРОБЛЕМЫ (блокеры, если есть):
1. {file:line}: {проблема} → {как исправить}

УЛУЧШЕНИЯ (конкретные):
1. {file:line}: {что изменить} → {как изменить}

ВЕРДИКТ: PASS (>= 8) | IMPROVE (< 8)
"
```

**Шаг 3: Опубликовать ответ ревьюера как комментарий к PR:**

После получения ответа от ревьюера — сразу опубликовать сырой результат в PR:

```bash
python3 {plugin_root}/scripts/pdlc_vcs.py pr-comment "${PR_NUM}" --body-stdin \
  --project-root "${PDLC_WORK_DIR:-.}" <<'REVIEW_EOF'
## 🤖 Quality Review — Iteration {iteration_number}

**Reviewer:** {REVIEWER_NAME}
**Task:** ${TASK_ID}

---

{сырой ответ ревьюера}

---

_Automated review by Polisade Orchestrator_
REVIEW_EOF
```

Если `pr-comment` завершился ошибкой — залогировать warning и продолжить работу.

**Важно для субагента:**
- `{worktree_path_or_project_root}` — если задача выполнялась в worktree, используй путь worktree. Иначе — корень проекта.
- `{TASK-XXX}` — ID задачи из шага 1
- `{N}` — номер PR из шага 1
- `{REVIEWER_NAME}` — в режиме Codex: `OpenAI Codex CLI (gpt-5.3-codex)`; в режиме self: `{Agent Name} (self-review)` (напр. `Claude Code (self-review)`)
- Субагент pre-fetch'ит diff и PR description через `pdlc_vcs.py` и передаёт в промпт ревьюера. Ревьюер навигирует проект для чтения TASK, parent, AGENTS.md и исходного кода.
- После получения ответа — обязательно опубликовать его как комментарий к PR через `pdlc_vcs.py pr-comment` (шаг 3)
